# Kubernetes (AKS) Deployment

Kubernetes manifests for running the UI + API on AKS (or any Kubernetes cluster).

This folder provides a simple AKS-friendly deployment:
- `web` (nginx serving the React UI) is exposed publicly (demo: `LoadBalancer`, prod: `Ingress`).
- `api` (FastAPI) is internal (`ClusterIP`) and should not be exposed publicly.
- `web` reverse-proxies `/api/*` to the `api` service, so the browser uses a same-origin base URL (`/api`) and CORS is not needed.

## Prereqs
- `kubectl` configured for your cluster
- AKS (or any Kubernetes) cluster that can pull from your image registry
- Images pushed to a registry your cluster can access (ACR recommended)
- Secrets Store CSI Driver and Azure Key Vault provider installed in the cluster
- Microsoft Entra Workload Identity enabled for the cluster

## AKS Demo Overlay

1) Create namespace + base resources:
```bash
kubectl apply -k infra/k8s/overlays/aks-demo
```

The demo overlay mounts a small set of sample migrations at `/data/migrations` so you can run the UI without setting up a PV or Git clone.

2) Create the runtime secret out-of-band (DO NOT commit this):
```bash
kubectl -n flyway-demo create secret generic flyway-api-secrets \
  --from-literal=ConnectionStrings__AppDb='<app-db-connection-string>' \
  --dry-run=client -o yaml | kubectl apply -f -
```

3) Restart the API to pick up the secret:
```bash
kubectl -n flyway-demo rollout restart deploy/flyway-api
```

4) Get the public endpoint for the web UI:
```bash
kubectl -n flyway-demo get svc flyway-web -w
```
Once the `EXTERNAL-IP` is assigned, open:
`http://<EXTERNAL-IP>/`

## Deploy (AKS Prod Overlay: Key Vault + Workload Identity)

The production overlay uses:
- Entra JWT validation (`AUTH_MODE=entra`)
- `Ingress` + TLS for the `web` service
- NetworkPolicy to restrict API ingress to the web pods (if enforced by your cluster)
- Secrets Store CSI + Azure Key Vault provider
- Workload Identity-bound service account for API secret retrieval

1) Review and set:
- `infra/k8s/overlays/aks-prod/api-configmap-patch.yaml` (`AzureAd__TenantId`, `AzureAd__Audience`)
- `infra/k8s/overlays/aks-prod/ingress.yaml` host and TLS secret
- `infra/k8s/overlays/aks-prod/serviceaccount.yaml` (`azure.workload.identity/client-id`)
- `infra/k8s/overlays/aks-prod/secretproviderclass.yaml` (`keyvaultName`, `tenantId`, `clientID`, and `objectName`)

2) Ensure Key Vault contains:
- `flyway-appdb-connection-string` secret for app metadata DB connection string
- Environment DB credential secrets referenced by each environment `passwordSecretName`

3) Apply:
```bash
kubectl apply -k infra/k8s/overlays/aks-prod
```

## Notes
- The prod overlay syncs `ConnectionStrings__AppDb` from Key Vault to `flyway-api-secrets` via `SecretProviderClass`.
- The API reads target DB passwords directly from Key Vault using `KeyVault__Uri` and `passwordSecretName`.
- The demo overlay is intentionally minimal and uses dev auth.
