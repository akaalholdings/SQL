# Infrastructure

## Primary: Kubernetes (AKS)
Kubernetes manifests live under `infra/k8s`.

- Demo overlay: `infra/k8s/overlays/aks-demo`
- Production overlay: `infra/k8s/overlays/aks-prod`

See `infra/k8s/README.md` for details.

## Legacy: Azure Container Apps (Bicep)
The previous Container Apps deployment is kept as legacy reference:

- `infra/legacy/container-apps/main.bicep`
- `infra/legacy/container-apps/README.md`

