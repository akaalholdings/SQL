# Azure Deployment (Container Apps, Legacy)

This deployment path is kept for reference. The primary deployment for this repo is now Kubernetes via `infra/k8s`.

## Prereqs
- Azure CLI logged in
- Images pushed to ACR or another registry

## Deploy
```bash
az group create -n rg-flywayweb -l eastus
az deployment group create \
  -g rg-flywayweb \
  -f main.bicep \
  -p namePrefix=flywayweb \
  -p apiImage=<acr>.azurecr.io/flywayweb-api:latest \
  -p webImage=<acr>.azurecr.io/flywayweb-web:latest \
  -p sqlAdminLogin=<admin> \
  -p sqlAdminPassword=<password>
```

## Configure Entra ID
- Register API and UI apps in Entra ID
- Add app roles: Viewer, Operator, Admin
- Assign users/groups to roles
- Set `AzureAd__TenantId` and `AzureAd__Audience` in the API
- Update MSAL config in the UI build env

## Key Vault
- Assign the API managed identity access to Key Vault secrets
- Store DB passwords and other secrets

