# Data Model

## environments
- id (uuid, PK)
- name (unique)
- type (dev/test/prod)
- server
- database
- schema
- auth_mode (entra/sql)
- jdbc_url
- user
- password_secret_name
- tags_json
- owner
- repository_id (FK)
- history_table
- is_active
- last_validated_at
- last_validation_drift
- last_validation_output
- created_at
- updated_at

## repositories
- id (uuid, PK)
- name (unique)
- type (local/git/internal)
- root_path
- git_url
- git_branch
- git_auth_secret_name
- created_at
- updated_at

## migration_runs
- id (uuid, PK)
- environment_id (FK)
- action (validate/migrate/plan)
- status (running/succeeded/failed)
- started_at
- finished_at
- triggered_by
- confirmation
- pending_count
- applied_count
- drift_detected
- output
- output_json
- error
- duration_ms

## run_logs
- id (uuid, PK)
- run_id (FK)
- timestamp
- level
- message

## audit_events
- id (uuid, PK)
- actor
- action
- entity_type
- entity_id
- occurred_at
- details_json

## environment_locks
- environment_id (PK)
- lock_token
- locked_by
- locked_at
- lock_expires_at
