# Architecture

```mermaid
flowchart LR
  User["Operators / Admins"] --> UI["Web UI (React + MSAL)"]
  UI --> API["API (FastAPI/Python)"]
  API --> AppDB["App DB (Azure SQL)"]
  API --> Repo["Migration Repo (Git/Local)"]
  API --> Flyway["Flyway CLI"]
  Flyway --> TargetDB["Azure SQL Database"]
  API --> KV["Azure Key Vault"]
```
