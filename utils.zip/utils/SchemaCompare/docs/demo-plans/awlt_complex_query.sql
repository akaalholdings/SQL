/*
  AdventureWorksLT complex query for demoing Plan Explorer.
  Targets: Azure SQL / SQL Server.

  Purpose:
  - Multiple CTEs
  - Aggregations + window functions
  - OUTER APPLY
  - Several joins across SalesLT tables
*/

DECLARE @StartDate date = DATEADD(year, -3, CAST(GETDATE() AS date));

WITH Orders AS (
  SELECT
    h.SalesOrderID,
    h.CustomerID,
    h.OrderDate,
    h.TotalDue,
    h.ShipToAddressID,
    h.Status
  FROM SalesLT.SalesOrderHeader h
  WHERE h.OrderDate >= @StartDate
),
OrderLines AS (
  SELECT
    o.SalesOrderID,
    o.CustomerID,
    d.ProductID,
    d.OrderQty,
    d.UnitPrice,
    d.UnitPriceDiscount,
    d.LineTotal
  FROM Orders o
  JOIN SalesLT.SalesOrderDetail d
    ON d.SalesOrderID = o.SalesOrderID
),
CustomerAgg AS (
  SELECT
    ol.CustomerID,
    COUNT(DISTINCT ol.SalesOrderID) AS OrderCount,
    SUM(ol.LineTotal) AS TotalLineSales,
    SUM(ol.OrderQty) AS TotalQty,
    AVG(ol.LineTotal * 1.0) AS AvgLineSales,
    MAX(ol.LineTotal) AS MaxSingleLine,
    SUM(ol.UnitPriceDiscount) AS TotalDiscount
  FROM OrderLines ol
  GROUP BY ol.CustomerID
),
CustomerTopCategory AS (
  SELECT
    ol.CustomerID,
    pc.Name AS CategoryName,
    SUM(ol.LineTotal) AS CategorySales,
    ROW_NUMBER() OVER (
      PARTITION BY ol.CustomerID
      ORDER BY SUM(ol.LineTotal) DESC
    ) AS rn
  FROM OrderLines ol
  JOIN SalesLT.Product p
    ON p.ProductID = ol.ProductID
  JOIN SalesLT.ProductCategory pc
    ON pc.ProductCategoryID = p.ProductCategoryID
  GROUP BY ol.CustomerID, pc.Name
)
SELECT TOP (25)
  c.CustomerID,
  CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
  c.CompanyName,
  ca.OrderCount,
  ca.TotalLineSales,
  ca.TotalQty,
  ca.AvgLineSales,
  ca.MaxSingleLine,
  ca.TotalDiscount,
  CAST(ca.TotalDiscount / NULLIF(ca.TotalLineSales, 0) AS decimal(10,4)) AS DiscountRatio,
  tc.CategoryName AS TopCategory,
  tc.CategorySales AS TopCategorySales,
  ship.City AS ShippingCity,
  ship.StateProvince AS ShippingState
FROM CustomerAgg ca
JOIN SalesLT.Customer c
  ON c.CustomerID = ca.CustomerID
LEFT JOIN CustomerTopCategory tc
  ON tc.CustomerID = ca.CustomerID
 AND tc.rn = 1
OUTER APPLY (
  SELECT TOP (1)
    a.City,
    a.StateProvince,
    a.CountryRegion,
    a.ModifiedDate
  FROM SalesLT.CustomerAddress ca2
  JOIN SalesLT.Address a
    ON a.AddressID = ca2.AddressID
  WHERE ca2.CustomerID = ca.CustomerID
  ORDER BY a.ModifiedDate DESC
) ship
WHERE ca.OrderCount >= 2
ORDER BY ca.TotalLineSales DESC;
