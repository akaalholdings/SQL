from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import audit, environments
from app.core.auth import AuthContextMiddleware
from app.core.config import get_settings
from app.db.session import get_session_factory, verify_or_bootstrap_schema
from app.services.app_seeder import AppSeeder


@asynccontextmanager
async def lifespan(_: FastAPI):
    verify_or_bootstrap_schema()
    session = get_session_factory()()
    try:
        AppSeeder(session).seed()
    finally:
        session.close()
    yield


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(title="Azure SQL Migration Manager API", version="1.0.0", lifespan=lifespan)

    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origins,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    app.add_middleware(AuthContextMiddleware)

    @app.get("/health")
    def health() -> dict:
        return {"status": "ok"}

    app.include_router(environments.router)
    app.include_router(audit.router)

    return app


app = create_app()
