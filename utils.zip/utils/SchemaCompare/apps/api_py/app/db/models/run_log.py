from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import DateTime, String, Text
from sqlalchemy.dialects.mssql import UNIQUEIDENTIFIER
from sqlalchemy.orm import Mapped, mapped_column

from app.db.models.base import Base


class RunLogEntity(Base):
    __tablename__ = "run_logs"

    id: Mapped[uuid.UUID] = mapped_column("Id", UNIQUEIDENTIFIER(as_uuid=True), primary_key=True, default=uuid.uuid4)
    run_id: Mapped[uuid.UUID] = mapped_column("RunId", UNIQUEIDENTIFIER(as_uuid=True), nullable=False, index=True)
    timestamp: Mapped[dt.datetime] = mapped_column(
        "Timestamp", DateTime(timezone=True), nullable=False, default=lambda: dt.datetime.now(dt.timezone.utc)
    )
    level: Mapped[str] = mapped_column("Level", String(20), nullable=False, default="info")
    message: Mapped[str] = mapped_column("Message", Text(), nullable=False)
