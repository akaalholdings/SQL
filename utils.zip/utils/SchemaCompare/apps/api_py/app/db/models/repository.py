from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import DateTime, String
from sqlalchemy.dialects.mssql import UNIQUEIDENTIFIER
from sqlalchemy.orm import Mapped, mapped_column

from app.db.models.base import Base


class RepositoryEntity(Base):
    __tablename__ = "repositories"

    id: Mapped[uuid.UUID] = mapped_column("Id", UNIQUEIDENTIFIER(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column("Name", String(200), nullable=False, unique=True)
    type: Mapped[str] = mapped_column("Type", String(20), nullable=False, default="local")
    root_path: Mapped[str] = mapped_column("RootPath", String(2048), nullable=False)
    git_url: Mapped[str | None] = mapped_column("GitUrl", String(2048), nullable=True)
    git_branch: Mapped[str | None] = mapped_column("GitBranch", String(200), nullable=True)
    git_auth_secret_name: Mapped[str | None] = mapped_column("GitAuthSecretName", String(200), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(
        "CreatedAt", DateTime(timezone=True), nullable=False, default=lambda: dt.datetime.now(dt.timezone.utc)
    )
    updated_at: Mapped[dt.datetime] = mapped_column(
        "UpdatedAt", DateTime(timezone=True), nullable=False, default=lambda: dt.datetime.now(dt.timezone.utc)
    )
