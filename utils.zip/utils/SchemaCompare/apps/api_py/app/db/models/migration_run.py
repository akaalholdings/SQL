from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import Boolean, DateTime, Integer, String, Text
from sqlalchemy.dialects.mssql import UNIQUEIDENTIFIER
from sqlalchemy.orm import Mapped, mapped_column

from app.db.models.base import Base


class MigrationRunEntity(Base):
    __tablename__ = "migration_runs"

    id: Mapped[uuid.UUID] = mapped_column("Id", UNIQUEIDENTIFIER(as_uuid=True), primary_key=True, default=uuid.uuid4)
    environment_id: Mapped[uuid.UUID] = mapped_column("EnvironmentId", UNIQUEIDENTIFIER(as_uuid=True), nullable=False, index=True)
    action: Mapped[str] = mapped_column("Action", String(50), nullable=False)
    status: Mapped[str] = mapped_column("Status", String(20), nullable=False, default="running")
    started_at: Mapped[dt.datetime] = mapped_column(
        "StartedAt", DateTime(timezone=True), nullable=False, default=lambda: dt.datetime.now(dt.timezone.utc)
    )
    finished_at: Mapped[dt.datetime | None] = mapped_column("FinishedAt", DateTime(timezone=True), nullable=True)
    triggered_by: Mapped[str] = mapped_column("TriggeredBy", String(200), nullable=False)
    confirmation: Mapped[str | None] = mapped_column("Confirmation", String(200), nullable=True)
    pending_count: Mapped[int | None] = mapped_column("PendingCount", Integer(), nullable=True)
    applied_count: Mapped[int | None] = mapped_column("AppliedCount", Integer(), nullable=True)
    drift_detected: Mapped[bool | None] = mapped_column("DriftDetected", Boolean(), nullable=True)
    output: Mapped[str | None] = mapped_column("Output", Text(), nullable=True)
    output_json: Mapped[str | None] = mapped_column("OutputJson", Text(), nullable=True)
    error: Mapped[str | None] = mapped_column("Error", Text(), nullable=True)
    duration_ms: Mapped[int | None] = mapped_column("DurationMs", Integer(), nullable=True)
