from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import DateTime, String, Text
from sqlalchemy.dialects.mssql import UNIQUEIDENTIFIER
from sqlalchemy.orm import Mapped, mapped_column

from app.db.models.base import Base


class AuditEventEntity(Base):
    __tablename__ = "audit_events"

    id: Mapped[uuid.UUID] = mapped_column("Id", UNIQUEIDENTIFIER(as_uuid=True), primary_key=True, default=uuid.uuid4)
    actor: Mapped[str] = mapped_column("Actor", String(200), nullable=False)
    action: Mapped[str] = mapped_column("Action", String(200), nullable=False)
    entity_type: Mapped[str] = mapped_column("EntityType", String(100), nullable=False)
    entity_id: Mapped[uuid.UUID | None] = mapped_column("EntityId", UNIQUEIDENTIFIER(as_uuid=True), nullable=True)
    occurred_at: Mapped[dt.datetime] = mapped_column(
        "OccurredAt", DateTime(timezone=True), nullable=False, default=lambda: dt.datetime.now(dt.timezone.utc)
    )
    details_json: Mapped[str | None] = mapped_column("DetailsJson", Text(), nullable=True)
