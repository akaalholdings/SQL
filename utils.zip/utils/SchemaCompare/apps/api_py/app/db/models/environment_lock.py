from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import DateTime, String
from sqlalchemy.dialects.mssql import UNIQUEIDENTIFIER
from sqlalchemy.orm import Mapped, mapped_column

from app.db.models.base import Base


class EnvironmentLockEntity(Base):
    __tablename__ = "environment_locks"

    environment_id: Mapped[uuid.UUID] = mapped_column("EnvironmentId", UNIQUEIDENTIFIER(as_uuid=True), primary_key=True)
    lock_token: Mapped[str | None] = mapped_column("LockToken", String(200), nullable=True)
    locked_by: Mapped[str | None] = mapped_column("LockedBy", String(200), nullable=True)
    locked_at: Mapped[dt.datetime] = mapped_column("LockedAt", DateTime(timezone=True), nullable=False)
    lock_expires_at: Mapped[dt.datetime] = mapped_column("LockExpiresAt", DateTime(timezone=True), nullable=False)
