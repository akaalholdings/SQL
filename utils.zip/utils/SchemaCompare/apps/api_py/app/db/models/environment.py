from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import Boolean, DateTime, String, Text
from sqlalchemy.dialects.mssql import UNIQUEIDENTIFIER
from sqlalchemy.orm import Mapped, mapped_column

from app.db.models.base import Base


class EnvironmentEntity(Base):
    __tablename__ = "environments"

    id: Mapped[uuid.UUID] = mapped_column("Id", UNIQUEIDENTIFIER(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column("Name", String(200), nullable=False, unique=True)
    type: Mapped[str] = mapped_column("Type", String(50), nullable=False, default="dev")
    server: Mapped[str] = mapped_column("Server", String(200), nullable=False)
    database: Mapped[str] = mapped_column("Database", String(200), nullable=False)
    schema: Mapped[str] = mapped_column("Schema", String(128), nullable=False, default="dbo")
    auth_mode: Mapped[str] = mapped_column("AuthMode", String(20), nullable=False, default="entra")
    jdbc_url: Mapped[str] = mapped_column("JdbcUrl", String(2048), nullable=False)
    user: Mapped[str | None] = mapped_column("User", String(200), nullable=True)
    password_secret_name: Mapped[str | None] = mapped_column("PasswordSecretName", String(200), nullable=True)
    tags_json: Mapped[str | None] = mapped_column("TagsJson", Text(), nullable=True)
    owner: Mapped[str | None] = mapped_column("Owner", String(200), nullable=True)
    repository_id: Mapped[uuid.UUID] = mapped_column("RepositoryId", UNIQUEIDENTIFIER(as_uuid=True), nullable=False)
    history_table: Mapped[str] = mapped_column("HistoryTable", String(200), nullable=False, default="flyway_schema_history")
    is_active: Mapped[bool] = mapped_column("IsActive", Boolean(), nullable=False, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(
        "CreatedAt", DateTime(timezone=True), nullable=False, default=lambda: dt.datetime.now(dt.timezone.utc)
    )
    updated_at: Mapped[dt.datetime] = mapped_column(
        "UpdatedAt", DateTime(timezone=True), nullable=False, default=lambda: dt.datetime.now(dt.timezone.utc)
    )
    last_validated_at: Mapped[dt.datetime | None] = mapped_column("LastValidatedAt", DateTime(timezone=True), nullable=True)
    last_validation_drift: Mapped[bool | None] = mapped_column("LastValidationDrift", Boolean(), nullable=True)
    last_validation_output: Mapped[str | None] = mapped_column("LastValidationOutput", Text(), nullable=True)
