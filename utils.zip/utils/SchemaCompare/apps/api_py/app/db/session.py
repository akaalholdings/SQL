from __future__ import annotations

import time
from typing import Dict, Generator
from urllib.parse import quote_plus

import pyodbc
from sqlalchemy import create_engine, inspect
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import Settings, get_settings
from app.db.models import Base


_REQUIRED_TABLES = {
    "environments",
    "repositories",
    "migration_runs",
    "run_logs",
    "audit_events",
    "environment_locks",
}


def _parse_ado_connection_string(raw: str) -> Dict[str, str]:
    parts: Dict[str, str] = {}
    for segment in raw.split(";"):
        item = segment.strip()
        if not item or "=" not in item:
            continue
        key, value = item.split("=", 1)
        parts[key.strip().lower()] = value.strip()
    return parts


def _to_bool_text(value: str | None, default: str = "no") -> str:
    if value is None:
        return default
    return "yes" if value.strip().lower() in {"1", "true", "yes", "on"} else "no"


def build_pyodbc_connect_string(raw: str) -> str:
    if raw.lower().startswith("driver="):
        return raw

    if raw.lower().startswith("mssql+pyodbc://"):
        if "odbc_connect=" not in raw:
            raise RuntimeError("Invalid SQLAlchemy mssql+pyodbc URL. Missing odbc_connect.")
        encoded = raw.split("odbc_connect=", 1)[1]
        from urllib.parse import unquote_plus

        return unquote_plus(encoded)

    values = _parse_ado_connection_string(raw)
    driver = values.get("driver", "ODBC Driver 18 for SQL Server")
    server = (
        values.get("server")
        or values.get("data source")
        or values.get("datasource")
        or values.get("address")
        or values.get("addr")
        or values.get("network address")
    )
    if not server:
        raise RuntimeError("App DB connection string must include Server.")

    database = values.get("database") or values.get("initial catalog")
    uid = values.get("user id") or values.get("uid") or values.get("user")
    pwd = values.get("password") or values.get("pwd")
    encrypt = _to_bool_text(values.get("encrypt"), default="yes")
    trust_server_cert = _to_bool_text(values.get("trustservercertificate"), default="no")
    timeout = values.get("connect timeout") or values.get("connection timeout") or values.get("timeout") or "30"
    authentication = values.get("authentication")

    attrs = [
        f"DRIVER={{{driver}}}",
        f"SERVER={server}",
    ]

    if database:
        attrs.append(f"DATABASE={database}")

    if authentication:
        attrs.append(f"Authentication={authentication}")

    if uid:
        attrs.append(f"UID={uid}")

    if pwd:
        attrs.append(f"PWD={pwd}")

    attrs.extend(
        [
            f"Encrypt={encrypt}",
            f"TrustServerCertificate={trust_server_cert}",
            f"Connection Timeout={timeout}",
        ]
    )

    return ";".join(attrs)


def build_sqlalchemy_url(raw: str) -> str:
    if raw.lower().startswith("mssql+pyodbc://"):
        return raw

    odbc_connect = build_pyodbc_connect_string(raw)
    return f"mssql+pyodbc:///?odbc_connect={quote_plus(odbc_connect)}"


def _quoted_identifier(value: str) -> str:
    safe = value.replace("]", "]]")
    return f"[{safe}]"


def _create_database_if_missing(settings: Settings) -> None:
    parts = _parse_ado_connection_string(settings.app_db_connection_string)
    database_name = parts.get("database") or parts.get("initial catalog")
    if not database_name:
        return

    master_parts = dict(parts)
    master_parts["database"] = "mid_dev"
    master_parts.pop("initial catalog", None)

    driver = master_parts.get("driver", "ODBC Driver 18 for SQL Server")
    server = master_parts.get("server") or master_parts.get("data source")
    if not server:
        return

    uid = master_parts.get("user id") or master_parts.get("uid") or master_parts.get("user")
    pwd = master_parts.get("password") or master_parts.get("pwd")
    encrypt = _to_bool_text(master_parts.get("encrypt"), default="yes")
    trust_server_cert = _to_bool_text(master_parts.get("trustservercertificate"), default="no")
    timeout = master_parts.get("connect timeout") or master_parts.get("connection timeout") or "30"

    conn_values = [
        f"DRIVER={{{driver}}}",
        f"SERVER={server}",
        "DATABASE=mid_dev",
        f"Encrypt={encrypt}",
        f"TrustServerCertificate={trust_server_cert}",
        f"Connection Timeout={timeout}",
    ]

    if uid:
        conn_values.append(f"UID={uid}")
    if pwd:
        conn_values.append(f"PWD={pwd}")

    conn_str = ";".join(conn_values)

    with pyodbc.connect(conn_str, autocommit=True) as conn:
        cursor = conn.cursor()
        safe_name = _quoted_identifier(database_name)
        cursor.execute(f"IF DB_ID(?) IS NULL CREATE DATABASE {safe_name};", database_name)
        cursor.close()


_ENGINE: Engine | None = None
_SESSION_FACTORY: sessionmaker[Session] | None = None


def get_engine() -> Engine:
    global _ENGINE
    if _ENGINE is None:
        settings = get_settings()
        _ENGINE = create_engine(
            build_sqlalchemy_url(settings.app_db_connection_string),
            pool_pre_ping=True,
            future=True,
        )
    return _ENGINE


def get_session_factory() -> sessionmaker[Session]:
    global _SESSION_FACTORY
    if _SESSION_FACTORY is None:
        _SESSION_FACTORY = sessionmaker(bind=get_engine(), autocommit=False, autoflush=False, expire_on_commit=False)
    return _SESSION_FACTORY


def get_db() -> Generator[Session, None, None]:
    session = get_session_factory()()
    try:
        yield session
    finally:
        session.close()


def verify_or_bootstrap_schema() -> None:
    settings = get_settings()

    last_error: Exception | None = None
    for attempt in range(30):
        try:
            if settings.app_db_auto_create:
                _create_database_if_missing(settings)

            engine = get_engine()
            inspector = inspect(engine)
            existing_tables = set(inspector.get_table_names())
            missing = _REQUIRED_TABLES - existing_tables

            if missing and settings.app_db_auto_create:
                Base.metadata.create_all(engine)
                inspector = inspect(engine)
                existing_tables = set(inspector.get_table_names())
                missing = _REQUIRED_TABLES - existing_tables

            if missing:
                missing_sorted = ", ".join(sorted(missing))
                raise RuntimeError(f"App DB schema is missing required tables: {missing_sorted}")

            return
        except Exception as exc:  # pragma: no cover - startup retry guard
            last_error = exc
            if attempt == 29:
                break
            time.sleep(2)

    if last_error is not None:
        raise last_error
