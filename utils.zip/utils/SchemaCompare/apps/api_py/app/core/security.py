from __future__ import annotations

from typing import Callable, Iterable, Set

from fastapi import Depends, HTTPException, Request, status

from app.core.auth import Principal


_POLICY_ROLES = {
    "Viewer": {"Viewer", "Operator", "Admin"},
    "Operator": {"Operator", "Admin"},
    "Admin": {"Admin"},
}


def get_current_principal(request: Request) -> Principal:
    principal: Principal | None = getattr(request.state, "principal", None)
    if principal is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    return principal


def require_policy(policy: str) -> Callable[[Principal], Principal]:
    allowed: Set[str] = _POLICY_ROLES[policy]

    def dependency(principal: Principal = Depends(get_current_principal)) -> Principal:
        if not set(principal.roles).intersection(allowed):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")
        return principal

    return dependency


def ensure_role(principal: Principal, allowed_roles: Iterable[str]) -> None:
    if not set(principal.roles).intersection(set(allowed_roles)):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")
