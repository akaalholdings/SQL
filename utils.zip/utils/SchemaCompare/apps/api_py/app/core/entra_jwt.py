from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import jwt
from jwt.algorithms import RSAAlgorithm

from app.core.config import Settings


class JwtValidationError(RuntimeError):
    pass


_JWKS_TTL_SECONDS = 60 * 60
_HTTP_TIMEOUT_SECONDS = 5

# tenant_id -> (expires_at_monotonic, keys_by_kid)
_JWKS_CACHE: Dict[str, Tuple[float, Dict[str, str]]] = {}


def _jwks_url(tenant_id: str) -> str:
    return f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"


def _fetch_jwks(tenant_id: str) -> Dict[str, str]:
    url = _jwks_url(tenant_id)
    request = urllib.request.Request(
        url,
        headers={"Accept": "application/json", "User-Agent": "flyway-web-api/1.0"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=_HTTP_TIMEOUT_SECONDS) as resp:  # nosec - JWKS fetch
            payload = resp.read().decode("utf-8")
    except urllib.error.URLError as exc:
        raise JwtValidationError(f"Failed to fetch Entra JWKS: {exc}") from exc

    try:
        doc = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise JwtValidationError("Invalid JWKS JSON payload.") from exc

    keys = doc.get("keys")
    if not isinstance(keys, list):
        raise JwtValidationError("Invalid JWKS payload: missing keys.")

    by_kid: Dict[str, str] = {}
    for item in keys:
        if not isinstance(item, dict):
            continue
        kid = item.get("kid")
        kty = item.get("kty")
        use = item.get("use")
        if not kid or not isinstance(kid, str):
            continue
        if kty != "RSA":
            continue
        if use and use != "sig":
            continue
        by_kid[kid] = json.dumps(item)

    if not by_kid:
        raise JwtValidationError("No RSA signing keys found in JWKS.")

    return by_kid


def _get_jwk_json(tenant_id: str, kid: str) -> str:
    now = time.monotonic()
    cached = _JWKS_CACHE.get(tenant_id)
    if cached is None or cached[0] <= now:
        keys_by_kid = _fetch_jwks(tenant_id)
        _JWKS_CACHE[tenant_id] = (now + _JWKS_TTL_SECONDS, keys_by_kid)
        cached = _JWKS_CACHE[tenant_id]

    jwk_json = cached[1].get(kid)
    if jwk_json:
        return jwk_json

    # Key rotation: refresh once if kid not found.
    keys_by_kid = _fetch_jwks(tenant_id)
    _JWKS_CACHE[tenant_id] = (now + _JWKS_TTL_SECONDS, keys_by_kid)
    jwk_json = keys_by_kid.get(kid)
    if not jwk_json:
        raise JwtValidationError("Signing key not found (kid unknown).")
    return jwk_json


def _extract_roles(claims: Dict[str, Any]) -> List[str]:
    roles_value = claims.get("roles")
    if isinstance(roles_value, list):
        return [str(r) for r in roles_value if r]
    if isinstance(roles_value, str) and roles_value.strip():
        # Sometimes roles can arrive as a single string.
        return [roles_value.strip()]
    return []


def _extract_name(claims: Dict[str, Any]) -> str:
    for key in ("preferred_username", "upn", "email", "name", "sub"):
        value = claims.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return "unknown"


@dataclass(frozen=True)
class EntraPrincipal:
    name: str
    roles: List[str]


def validate_bearer_token(token: str, settings: Settings) -> EntraPrincipal:
    if not settings.entra_tenant_id:
        raise JwtValidationError("Entra tenant ID is not configured (ENTRA_TENANT_ID / AzureAd__TenantId).")
    if not settings.entra_audience:
        raise JwtValidationError("Entra audience is not configured (ENTRA_AUDIENCE / AzureAd__Audience).")

    token = (token or "").strip()
    if not token:
        raise JwtValidationError("Empty bearer token.")

    try:
        header = jwt.get_unverified_header(token)
    except jwt.PyJWTError as exc:
        raise JwtValidationError("Invalid JWT header.") from exc

    kid = header.get("kid")
    if not kid or not isinstance(kid, str):
        raise JwtValidationError("JWT is missing kid header.")

    jwk_json = _get_jwk_json(settings.entra_tenant_id, kid)
    public_key = RSAAlgorithm.from_jwk(jwk_json)

    try:
        claims = jwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            audience=settings.entra_audience,
            issuer=settings.entra_issuer,
            options={
                "verify_signature": True,
                "verify_aud": True,
                "verify_iss": True,
                "verify_exp": True,
                "verify_nbf": True,
                "verify_iat": False,
            },
            leeway=60,
        )
    except jwt.PyJWTError as exc:
        raise JwtValidationError(f"JWT validation failed: {exc}") from exc

    if not isinstance(claims, dict):
        raise JwtValidationError("Invalid JWT claims payload.")

    return EntraPrincipal(name=_extract_name(claims), roles=_extract_roles(claims))

