from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from typing import List

from app.keyvault_provider import KeyVaultProvider

provider = KeyVaultProvider.from_env()

def _first_env(*keys: str, default: str | None = None) -> str | None:
    for key in keys:
        value = os.getenv(key)
        if value is not None:
            return value
    return default


def _parse_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_int(value: str | None, default: int) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _parse_origins(value: str | None) -> List[str]:
    if not value:
        return []

    text = value.strip()
    if text.startswith("[") and text.endswith("]"):
        text = text[1:-1]

    return [item.strip().strip('"').strip("'") for item in text.split(",") if item.strip()]


def _load_indexed_origins(prefixes: List[str]) -> List[str]:
    indexed: List[tuple[int, str]] = []
    for key, value in os.environ.items():
        if not value:
            continue
        lower = key.lower()
        for prefix in prefixes:
            prefix_lower = prefix.lower()
            if not lower.startswith(prefix_lower):
                continue
            suffix = key[len(prefix):]
            if suffix.isdigit():
                indexed.append((int(suffix), value.strip()))
            break

    if not indexed:
        return []

    indexed.sort(key=lambda item: item[0])
    return [value for _, value in indexed]


def _load_cors_origins() -> List[str]:
    explicit = _first_env("CORS_ORIGINS", "Cors__Origins")
    if explicit:
        parsed = _parse_origins(explicit)
        if parsed:
            return parsed

    indexed = _load_indexed_origins(["Cors__Origins__", "CORS_ORIGINS__"])
    if indexed:
        return indexed

    return []


def _resolve_entra_issuer(tenant_id: str, explicit: str | None) -> str:
    if explicit and explicit.strip():
        return explicit.strip()
    return f"https://login.microsoftonline.com/{tenant_id}/v2.0"


@dataclass(frozen=True)
class Settings:
    app_db_connection_string: str
    flyway_path: str
    flyway_timeout_seconds: int
    locks_timeout_minutes: int
    security_allow_sql_auth: bool
    key_vault_uri: str
    seed_enabled: bool
    seed_repo_root: str
    dev_auth_enabled: bool
    dev_auth_user: str
    dev_auth_roles: List[str]
    auth_mode: str
    cors_origins: List[str]
    app_db_auto_create: bool
    output_max_chars: int
    entra_tenant_id: str
    entra_audience: str
    entra_issuer: str
    openai_api_key: str
    openai_model: str
    openai_max_output_tokens: int
    openai_reasoning_effort: str

    @property
    def lock_timeout_seconds(self) -> int:
        return max(self.locks_timeout_minutes, 1) * 60


def _load_dev_auth_roles() -> List[str]:
    roles_text = _first_env("DEV_AUTH_ROLES", "DevAuth__Roles", default="Admin,Operator,Viewer")
    if not roles_text:
        return ["Admin", "Operator", "Viewer"]

    roles = [role.strip() for role in roles_text.split(",") if role.strip()]
    return roles or ["Admin", "Operator", "Viewer"]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    app_db = provider.get_secret("db-connection-string")
    if not app_db:
        raise RuntimeError("App DB connection string is required. Set db-connection-string in Key Vault")
    key_vault_name = (_first_env("KEY_VAULT_NAME", default="") or "").strip()
    if not key_vault_name:
        raise RuntimeError("Key Vault name is required. Set KEY_VAULT_NAME.")
    key_vault_uri = f"https://{key_vault_name}.vault.azure.net/"
    auth_mode = (_first_env("AUTH_MODE", default="entra") or "entra").strip().lower()

    entra_tenant_id = (_first_env("ENTRA_TENANT_ID", "AzureAd__TenantId", default="") or "").strip()
    entra_audience = (_first_env("ENTRA_AUDIENCE", "AzureAd__Audience", default="") or "").strip()
    entra_issuer = _resolve_entra_issuer(entra_tenant_id, _first_env("ENTRA_ISSUER", "AzureAd__Issuer"))

    return Settings(
        app_db_connection_string=app_db,
        flyway_path=_first_env("FLYWAY_PATH", "Flyway__Path", default="flyway") or "flyway",
        flyway_timeout_seconds=_parse_int(_first_env("FLYWAY_TIMEOUT_SECONDS", "Flyway__TimeoutSeconds"), 1800),
        locks_timeout_minutes=_parse_int(_first_env("LOCKS_TIMEOUT_MINUTES", "Locks__TimeoutMinutes"), 60),
        security_allow_sql_auth=_parse_bool(_first_env("SECURITY_ALLOW_SQL_AUTH", "Security__AllowSqlAuth"), False),
        key_vault_uri=key_vault_uri,
        seed_enabled=_parse_bool(_first_env("SEED_ENABLED", "Seed__Enabled"), False),
        seed_repo_root=_first_env("SEED_REPO_ROOT", "Seed__RepoRoot", default="/data/migrations") or "/data/migrations",
        dev_auth_enabled=_parse_bool(_first_env("DEV_AUTH_ENABLED", "DevAuth__Enabled"), False),
        dev_auth_user=_first_env("DEV_AUTH_USER", "DevAuth__User", default="dev.user@local") or "dev.user@local",
        dev_auth_roles=_load_dev_auth_roles(),
        auth_mode=auth_mode,
        cors_origins=_load_cors_origins(),
        app_db_auto_create=_parse_bool(_first_env("APP_DB_AUTO_CREATE"), False),
        output_max_chars=_parse_int(_first_env("OUTPUT_MAX_CHARS", "Output__MaxChars"), 2_000_000),
        entra_tenant_id=entra_tenant_id,
        entra_audience=entra_audience,
        entra_issuer=entra_issuer,
        openai_api_key=_first_env("OPENAI_API_KEY", "OpenAI__ApiKey", default="") or "",
        openai_model=_first_env("OPENAI_MODEL", "OpenAI__Model", default="gpt-5-mini") or "gpt-5-mini",
        openai_max_output_tokens=_parse_int(
            _first_env("OPENAI_MAX_OUTPUT_TOKENS", "OpenAI__MaxOutputTokens"), default=900
        ),
        openai_reasoning_effort=(
            _first_env("OPENAI_REASONING_EFFORT", "OpenAI__ReasoningEffort", default="low") or "low"
        ).strip(),
    )
