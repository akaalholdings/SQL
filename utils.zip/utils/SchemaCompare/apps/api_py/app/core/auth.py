from __future__ import annotations

from dataclasses import dataclass
from typing import List

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

from app.core.config import get_settings
from app.core.entra_jwt import JwtValidationError, validate_bearer_token


@dataclass
class Principal:
    name: str
    roles: List[str]


class AuthContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        settings = get_settings()

        if settings.auth_mode == "dev":
            request.state.principal = Principal(name=settings.dev_auth_user, roles=settings.dev_auth_roles)
        elif settings.auth_mode == "entra":
            principal = None
            auth = request.headers.get("Authorization") or ""
            if auth.lower().startswith("bearer "):
                token = auth.split(" ", 1)[1].strip()
                try:
                    entra_principal = validate_bearer_token(token, settings)
                    principal = Principal(name=entra_principal.name, roles=entra_principal.roles)
                except JwtValidationError:
                    principal = None
            request.state.principal = principal
        else:
            request.state.principal = None

        return await call_next(request)


def get_actor(request: Request) -> str:
    principal: Principal | None = getattr(request.state, "principal", None)
    if principal and principal.name:
        return principal.name
    return "unknown"
