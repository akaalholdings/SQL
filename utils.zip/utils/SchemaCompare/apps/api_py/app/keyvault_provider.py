"""
Reusable Azure Key Vault secret provider.

Drop this file into any repo. It has no app-specific imports — only requires:
    pip install azure-identity azure-keyvault-secrets

Usage:
    from app.keyvault_provider import KeyVaultProvider

    # Fetch a single secret
    provider = KeyVaultProvider("https://my-vault.vault.azure.net/")
    password = provider.get_secret("db-password")

    # Fetch multiple secrets at once (returns a dict)
    secrets = provider.get_secrets(["db-host", "db-name", "db-username", "db-password"])
    print(secrets["db-password"])

    # Auto-create from KEY_VAULT_NAME or KEY_VAULT_URI env var
    provider = KeyVaultProvider.from_env()

Authentication:
    Uses DefaultAzureCredential which supports:
    - Workload Identity on AKS (AZURE_CLIENT_ID + federated token)
    - Managed Identity on Azure VMs / App Service
    - Azure CLI / VS Code credentials for local development
    - Environment variables (AZURE_CLIENT_ID + AZURE_CLIENT_SECRET + AZURE_TENANT_ID)
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)


class KeyVaultProvider:
    def __init__(self, vault_uri: str) -> None:
        if not vault_uri:
            raise ValueError("vault_uri must not be empty.")

        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient

        self._vault_uri = vault_uri
        self._client = SecretClient(vault_url=vault_uri, credential=DefaultAzureCredential())
        logger.info("KeyVaultProvider initialized for %s", vault_uri)

    @classmethod
    def from_name(cls, vault_name: str) -> KeyVaultProvider:
        """Create a provider from just the vault name (constructs the URL)."""
        if not vault_name:
            raise ValueError("vault_name must not be empty.")
        vault_uri = f"https://{vault_name}.vault.azure.net/"
        return cls(vault_uri)

    @classmethod
    def from_env(cls) -> KeyVaultProvider:
        """Create a provider from KEY_VAULT_NAME or KEY_VAULT_URI env var."""
        vault_name = os.getenv("KEY_VAULT_NAME", "").strip()
        if vault_name:
            return cls.from_name(vault_name)
        vault_uri = os.getenv("KEY_VAULT_URI", "").strip()
        if vault_uri:
            return cls(vault_uri)
        raise RuntimeError("Set KEY_VAULT_NAME or KEY_VAULT_URI environment variable.")

    def get_secret(self, name: str) -> str | None:
        """Fetch a single secret by name. Returns None on failure."""
        if not name:
            return None
        try:
            secret = self._client.get_secret(name)
            return secret.value
        except Exception:
            logger.exception("Failed to fetch secret '%s' from %s", name, self._vault_uri)
            return None

    def get_secrets(self, names: list[str]) -> dict[str, str | None]:
        """Fetch multiple secrets by name. Returns a dict of {name: value}."""
        return {name: self.get_secret(name) for name in names}
