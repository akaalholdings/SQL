from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import Field

from app.schemas.base import ApiModel


class PlanReviewObject(ApiModel):
    database: Optional[str] = None
    schema: Optional[str] = None
    table: Optional[str] = None
    index: Optional[str] = None
    alias: Optional[str] = None


class PlanReviewNode(ApiModel):
    nodeId: int
    physicalOp: Optional[str] = None
    logicalOp: Optional[str] = None
    estimatedRows: Optional[float] = None
    actualRows: Optional[float] = None
    estimatedTotalSubtreeCost: Optional[float] = None
    estimatedOperatorCost: Optional[float] = None
    object: Optional[PlanReviewObject] = None
    warnings: List[str] = Field(default_factory=list)


class PlanReviewRequest(ApiModel):
    fileName: Optional[str] = None
    statementText: Optional[str] = None
    queryPlan: Optional[str] = None
    nodeCount: int
    hasActualRows: bool = False
    nodes: List[PlanReviewNode]


class PlanReviewResponse(ApiModel):
    model: str
    generatedAt: datetime
    analysis: str
