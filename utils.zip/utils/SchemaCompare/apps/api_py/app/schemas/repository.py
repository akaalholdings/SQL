from __future__ import annotations

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from app.schemas.base import ApiModel


class RepositoryCreateRequest(ApiModel):
    name: str
    type: str
    rootPath: str
    gitUrl: Optional[str] = None
    gitBranch: Optional[str] = None
    gitAuthSecretName: Optional[str] = None


class RepositoryResponse(ApiModel):
    id: UUID
    name: str
    type: str
    rootPath: str
    gitUrl: Optional[str] = None
    gitBranch: Optional[str] = None
    createdAt: datetime
    updatedAt: datetime


class ScriptInfoResponse(ApiModel):
    path: str
    type: str
    version: Optional[str] = None
    description: str
    checksum: str
    sizeBytes: int
    lastModified: datetime


class ScriptContentResponse(ApiModel):
    path: str
    checksum: str
    content: str


class ScriptDiffResponse(ApiModel):
    leftPath: str
    rightPath: str
    diffLines: List[str]
