from __future__ import annotations

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from app.schemas.base import ApiModel


class RunResponse(ApiModel):
    id: UUID
    environmentId: UUID
    action: str
    status: str
    startedAt: datetime
    finishedAt: Optional[datetime] = None
    triggeredBy: str
    pendingCount: Optional[int] = None
    appliedCount: Optional[int] = None
    driftDetected: Optional[bool] = None
    error: Optional[str] = None


class RunLogItem(ApiModel):
    timestamp: datetime
    level: str
    message: str


class RunDetailResponse(ApiModel):
    id: UUID
    environmentId: UUID
    action: str
    status: str
    startedAt: datetime
    finishedAt: Optional[datetime] = None
    triggeredBy: str
    pendingCount: Optional[int] = None
    appliedCount: Optional[int] = None
    driftDetected: Optional[bool] = None
    output: Optional[str] = None
    outputJson: Optional[str] = None
    error: Optional[str] = None
    logs: List[RunLogItem]
