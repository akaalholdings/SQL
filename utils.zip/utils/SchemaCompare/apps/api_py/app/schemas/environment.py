from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional
from uuid import UUID

from app.schemas.base import ApiModel


class EnvironmentCreateRequest(ApiModel):
    name: str
    type: str
    server: str
    database: str
    schema: Optional[str] = None
    authMode: str
    jdbcUrl: str
    user: Optional[str] = None
    passwordSecretName: Optional[str] = None
    repositoryId: UUID
    historyTable: Optional[str] = None
    tags: Optional[Dict[str, str]] = None
    owner: Optional[str] = None


class EnvironmentUpdateRequest(ApiModel):
    name: str
    type: str
    server: str
    database: str
    schema: Optional[str] = None
    authMode: str
    jdbcUrl: str
    user: Optional[str] = None
    passwordSecretName: Optional[str] = None
    repositoryId: UUID
    historyTable: Optional[str] = None
    tags: Optional[Dict[str, str]] = None
    owner: Optional[str] = None
    isActive: bool


class EnvironmentResponse(ApiModel):
    id: UUID
    name: str
    type: str
    server: str
    database: str
    schema: str
    authMode: str
    jdbcUrl: str
    user: Optional[str] = None
    passwordSecretName: Optional[str] = None
    repositoryId: UUID
    historyTable: str
    isActive: bool
    tags: Optional[Dict[str, str]] = None
    owner: Optional[str] = None
    createdAt: datetime
    updatedAt: datetime
    lastValidatedAt: Optional[datetime] = None
    lastValidationDrift: Optional[bool] = None


class EnvironmentStatusResponse(ApiModel):
    environmentId: UUID
    currentVersion: str
    pendingCount: int
    appliedCount: int
    driftDetected: bool
    lastValidatedAt: Optional[datetime] = None


class MigrationActionRequest(ApiModel):
    dryRun: bool = False
    confirmation: Optional[str] = None


class MigrationHistoryItem(ApiModel):
    version: Optional[str] = None
    description: Optional[str] = None
    type: Optional[str] = None
    script: Optional[str] = None
    checksum: Optional[str] = None
    installedBy: Optional[str] = None
    installedOn: Optional[datetime] = None
    executionTimeMs: Optional[int] = None
    success: Optional[bool] = None
    state: Optional[str] = None


class MigrationHistoryResponse(ApiModel):
    environmentId: UUID
    applied: List[MigrationHistoryItem]
    pending: List[MigrationHistoryItem]
