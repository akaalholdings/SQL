from __future__ import annotations

from typing import List, Optional

from app.schemas.base import ApiModel


class DatabaseSchemaResponse(ApiModel):
    connectionId: str
    connectionName: str
    environment: str
    fetchedAt: str
    tables: List["TableSchemaResponse"]


class EnvironmentRowCountsResponse(ApiModel):
    connectionId: str
    connectionName: str
    environment: str
    fetchedAt: str
    tables: List["TableRowCountResponse"]


class TableRowCountResponse(ApiModel):
    schema: str
    tableName: str
    rowCount: int


class TableSchemaResponse(ApiModel):
    name: str
    schema: str
    columns: List["ColumnSchemaResponse"]
    indexes: List["IndexSchemaResponse"]
    constraints: List["TableConstraintSchemaResponse"]
    foreignKeys: List["ForeignKeySchemaResponse"]
    partitions: Optional["PartitionSchemaResponse"] = None


class ColumnSchemaResponse(ApiModel):
    name: str
    dataType: str
    maxLength: Optional[int] = None
    precision: Optional[int] = None
    scale: Optional[int] = None
    isNullable: bool
    defaultValue: Optional[str] = None
    isIdentity: bool
    isComputed: bool


class IndexSchemaResponse(ApiModel):
    name: str
    type: str
    isUnique: bool
    isPrimaryKey: bool
    columns: List["IndexColumnSchemaResponse"]


class IndexColumnSchemaResponse(ApiModel):
    name: str
    isDescending: bool
    isIncluded: bool


class PartitionSchemaResponse(ApiModel):
    schemeName: Optional[str] = None
    functionName: Optional[str] = None
    columnName: Optional[str] = None
    partitionCount: int


class TableConstraintSchemaResponse(ApiModel):
    name: str
    type: str
    definition: Optional[str] = None
    isClustered: bool
    isDisabled: bool
    isNotTrusted: bool
    columns: List["ConstraintColumnSchemaResponse"]


class ConstraintColumnSchemaResponse(ApiModel):
    name: str
    isDescending: bool


class ForeignKeySchemaResponse(ApiModel):
    name: str
    referencedSchema: str
    referencedTable: str
    onDeleteAction: str
    onUpdateAction: str
    isDisabled: bool
    isNotTrusted: bool
    columns: List["ForeignKeyColumnSchemaResponse"]


class ForeignKeyColumnSchemaResponse(ApiModel):
    sourceColumn: str
    referencedColumn: str


DatabaseSchemaResponse.model_rebuild()
EnvironmentRowCountsResponse.model_rebuild()
TableSchemaResponse.model_rebuild()
IndexSchemaResponse.model_rebuild()
TableConstraintSchemaResponse.model_rebuild()
ForeignKeySchemaResponse.model_rebuild()
