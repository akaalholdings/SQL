from __future__ import annotations

from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.dependencies import get_audit_service, get_diff_service, get_repo_service, get_repo_sync_service
from app.core.auth import Principal
from app.core.security import require_policy
from app.db.models import RepositoryEntity
from app.db.session import get_db
from app.schemas.repository import (
    RepositoryCreateRequest,
    RepositoryResponse,
    ScriptContentResponse,
    ScriptDiffResponse,
    ScriptInfoResponse,
)
from app.services.audit_service import AuditService
from app.services.diff_service import DiffService
from app.services.mapping import repository_to_response
from app.services.repo_service import MigrationRepository, RepoSyncService


router = APIRouter(prefix="/repos", tags=["repositories"])


def _bad_request(message: str) -> JSONResponse:
    return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={"error": message})


@router.get("", response_model=List[RepositoryResponse])
def get_repositories(
    db: Session = Depends(get_db),
    _: Principal = Depends(require_policy("Viewer")),
) -> List[RepositoryResponse]:
    repos = db.execute(select(RepositoryEntity).order_by(RepositoryEntity.name.asc())).scalars().all()
    return [repository_to_response(item) for item in repos]


@router.post("", response_model=RepositoryResponse, status_code=status.HTTP_201_CREATED)
def create_repository(
    request: RepositoryCreateRequest,
    db: Session = Depends(get_db),
    audit_service: AuditService = Depends(get_audit_service),
    principal: Principal = Depends(require_policy("Admin")),
):
    duplicate = db.execute(select(RepositoryEntity.id).where(RepositoryEntity.name == request.name)).first()
    if duplicate:
        return _bad_request("Repository name already exists.")

    repo = RepositoryEntity(
        name=request.name,
        type=request.type,
        root_path=request.rootPath,
        git_url=request.gitUrl,
        git_branch=request.gitBranch,
        git_auth_secret_name=request.gitAuthSecretName,
    )

    db.add(repo)
    db.commit()
    db.refresh(repo)

    audit_service.record(principal.name, "repo.create", "repository", repo.id, request.model_dump())
    return repository_to_response(repo)


@router.post("/{repo_id}/sync")
def sync_repository(
    repo_id: UUID,
    db: Session = Depends(get_db),
    sync_service: RepoSyncService = Depends(get_repo_sync_service),
    _: Principal = Depends(require_policy("Admin")),
):
    repo = db.execute(select(RepositoryEntity).where(RepositoryEntity.id == repo_id)).scalar_one_or_none()
    if repo is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    success, output = sync_service.sync(repo)
    if success:
        return {"output": output}
    return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={"output": output})


@router.get("/{repo_id}/scripts", response_model=List[ScriptInfoResponse])
def list_scripts(
    repo_id: UUID,
    db: Session = Depends(get_db),
    repository_service: MigrationRepository = Depends(get_repo_service),
    _: Principal = Depends(require_policy("Viewer")),
) -> List[ScriptInfoResponse]:
    repo = db.execute(select(RepositoryEntity).where(RepositoryEntity.id == repo_id)).scalar_one_or_none()
    if repo is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    scripts = repository_service.list_scripts(repo.root_path)
    return [
        ScriptInfoResponse(
            path=item.path,
            type=item.type,
            version=item.version,
            description=item.description,
            checksum=item.checksum,
            sizeBytes=item.size_bytes,
            lastModified=item.last_modified,
        )
        for item in scripts
    ]


@router.get("/{repo_id}/script", response_model=ScriptContentResponse)
def read_script(
    repo_id: UUID,
    path: str = Query(...),
    db: Session = Depends(get_db),
    repository_service: MigrationRepository = Depends(get_repo_service),
    _: Principal = Depends(require_policy("Viewer")),
) -> ScriptContentResponse:
    repo = db.execute(select(RepositoryEntity).where(RepositoryEntity.id == repo_id)).scalar_one_or_none()
    if repo is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    try:
        content = repository_service.read_script(repo.root_path, path)
        checksum = repository_service.compute_checksum(repo.root_path, path)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    return ScriptContentResponse(path=path, checksum=checksum, content=content)


@router.get("/{repo_id}/diff", response_model=ScriptDiffResponse)
def diff_scripts(
    repo_id: UUID,
    left: str = Query(...),
    right: str = Query(...),
    db: Session = Depends(get_db),
    repository_service: MigrationRepository = Depends(get_repo_service),
    diff_service: DiffService = Depends(get_diff_service),
    _: Principal = Depends(require_policy("Viewer")),
) -> ScriptDiffResponse:
    repo = db.execute(select(RepositoryEntity).where(RepositoryEntity.id == repo_id)).scalar_one_or_none()
    if repo is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    try:
        left_content = repository_service.read_script(repo.root_path, left)
        right_content = repository_service.read_script(repo.root_path, right)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    diff_lines = diff_service.build_diff(left_content, right_content)
    return ScriptDiffResponse(leftPath=left, rightPath=right, diffLines=diff_lines)
