from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status

from app.api.dependencies import get_plan_review_service
from app.core.auth import Principal
from app.core.security import require_policy
from app.schemas.plan_review import PlanReviewRequest, PlanReviewResponse
from app.services.plan_review_service import PlanReviewService


router = APIRouter(tags=["plan-review"])


@router.post("/plan-review", response_model=PlanReviewResponse)
def review_plan(
    request: PlanReviewRequest,
    principal: Principal = Depends(require_policy("Operator")),
    service: PlanReviewService = Depends(get_plan_review_service),
) -> PlanReviewResponse:
    try:
        analysis = service.review(request, actor=principal.name)
    except RuntimeError as exc:
        message = str(exc)
        if "OpenAI is not configured" in message:
            code = status.HTTP_501_NOT_IMPLEMENTED
        else:
            code = status.HTTP_502_BAD_GATEWAY
        raise HTTPException(status_code=code, detail=message) from exc
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)) from exc

    return PlanReviewResponse(
        model=service.model,
        generatedAt=datetime.now(timezone.utc),
        analysis=analysis,
    )
