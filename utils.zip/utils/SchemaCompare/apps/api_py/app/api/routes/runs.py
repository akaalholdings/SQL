from __future__ import annotations

from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import Principal
from app.core.security import require_policy
from app.db.models import MigrationRunEntity, RunLogEntity
from app.db.session import get_db
from app.schemas.run import RunDetailResponse, RunLogItem, RunResponse
from app.services.mapping import run_to_response


router = APIRouter(prefix="/runs", tags=["runs"])


@router.get("", response_model=List[RunResponse])
def get_runs(
    db: Session = Depends(get_db),
    _: Principal = Depends(require_policy("Viewer")),
) -> List[RunResponse]:
    runs = (
        db.execute(select(MigrationRunEntity).order_by(MigrationRunEntity.started_at.desc()).limit(200))
        .scalars()
        .all()
    )
    return [run_to_response(item) for item in runs]


@router.get("/{run_id}", response_model=RunDetailResponse)
def get_run(
    run_id: UUID,
    db: Session = Depends(get_db),
    _: Principal = Depends(require_policy("Viewer")),
) -> RunDetailResponse:
    run = db.execute(select(MigrationRunEntity).where(MigrationRunEntity.id == run_id)).scalar_one_or_none()
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    logs = (
        db.execute(select(RunLogEntity).where(RunLogEntity.run_id == run_id).order_by(RunLogEntity.timestamp.asc()))
        .scalars()
        .all()
    )

    return RunDetailResponse(
        id=run.id,
        environmentId=run.environment_id,
        action=run.action,
        status=run.status,
        startedAt=run.started_at,
        finishedAt=run.finished_at,
        triggeredBy=run.triggered_by,
        pendingCount=run.pending_count,
        appliedCount=run.applied_count,
        driftDetected=run.drift_detected,
        output=run.output,
        outputJson=run.output_json,
        error=run.error,
        logs=[RunLogItem(timestamp=item.timestamp, level=item.level, message=item.message) for item in logs],
    )
