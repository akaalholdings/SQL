from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any, List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.dependencies import (
    get_audit_service,
    get_flyway_runner,
    get_lock_service,
    get_run_service,
    get_schema_service,
    get_status_service,
)
from app.core.auth import Principal
from app.core.config import get_settings
from app.core.security import require_policy
from app.db.models import EnvironmentEntity, RepositoryEntity
from app.db.session import get_db
from app.schemas.environment import (
    EnvironmentCreateRequest,
    EnvironmentResponse,
    EnvironmentStatusResponse,
    EnvironmentUpdateRequest,
    MigrationActionRequest,
    MigrationHistoryItem,
    MigrationHistoryResponse,
)
from app.schemas.schema import DatabaseSchemaResponse, EnvironmentRowCountsResponse
from app.services.audit_service import AuditService
from app.services.environment_status_service import EnvironmentStatusService
from app.services.flyway_runner import FlywayCommand, FlywayInfoResult, FlywayMigration, FlywayRunner
from app.services.lock_service import LockService
from app.services.mapping import environment_to_response
from app.services.run_service import RunService
from app.services.schema_service import DatabaseSchemaService


router = APIRouter(prefix="/environments", tags=["environments"])


def _bad_request(message: str) -> JSONResponse:
    return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={"error": message})


def _conflict(message: str) -> JSONResponse:
    return JSONResponse(status_code=status.HTTP_409_CONFLICT, content={"error": message})


def _to_history_item(migration: FlywayMigration) -> MigrationHistoryItem:
    return MigrationHistoryItem(
        version=migration.version,
        description=migration.description,
        type=migration.type,
        script=migration.script,
        checksum=migration.checksum,
        installedBy=migration.installed_by,
        installedOn=migration.installed_on,
        executionTimeMs=migration.execution_time,
        success=migration.success,
        state=migration.state,
    )


def _serialize_info(info: FlywayInfoResult) -> str:
    payload = {
        "schemaVersion": info.schema_version,
        "migrations": [
            {
                "category": item.category,
                "version": item.version,
                "description": item.description,
                "type": item.type,
                "script": item.script,
                "checksum": item.checksum,
                "installedBy": item.installed_by,
                "installedOn": item.installed_on.isoformat() if item.installed_on else None,
                "executionTime": item.execution_time,
                "success": item.success,
                "state": item.state,
            }
            for item in info.migrations
        ],
    }
    return json.dumps(payload)


def _find_environment(db: Session, env_id: UUID) -> EnvironmentEntity:
    env = db.execute(select(EnvironmentEntity).where(EnvironmentEntity.id == env_id)).scalar_one_or_none()
    if env is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    return env


def _find_repository(db: Session, repository_id: UUID) -> RepositoryEntity | None:
    return db.execute(select(RepositoryEntity).where(RepositoryEntity.id == repository_id)).scalar_one_or_none()


@router.get("", response_model=List[EnvironmentResponse])
def get_environments(
    db: Session = Depends(get_db),
    _: Principal = Depends(require_policy("Viewer")),
) -> List[EnvironmentResponse]:
    envs = db.execute(select(EnvironmentEntity).order_by(EnvironmentEntity.name.asc())).scalars().all()
    return [environment_to_response(item) for item in envs]


@router.get("/{env_id}", response_model=EnvironmentResponse)
def get_environment(
    env_id: UUID,
    db: Session = Depends(get_db),
    _: Principal = Depends(require_policy("Viewer")),
) -> EnvironmentResponse:
    env = _find_environment(db, env_id)
    return environment_to_response(env)


@router.get("/{env_id}/schema", response_model=DatabaseSchemaResponse)
def get_environment_schema(
    env_id: UUID,
    db: Session = Depends(get_db),
    schema_service: DatabaseSchemaService = Depends(get_schema_service),
    _: Principal = Depends(require_policy("Viewer")),
) -> DatabaseSchemaResponse:
    env = _find_environment(db, env_id)
    try:
        return schema_service.get_schema(env)
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)) from exc


@router.get("/{env_id}/row-counts", response_model=EnvironmentRowCountsResponse)
def get_environment_row_counts(
    env_id: UUID,
    db: Session = Depends(get_db),
    schema_service: DatabaseSchemaService = Depends(get_schema_service),
    _: Principal = Depends(require_policy("Viewer")),
) -> EnvironmentRowCountsResponse:
    env = _find_environment(db, env_id)
    try:
        return schema_service.get_row_counts(env)
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)) from exc


@router.post("", response_model=EnvironmentResponse, status_code=status.HTTP_201_CREATED)
def create_environment(
    request: EnvironmentCreateRequest,
    db: Session = Depends(get_db),
    audit_service: AuditService = Depends(get_audit_service),
    principal: Principal = Depends(require_policy("Admin")),
):
    settings = get_settings()

    if _find_repository(db, request.repositoryId) is None:
        return _bad_request("Repository not found.")

    if request.authMode.lower() == "sql" and not settings.security_allow_sql_auth:
        return _bad_request("SQL authentication is disabled by policy.")

    duplicate = db.execute(select(EnvironmentEntity.id).where(EnvironmentEntity.name == request.name)).first()
    if duplicate:
        return _bad_request("Environment name already exists.")

    now = datetime.now(timezone.utc)
    env = EnvironmentEntity(
        name=request.name,
        type=request.type,
        server=request.server,
        database=request.database,
        schema=request.schema or "dbo",
        auth_mode=request.authMode,
        jdbc_url=request.jdbcUrl,
        user=request.user,
        password_secret_name=request.passwordSecretName,
        tags_json=None if request.tags is None else json.dumps(request.tags),
        owner=request.owner,
        repository_id=request.repositoryId,
        history_table=request.historyTable or "flyway_schema_history",
        created_at=now,
        updated_at=now,
    )

    db.add(env)
    db.commit()
    db.refresh(env)

    audit_service.record(principal.name, "environment.create", "environment", env.id, request.model_dump())
    return environment_to_response(env)


@router.put("/{env_id}", response_model=EnvironmentResponse)
def update_environment(
    env_id: UUID,
    request: EnvironmentUpdateRequest,
    db: Session = Depends(get_db),
    audit_service: AuditService = Depends(get_audit_service),
    principal: Principal = Depends(require_policy("Admin")),
):
    settings = get_settings()
    env = _find_environment(db, env_id)

    if _find_repository(db, request.repositoryId) is None:
        return _bad_request("Repository not found.")

    if request.authMode.lower() == "sql" and not settings.security_allow_sql_auth:
        return _bad_request("SQL authentication is disabled by policy.")

    duplicate = db.execute(
        select(EnvironmentEntity.id).where(EnvironmentEntity.name == request.name, EnvironmentEntity.id != env_id)
    ).first()
    if duplicate:
        return _bad_request("Environment name already exists.")

    env.name = request.name
    env.type = request.type
    env.server = request.server
    env.database = request.database
    env.schema = request.schema or "dbo"
    env.auth_mode = request.authMode
    env.jdbc_url = request.jdbcUrl
    env.user = request.user
    env.password_secret_name = request.passwordSecretName
    env.repository_id = request.repositoryId
    env.history_table = request.historyTable or "flyway_schema_history"
    env.tags_json = None if request.tags is None else json.dumps(request.tags)
    env.owner = request.owner
    env.is_active = request.isActive
    env.updated_at = datetime.now(timezone.utc)

    db.add(env)
    db.commit()
    db.refresh(env)

    audit_service.record(principal.name, "environment.update", "environment", env.id, request.model_dump())
    return environment_to_response(env)


@router.post("/{env_id}/test-connection")
def test_environment_connection(
    env_id: UUID,
    db: Session = Depends(get_db),
    schema_service: DatabaseSchemaService = Depends(get_schema_service),
    audit_service: AuditService = Depends(get_audit_service),
    principal: Principal = Depends(require_policy("Operator")),
):
    env = _find_environment(db, env_id)
    try:
        schema_service.test_connection(env)
        audit_service.record(principal.name, "environment.test_connection", "environment", env.id, {"success": True})
        return {"success": True, "message": "Connection successful."}
    except Exception as exc:
        audit_service.record(
            principal.name,
            "environment.test_connection",
            "environment",
            env.id,
            {"success": False, "error": str(exc)},
        )
        return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={"success": False, "error": str(exc)})


@router.get("/{env_id}/status", response_model=EnvironmentStatusResponse)
def get_environment_status(
    env_id: UUID,
    db: Session = Depends(get_db),
    status_service: EnvironmentStatusService = Depends(get_status_service),
    _: Principal = Depends(require_policy("Viewer")),
) -> EnvironmentStatusResponse:
    env = _find_environment(db, env_id)
    repo = _find_repository(db, env.repository_id)
    if repo is None:
        return _bad_request("Repository not found.")
    return status_service.get_status(env, repo)


@router.post("/{env_id}/validate")
def validate_environment(
    env_id: UUID,
    db: Session = Depends(get_db),
    lock_service: LockService = Depends(get_lock_service),
    flyway_runner: FlywayRunner = Depends(get_flyway_runner),
    run_service: RunService = Depends(get_run_service),
    audit_service: AuditService = Depends(get_audit_service),
    principal: Principal = Depends(require_policy("Operator")),
):
    env = _find_environment(db, env_id)
    repo = _find_repository(db, env.repository_id)
    if repo is None:
        return _bad_request("Repository not found.")

    settings = get_settings()
    lock_handle = lock_service.try_acquire(env.id, principal.name, timedelta(minutes=settings.locks_timeout_minutes))
    if lock_handle is None:
        return _conflict("Another migration run is in progress.")

    run = run_service.start_run(env.id, "validate", principal.name, None)

    try:
        result = flyway_runner.run(FlywayCommand.VALIDATE, env, repo)
        drift_detected = result.exit_code != 0
        env.last_validated_at = datetime.now(timezone.utc)
        env.last_validation_drift = drift_detected
        env.last_validation_output = f"{result.std_out}{result.std_err}"
        env.updated_at = datetime.now(timezone.utc)
        db.add(env)
        db.commit()

        run_service.complete_run(
            run,
            "failed" if drift_detected else "succeeded",
            result.std_out,
            None,
            result.std_err,
            None,
            None,
            drift_detected,
        )
        audit_service.record(principal.name, "environment.validate", "environment", env.id, {"driftDetected": drift_detected})

        return {
            "driftDetected": drift_detected,
            "output": result.std_out,
            "error": result.std_err,
            "runId": str(run.id),
        }
    except Exception as exc:
        run_service.complete_run(run, "failed", None, None, str(exc), None, None, True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)) from exc
    finally:
        lock_handle.close()


@router.post("/{env_id}/plan")
def plan_environment(
    env_id: UUID,
    db: Session = Depends(get_db),
    lock_service: LockService = Depends(get_lock_service),
    flyway_runner: FlywayRunner = Depends(get_flyway_runner),
    run_service: RunService = Depends(get_run_service),
    principal: Principal = Depends(require_policy("Operator")),
):
    env = _find_environment(db, env_id)
    repo = _find_repository(db, env.repository_id)
    if repo is None:
        return _bad_request("Repository not found.")

    settings = get_settings()
    lock_handle = lock_service.try_acquire(env.id, principal.name, timedelta(minutes=settings.locks_timeout_minutes))
    if lock_handle is None:
        return _conflict("Another migration run is in progress.")

    run = run_service.start_run(env.id, "plan", principal.name, None)

    try:
        info = flyway_runner.info(env, repo)
        pending = [item for item in info.migrations if (item.state or "").lower() == "pending"]
        applied = [item for item in info.migrations if (item.state or "").lower() == "success"]

        run_service.complete_run(run, "succeeded", None, _serialize_info(info), None, len(pending), len(applied), None)

        return {
            "runId": str(run.id),
            "pending": [_to_history_item(item).model_dump() for item in pending],
            "appliedCount": len(applied),
        }
    except Exception as exc:
        run_service.complete_run(run, "failed", None, None, str(exc), None, None, None)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)) from exc
    finally:
        lock_handle.close()


@router.post("/{env_id}/migrate")
def migrate_environment(
    env_id: UUID,
    request: MigrationActionRequest,
    db: Session = Depends(get_db),
    lock_service: LockService = Depends(get_lock_service),
    flyway_runner: FlywayRunner = Depends(get_flyway_runner),
    run_service: RunService = Depends(get_run_service),
    audit_service: AuditService = Depends(get_audit_service),
    principal: Principal = Depends(require_policy("Operator")),
):
    env = _find_environment(db, env_id)

    if env.type.lower() == "prod":
        if "Admin" not in principal.roles:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

        if not request.confirmation or request.confirmation.lower() != env.database.lower():
            return _bad_request("Prod migrations require confirmation matching the database name.")

    repo = _find_repository(db, env.repository_id)
    if repo is None:
        return _bad_request("Repository not found.")

    settings = get_settings()
    lock_handle = lock_service.try_acquire(env.id, principal.name, timedelta(minutes=settings.locks_timeout_minutes))
    if lock_handle is None:
        return _conflict("Another migration run is in progress.")

    run = run_service.start_run(env.id, "migrate", principal.name, request.confirmation)

    try:
        result = flyway_runner.run(FlywayCommand.MIGRATE, env, repo)
        info = flyway_runner.info(env, repo)
        pending = sum(1 for item in info.migrations if (item.state or "").lower() == "pending")
        applied = sum(1 for item in info.migrations if (item.state or "").lower() == "success")

        run_service.complete_run(
            run,
            "succeeded" if result.exit_code == 0 else "failed",
            result.std_out,
            _serialize_info(info),
            result.std_err,
            pending,
            applied,
            None,
        )
        audit_service.record(principal.name, "environment.migrate", "environment", env.id, {"exitCode": result.exit_code})

        return {
            "runId": str(run.id),
            "exitCode": result.exit_code,
            "output": result.std_out,
            "error": result.std_err,
            "pendingCount": pending,
            "appliedCount": applied,
        }
    except Exception as exc:
        run_service.complete_run(run, "failed", None, None, str(exc), None, None, None)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)) from exc
    finally:
        lock_handle.close()


@router.post("/{env_id}/repair")
def repair_environment(
    env_id: UUID,
    request: MigrationActionRequest,
    db: Session = Depends(get_db),
    lock_service: LockService = Depends(get_lock_service),
    flyway_runner: FlywayRunner = Depends(get_flyway_runner),
    run_service: RunService = Depends(get_run_service),
    audit_service: AuditService = Depends(get_audit_service),
    principal: Principal = Depends(require_policy("Admin")),
):
    env = _find_environment(db, env_id)

    if env.type.lower() == "prod":
        if not request.confirmation or request.confirmation.lower() != env.database.lower():
            return _bad_request("Prod repair requires confirmation matching the database name.")

    repo = _find_repository(db, env.repository_id)
    if repo is None:
        return _bad_request("Repository not found.")

    settings = get_settings()
    lock_handle = lock_service.try_acquire(env.id, principal.name, timedelta(minutes=settings.locks_timeout_minutes))
    if lock_handle is None:
        return _conflict("Another migration run is in progress.")

    run = run_service.start_run(env.id, "repair", principal.name, request.confirmation)

    try:
        result = flyway_runner.run(FlywayCommand.REPAIR, env, repo)
        run_service.complete_run(
            run,
            "succeeded" if result.exit_code == 0 else "failed",
            result.std_out,
            None,
            result.std_err,
            None,
            None,
            None,
        )
        audit_service.record(principal.name, "environment.repair", "environment", env.id, {"exitCode": result.exit_code})
        return {"runId": str(run.id), "output": result.std_out, "error": result.std_err}
    except Exception as exc:
        run_service.complete_run(run, "failed", None, None, str(exc), None, None, None)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)) from exc
    finally:
        lock_handle.close()


@router.post("/{env_id}/baseline")
def baseline_environment(
    env_id: UUID,
    request: MigrationActionRequest,
    db: Session = Depends(get_db),
    lock_service: LockService = Depends(get_lock_service),
    flyway_runner: FlywayRunner = Depends(get_flyway_runner),
    run_service: RunService = Depends(get_run_service),
    audit_service: AuditService = Depends(get_audit_service),
    principal: Principal = Depends(require_policy("Admin")),
):
    env = _find_environment(db, env_id)

    if env.type.lower() == "prod":
        if not request.confirmation or request.confirmation.lower() != env.database.lower():
            return _bad_request("Prod baseline requires confirmation matching the database name.")

    repo = _find_repository(db, env.repository_id)
    if repo is None:
        return _bad_request("Repository not found.")

    settings = get_settings()
    lock_handle = lock_service.try_acquire(env.id, principal.name, timedelta(minutes=settings.locks_timeout_minutes))
    if lock_handle is None:
        return _conflict("Another migration run is in progress.")

    run = run_service.start_run(env.id, "baseline", principal.name, request.confirmation)

    try:
        result = flyway_runner.run(FlywayCommand.BASELINE, env, repo)
        run_service.complete_run(
            run,
            "succeeded" if result.exit_code == 0 else "failed",
            result.std_out,
            None,
            result.std_err,
            None,
            None,
            None,
        )
        audit_service.record(principal.name, "environment.baseline", "environment", env.id, {"exitCode": result.exit_code})
        return {"runId": str(run.id), "output": result.std_out, "error": result.std_err}
    except Exception as exc:
        run_service.complete_run(run, "failed", None, None, str(exc), None, None, None)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)) from exc
    finally:
        lock_handle.close()


@router.get("/{env_id}/history", response_model=MigrationHistoryResponse)
def get_environment_history(
    env_id: UUID,
    db: Session = Depends(get_db),
    flyway_runner: FlywayRunner = Depends(get_flyway_runner),
    _: Principal = Depends(require_policy("Viewer")),
) -> MigrationHistoryResponse:
    env = _find_environment(db, env_id)
    repo = _find_repository(db, env.repository_id)
    if repo is None:
        return _bad_request("Repository not found.")

    info = flyway_runner.info(env, repo)
    applied = [_to_history_item(item) for item in info.migrations if (item.state or "").lower() == "success"]
    pending = [_to_history_item(item) for item in info.migrations if (item.state or "").lower() == "pending"]

    return MigrationHistoryResponse(environmentId=env.id, applied=applied, pending=pending)
