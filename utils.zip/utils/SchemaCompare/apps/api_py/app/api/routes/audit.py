from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.auth import Principal
from app.core.security import require_policy
from app.db.models import AuditEventEntity
from app.db.session import get_db


router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("")
def get_audit(
    db: Session = Depends(get_db),
    _: Principal = Depends(require_policy("Admin")),
) -> List[dict]:
    events = db.execute(select(AuditEventEntity).order_by(AuditEventEntity.occurred_at.desc()).limit(200)).scalars().all()
    return [
        {
            "id": str(item.id),
            "actor": item.actor,
            "action": item.action,
            "entityType": item.entity_type,
            "entityId": None if item.entity_id is None else str(item.entity_id),
            "occurredAt": item.occurred_at,
            "detailsJson": item.details_json,
        }
        for item in events
    ]
