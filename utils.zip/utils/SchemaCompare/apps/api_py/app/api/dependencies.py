from __future__ import annotations

from functools import lru_cache

from fastapi import Depends
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.session import get_db, get_engine
from app.services.audit_service import AuditService
from app.services.diff_service import DiffService
from app.services.environment_status_service import EnvironmentStatusService
from app.services.flyway_runner import FlywayRunner
from app.services.lock_service import LockService
from app.services.repo_service import MigrationRepository, RepoSyncService
from app.services.run_service import RunService
from app.services.schema_service import DatabaseSchemaService
from app.services.secret_provider import SecretProvider, build_secret_provider


@lru_cache(maxsize=1)
def get_secret_provider() -> SecretProvider:
    return build_secret_provider()


@lru_cache(maxsize=1)
def get_diff_service() -> DiffService:
    return DiffService()


@lru_cache(maxsize=1)
def get_repo_service() -> MigrationRepository:
    return MigrationRepository()


@lru_cache(maxsize=1)
def get_repo_sync_service() -> RepoSyncService:
    return RepoSyncService()


@lru_cache(maxsize=1)
def get_lock_service() -> LockService:
    return LockService(get_engine())


@lru_cache(maxsize=1)
def get_plan_review_service():
    from app.services.plan_review_service import PlanReviewService

    return PlanReviewService(get_settings())


def get_flyway_runner(secret_provider: SecretProvider = Depends(get_secret_provider)) -> FlywayRunner:
    return FlywayRunner(secret_provider)


def get_schema_service(secret_provider: SecretProvider = Depends(get_secret_provider)) -> DatabaseSchemaService:
    return DatabaseSchemaService(secret_provider)


def get_status_service(flyway_runner: FlywayRunner = Depends(get_flyway_runner)) -> EnvironmentStatusService:
    return EnvironmentStatusService(flyway_runner)


def get_run_service(db: Session = Depends(get_db)) -> RunService:
    return RunService(db)


def get_audit_service(db: Session = Depends(get_db)) -> AuditService:
    return AuditService(db)
