from __future__ import annotations

import json

from app.db.models import EnvironmentEntity, MigrationRunEntity, RepositoryEntity
from app.schemas.environment import EnvironmentResponse
from app.schemas.repository import RepositoryResponse
from app.schemas.run import RunResponse


def environment_to_response(entity: EnvironmentEntity) -> EnvironmentResponse:
    tags = None
    if entity.tags_json:
        try:
            loaded = json.loads(entity.tags_json)
            if isinstance(loaded, dict):
                tags = {str(k): str(v) for k, v in loaded.items()}
        except json.JSONDecodeError:
            tags = None

    return EnvironmentResponse(
        id=entity.id,
        name=entity.name,
        type=entity.type,
        server=entity.server,
        database=entity.database,
        schema=entity.schema,
        authMode=entity.auth_mode,
        jdbcUrl=entity.jdbc_url,
        user=entity.user,
        passwordSecretName=entity.password_secret_name,
        repositoryId=entity.repository_id,
        historyTable=entity.history_table,
        isActive=entity.is_active,
        tags=tags,
        owner=entity.owner,
        createdAt=entity.created_at,
        updatedAt=entity.updated_at,
        lastValidatedAt=entity.last_validated_at,
        lastValidationDrift=entity.last_validation_drift,
    )


def repository_to_response(entity: RepositoryEntity) -> RepositoryResponse:
    return RepositoryResponse(
        id=entity.id,
        name=entity.name,
        type=entity.type,
        rootPath=entity.root_path,
        gitUrl=entity.git_url,
        gitBranch=entity.git_branch,
        createdAt=entity.created_at,
        updatedAt=entity.updated_at,
    )


def run_to_response(entity: MigrationRunEntity) -> RunResponse:
    return RunResponse(
        id=entity.id,
        environmentId=entity.environment_id,
        action=entity.action,
        status=entity.status,
        startedAt=entity.started_at,
        finishedAt=entity.finished_at,
        triggeredBy=entity.triggered_by,
        pendingCount=entity.pending_count,
        appliedCount=entity.applied_count,
        driftDetected=entity.drift_detected,
        error=entity.error,
    )
