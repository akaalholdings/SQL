from __future__ import annotations

import json
from collections import Counter
from typing import Any, Dict, List, Optional

from app.core.config import Settings
from app.schemas.plan_review import PlanReviewNode, PlanReviewRequest


class PlanReviewService:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._client = None

    @property
    def model(self) -> str:
        return self._settings.openai_model

    def review(self, request: PlanReviewRequest, actor: str) -> str:
        if not self._settings.openai_api_key:
            raise RuntimeError("OpenAI is not configured. Set OPENAI_API_KEY to enable AI plan review.")

        request = self._sanitize_request(request)

        query_plan = (request.queryPlan or "").strip()
        provided_plan_xml = bool(query_plan)
        if not query_plan:
            summary = self._build_summary(request)
            query_plan = json.dumps(summary, indent=2)

        # Keep costs predictable and avoid accidentally uploading huge plans.
        max_chars = 200_000 if provided_plan_xml else 1_000_000
        if len(query_plan) > max_chars:
            raise RuntimeError(
                f"Query plan is too large to analyze ({len(query_plan):,} chars). Limit is {max_chars:,} chars."
            )

        user_prompt = _PROMPT_TEMPLATE.replace("{{QUERY_PLAN}}", query_plan)

        system_prompt = (
            "Follow the user's instructions exactly. "
            "Do not output any scratchpad or hidden reasoning. "
            "Output ONLY the content within the <analysis> tags as specified."
        )

        text = self._call_openai(system_prompt=system_prompt, user_prompt=user_prompt)
        return _ensure_wrapped_analysis(text.strip())

    def _sanitize_request(self, request: PlanReviewRequest) -> PlanReviewRequest:
        # Server-side cap to prevent huge payloads from blowing up memory/costs.
        MAX_NODES = 600
        nodes_all = list(request.nodes or [])
        if len(nodes_all) <= MAX_NODES:
            return request

        def score(node: PlanReviewNode) -> float:
            value = getattr(node, "estimatedTotalSubtreeCost", None)
            if value is None:
                return 0.0
            try:
                return float(value)
            except (TypeError, ValueError):
                return 0.0

        nodes = sorted(nodes_all, key=score, reverse=True)[:MAX_NODES]
        return PlanReviewRequest(
            fileName=request.fileName,
            statementText=request.statementText,
            queryPlan=request.queryPlan,
            nodeCount=request.nodeCount,
            hasActualRows=request.hasActualRows,
            nodes=nodes,
        )

    def _build_summary(self, request: PlanReviewRequest) -> Dict[str, Any]:
        statement_text = (request.statementText or "").strip()
        if len(statement_text) > 4000:
            statement_text = statement_text[:4000] + "…"

        nodes = request.nodes
        total_nodes = request.nodeCount or len(nodes)

        physical_ops = Counter((n.physicalOp or "Unknown").strip() for n in nodes)
        logical_ops = Counter((n.logicalOp or "Unknown").strip() for n in nodes)

        warnings: List[str] = []
        for n in nodes:
            for w in n.warnings or []:
                if w and w not in warnings:
                    warnings.append(w)

        top_subtree = self._top_nodes(nodes, key="estimatedTotalSubtreeCost", limit=25)
        top_operator = self._top_nodes(nodes, key="estimatedOperatorCost", limit=25)

        patterns = {
            "tableScans": self._find_nodes(nodes, contains_any=["table scan"]),
            "indexScans": self._find_nodes(nodes, contains_any=["index scan"]),
            "keyLookups": self._find_nodes(nodes, contains_any=["key lookup", "rid lookup"]),
            "sorts": self._find_nodes(nodes, contains_any=["sort"]),
            "hashMatches": self._find_nodes(nodes, contains_any=["hash match"]),
            "nestedLoops": self._find_nodes(nodes, contains_any=["nested loops"]),
            "mergeJoins": self._find_nodes(nodes, contains_any=["merge join"]),
            "spools": self._find_nodes(nodes, contains_any=["spool"]),
            "parallelism": self._find_nodes(nodes, contains_any=["parallelism"]),
        }

        return {
            "fileName": request.fileName,
            "hasActualRows": request.hasActualRows,
            "nodeCount": total_nodes,
            "statementText": statement_text or None,
            "warnings": warnings,
            "opCounts": {
                "physical": physical_ops.most_common(25),
                "logical": logical_ops.most_common(25),
            },
            "topNodes": {
                "bySubtreeCost": top_subtree,
                "byOperatorCost": top_operator,
            },
            "patterns": patterns,
        }

    def _node_compact(self, node: PlanReviewNode) -> Dict[str, Any]:
        obj = node.object.model_dump() if node.object is not None else None
        return {
            "nodeId": node.nodeId,
            "physicalOp": node.physicalOp,
            "logicalOp": node.logicalOp,
            "estimatedRows": node.estimatedRows,
            "actualRows": node.actualRows,
            "estimatedTotalSubtreeCost": node.estimatedTotalSubtreeCost,
            "estimatedOperatorCost": node.estimatedOperatorCost,
            "object": obj,
            "warnings": node.warnings,
        }

    def _top_nodes(self, nodes: List[PlanReviewNode], key: str, limit: int) -> List[Dict[str, Any]]:
        def score(n: PlanReviewNode) -> float:
            value = getattr(n, key, None)
            if value is None:
                return 0.0
            try:
                return float(value)
            except (TypeError, ValueError):
                return 0.0

        picked = sorted(nodes, key=score, reverse=True)[:limit]
        return [self._node_compact(n) for n in picked]

    def _find_nodes(self, nodes: List[PlanReviewNode], contains_any: List[str], limit: int = 30) -> List[Dict[str, Any]]:
        matches: List[PlanReviewNode] = []
        needles = [n.lower() for n in contains_any]

        for node in nodes:
            hay = " ".join([node.physicalOp or "", node.logicalOp or ""]).lower()
            if any(needle in hay for needle in needles):
                matches.append(node)

        return [self._node_compact(n) for n in matches[:limit]]

    def _call_openai(self, system_prompt: str, user_prompt: str) -> str:
        try:
            # OpenAI Python SDK (v1+ / v2+). Keep imports here so the API still starts without the dependency installed.
            from openai import OpenAI  # type: ignore

            if self._client is None:
                self._client = OpenAI(api_key=self._settings.openai_api_key)

            reasoning = _build_reasoning(self._settings.openai_reasoning_effort)

            kwargs: Dict[str, Any] = {
                "model": self._settings.openai_model,
                "input": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                "max_output_tokens": self._settings.openai_max_output_tokens,
            }

            # Some reasoning models reject sampling params like temperature.
            model_lower = (self._settings.openai_model or "").lower()
            if not (model_lower.startswith("gpt-5") or model_lower.startswith("o")):
                kwargs["temperature"] = 0.2

            if reasoning is not None:
                kwargs["reasoning"] = reasoning

            response = self._client.responses.create(**kwargs)

            output_text: Optional[str] = getattr(response, "output_text", None)
            if output_text:
                return output_text

            # Fallback: attempt to locate the first text block in the response structure.
            output = getattr(response, "output", None)
            if isinstance(output, list):
                for item in output:
                    content = item.get("content") if isinstance(item, dict) else getattr(item, "content", None)
                    if not content:
                        continue
                    for part in content:
                        text = part.get("text") if isinstance(part, dict) else getattr(part, "text", None)
                        if text:
                            return str(text)

            raise RuntimeError("OpenAI response contained no text output.")
        except Exception as exc:
            guidance = ""
            exc_text = str(exc)
            if self._settings.openai_reasoning_effort and (
                "reasoning" in exc_text.lower() or "effort" in exc_text.lower() or "o-series" in exc_text.lower()
            ):
                guidance = " If this model does not support reasoning, unset OPENAI_REASONING_EFFORT or switch OPENAI_MODEL."
            raise RuntimeError(f"OpenAI request failed: {exc}{guidance}") from exc


def _ensure_wrapped_analysis(text: str) -> str:
    if "<analysis>" in text and "</analysis>" in text:
        return text
    return f"<analysis>\n{text}\n</analysis>\n"


def _build_reasoning(effort: str) -> Dict[str, Any] | None:
    value = (effort or "").strip().lower()
    if not value:
        return None

    allowed = {"none", "minimal", "low", "medium", "high", "xhigh"}
    if value not in allowed:
        raise RuntimeError(
            f"Invalid OPENAI_REASONING_EFFORT='{effort}'. Allowed: {', '.join(sorted(allowed))}."
        )

    return {"effort": value}


_PROMPT_TEMPLATE = """You will be acting as a database performance analyst reviewing SQL query execution plans or XML query representations. Your goal is to provide an in-depth technical review for developers and engineering teams.

Here is the query plan or XML to analyze:

<query_plan>
{{QUERY_PLAN}}
</query_plan>

Your task is to:

1. **Understand and explain what the query is doing**: Analyze the query plan to determine the query's purpose, what data it's accessing, and how it's processing that data. Explain this in clear terms that developers can understand.

2. **Identify performance issues**: Look for common problems such as:
   - Full table scans on large tables
   - Missing or unused indexes
   - Expensive operations (sorts, nested loops on large datasets, hash joins)
   - High cardinality estimates or estimation errors
   - Implicit conversions
   - Excessive data movement or spooling
   - Blocking operators
   - Parallelism issues (too much or too little)
   - Suboptimal join orders or join types

3. **Provide quantified, actionable suggestions**: For each issue identified, provide specific recommendations with estimated impact where possible. Include:
   - What index to create (with specific columns)
   - What query rewrites to consider
   - What statistics to update
   - Expected performance improvements (e.g., "could reduce rows scanned from 1M to 100K")

<analysis>

<query_explanation>
Provide a clear explanation of what the query is doing, written for a developer audience. Include:
- The main purpose/goal of the query
- Key tables and joins involved
- Major operations being performed
- Overall execution flow
</query_explanation>

<issues_identified>
List each performance issue you've identified. For each issue:
- Describe the problem clearly
- Explain why it's problematic
- Quantify the impact where possible (rows affected, estimated cost, etc.)
Number each issue for easy reference.
</issues_identified>

<recommendations>
For each issue identified above, provide specific, actionable recommendations:
- What exactly needs to be changed
- How to implement the change (specific SQL for index creation, query rewrites, etc.)
- Expected performance improvement
- Priority level (Critical/High/Medium/Low)
Number recommendations to correspond with the issues they address.
</recommendations>

</analysis>

Important: Your final output should contain only the content within the <analysis> tags as specified above. Focus on being specific, quantified, and actionable in your recommendations rather than generic advice.
"""
