from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.models import EnvironmentEntity, RepositoryEntity


class AppSeeder:
    def __init__(self, db: Session) -> None:
        self._db = db
        self._settings = get_settings()

    def seed(self) -> None:
        if not self._settings.seed_enabled:
            return

        has_repo = self._db.execute(select(RepositoryEntity.id).limit(1)).first()
        if has_repo:
            return

        repo = RepositoryEntity(
            name="sample-migrations",
            type="local",
            root_path=self._settings.seed_repo_root,
        )
        self._db.add(repo)
        self._db.commit()
        self._db.refresh(repo)

        env = EnvironmentEntity(
            name="dev-local",
            type="dev",
            server="targetdb",
            database="TargetDb",
            schema="dbo",
            auth_mode="sql",
            jdbc_url="jdbc:sqlserver://targetdb:1433;databaseName=TargetDb;encrypt=false;trustServerCertificate=true;",
            user="sa",
            password_secret_name="local-sa-password",
            repository_id=repo.id,
            history_table="flyway_schema_history",
        )
        self._db.add(env)
        self._db.commit()
