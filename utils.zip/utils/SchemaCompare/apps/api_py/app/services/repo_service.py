from __future__ import annotations

import hashlib
import os
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Tuple

from app.db.models import RepositoryEntity


@dataclass
class ScriptInfo:
    path: str
    type: str
    version: Optional[str]
    description: str
    checksum: str
    size_bytes: int
    last_modified: datetime


class MigrationRepository:
    def list_scripts(self, root_path: str) -> List[ScriptInfo]:
        scripts: List[ScriptInfo] = []
        root = Path(root_path).resolve()
        # Keep the link-path for user-facing paths like "sql/versioned/V001__init.sql",
        # but validate using resolved paths to avoid symlink/traversal issues.
        sql_root_link = root / "sql"
        if not sql_root_link.exists() or not sql_root_link.is_dir():
            return scripts

        sql_root_resolved = sql_root_link.resolve()

        for file_path in sorted(sql_root_link.rglob("*.sql")):
            if not file_path.is_file():
                continue
            resolved = file_path.resolve()
            try:
                resolved.relative_to(root)
                resolved.relative_to(sql_root_resolved)
            except ValueError:
                continue

            relative_path = file_path.relative_to(root).as_posix()
            file_name = resolved.name
            migration_type, version, description = self._parse_migration_file(file_name, relative_path)
            checksum = self._compute_checksum_internal(resolved)
            stat = resolved.stat()
            scripts.append(
                ScriptInfo(
                    path=relative_path,
                    type=migration_type,
                    version=version,
                    description=description,
                    checksum=checksum,
                    size_bytes=stat.st_size,
                    last_modified=datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc),
                )
            )

        return sorted(scripts, key=lambda item: (item.type, item.version or "", item.path))

    def read_script(self, root_path: str, path: str) -> str:
        full_path = self._resolve_path(root_path, path)
        return full_path.read_text(encoding="utf-8")

    def compute_checksum(self, root_path: str, path: str) -> str:
        full_path = self._resolve_path(root_path, path)
        return self._compute_checksum_internal(full_path)

    def _resolve_path(self, root_path: str, path: str) -> Path:
        root = Path(root_path).resolve()
        sql_root = (root / "sql").resolve()
        full_path = (root / path).resolve()
        try:
            full_path.relative_to(sql_root)
        except ValueError as exc:
            raise ValueError("Invalid path.") from exc
        if full_path.suffix.lower() != ".sql":
            raise ValueError("Invalid path.")
        if not full_path.exists() or not full_path.is_file():
            raise FileNotFoundError("Script not found.")
        return full_path

    @staticmethod
    def _parse_migration_file(file_name: str, relative_path: str) -> Tuple[str, Optional[str], str]:
        if file_name.lower().startswith("v"):
            parts = [part for part in file_name.split("__") if part]
            version = parts[0][1:] if parts else None
            desc = parts[1] if len(parts) > 1 else file_name
            desc = desc.removesuffix(".sql").replace("_", " ")
            return "versioned", version, desc

        if file_name.lower().startswith("r__"):
            desc = file_name[3:].removesuffix(".sql").replace("_", " ")
            return "repeatable", None, desc

        return "other", None, relative_path

    @staticmethod
    def _compute_checksum_internal(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(8192), b""):
                digest.update(chunk)
        return digest.hexdigest()


class RepoSyncService:
    def sync(self, repository: RepositoryEntity) -> tuple[bool, str]:
        if repository.type.lower() != "git":
            return False, "Repository is not git-backed."

        if not repository.root_path:
            return False, "Repository root path is required."

        args = ["git", "pull"]
        if repository.git_branch:
            args.extend(["origin", repository.git_branch])

        result = subprocess.run(
            args,
            cwd=repository.root_path,
            capture_output=True,
            text=True,
            check=False,
        )

        output = "\n".join([line for line in [result.stdout, result.stderr] if line]).strip()
        return result.returncode == 0, output
