from __future__ import annotations

import difflib
from typing import List


class DiffService:
    def build_diff(self, left: str, right: str) -> List[str]:
        lines: List[str] = []
        for line in difflib.ndiff((left or "").splitlines(), (right or "").splitlines()):
            prefix = line[:2]
            content = line[2:]
            if prefix == "? ":
                continue
            if prefix == "+ ":
                lines.append(f"+ {content}")
            elif prefix == "- ":
                lines.append(f"- {content}")
            else:
                lines.append(f"  {content}")
        return lines
