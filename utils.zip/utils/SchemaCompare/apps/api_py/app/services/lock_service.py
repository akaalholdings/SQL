from __future__ import annotations

import math
import threading
import time
import uuid
from datetime import timedelta
from typing import Optional
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.engine import Engine


class EnvironmentLockHandle:
    def __init__(self, service: "LockService", environment_id: UUID, lock_token: str, ttl: timedelta) -> None:
        self._service = service
        self._environment_id = environment_id
        self._lock_token = lock_token
        self._ttl = ttl
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._thread.start()

    def _heartbeat_loop(self) -> None:
        interval_seconds = max(60, int(self._ttl.total_seconds() / 2))
        while not self._stop_event.wait(interval_seconds):
            try:
                self._service.refresh(self._environment_id, self._lock_token, self._ttl)
            except Exception:
                # Ignore heartbeat failures; lock may still be valid.
                continue

    def close(self) -> None:
        self._stop_event.set()
        self._thread.join(timeout=2)
        self._service.release(self._environment_id, self._lock_token)


class LockService:
    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def try_acquire(self, environment_id: UUID, locked_by: str, ttl: timedelta) -> Optional[EnvironmentLockHandle]:
        token = uuid.uuid4().hex
        ttl_minutes = int(math.ceil(ttl.total_seconds() / 60))

        query = text(
            """
MERGE environment_locks WITH (HOLDLOCK) AS target
USING (SELECT :EnvId AS EnvironmentId) AS source
ON target.EnvironmentId = source.EnvironmentId
WHEN MATCHED AND (target.LockExpiresAt IS NULL OR target.LockExpiresAt < SYSUTCDATETIME())
    THEN UPDATE SET LockToken=:Token, LockedBy=:LockedBy, LockedAt=SYSUTCDATETIME(), LockExpiresAt=DATEADD(minute, :TtlMinutes, SYSUTCDATETIME())
WHEN NOT MATCHED
    THEN INSERT (EnvironmentId, LockToken, LockedBy, LockedAt, LockExpiresAt)
         VALUES (:EnvId, :Token, :LockedBy, SYSUTCDATETIME(), DATEADD(minute, :TtlMinutes, SYSUTCDATETIME()))
OUTPUT $action;
"""
        )

        with self._engine.begin() as connection:
            connection.exec_driver_sql("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;")
            result = connection.execute(
                query,
                {
                    "EnvId": str(environment_id),
                    "Token": token,
                    "LockedBy": locked_by,
                    "TtlMinutes": ttl_minutes,
                },
            )
            action = result.scalar_one_or_none()

        if action is None:
            return None

        return EnvironmentLockHandle(self, environment_id, token, ttl)

    def refresh(self, environment_id: UUID, lock_token: str, ttl: timedelta) -> None:
        ttl_minutes = int(math.ceil(ttl.total_seconds() / 60))
        query = text(
            """
UPDATE environment_locks
SET LockExpiresAt = DATEADD(minute, :TtlMinutes, SYSUTCDATETIME())
WHERE EnvironmentId = :EnvId AND LockToken = :Token;
"""
        )
        with self._engine.begin() as connection:
            connection.execute(
                query,
                {
                    "EnvId": str(environment_id),
                    "Token": lock_token,
                    "TtlMinutes": ttl_minutes,
                },
            )

    def release(self, environment_id: UUID, lock_token: str) -> None:
        query = text(
            """
UPDATE environment_locks
SET LockExpiresAt = SYSUTCDATETIME(), LockedBy = NULL, LockToken = NULL
WHERE EnvironmentId = :EnvId AND LockToken = :Token;
"""
        )
        with self._engine.begin() as connection:
            connection.execute(query, {"EnvId": str(environment_id), "Token": lock_token})
