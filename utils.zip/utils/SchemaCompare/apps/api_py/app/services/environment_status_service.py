from __future__ import annotations

from app.db.models import EnvironmentEntity, RepositoryEntity
from app.schemas.environment import EnvironmentStatusResponse
from app.services.flyway_runner import FlywayRunner


class EnvironmentStatusService:
    def __init__(self, flyway_runner: FlywayRunner) -> None:
        self._flyway_runner = flyway_runner

    def get_status(self, environment: EnvironmentEntity, repository: RepositoryEntity) -> EnvironmentStatusResponse:
        info = self._flyway_runner.info(environment, repository)

        applied = [m for m in info.migrations if (m.state or "").lower() == "success"]
        pending = [m for m in info.migrations if (m.state or "").lower() == "pending"]

        current_version = ""
        versioned_applied = [m for m in applied if m.version]
        if versioned_applied:
            current_version = versioned_applied[-1].version or ""
        elif info.schema_version:
            current_version = info.schema_version

        drift_from_info = any((m.state or "").lower() in {"outoforder", "missing", "failed"} for m in info.migrations)
        drift_detected = environment.last_validation_drift if environment.last_validation_drift is not None else drift_from_info

        return EnvironmentStatusResponse(
            environmentId=environment.id,
            currentVersion=current_version,
            pendingCount=len(pending),
            appliedCount=len(applied),
            driftDetected=drift_detected,
            lastValidatedAt=environment.last_validated_at,
        )
