from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from sqlalchemy.orm import Session

from app.db.models import AuditEventEntity


class AuditService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def record(self, actor: str, action: str, entity_type: str, entity_id: UUID | None, details: Any) -> None:
        event = AuditEventEntity(
            actor=actor,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            details_json=None if details is None else json.dumps(details, default=str),
        )
        self._db.add(event)
        self._db.commit()
