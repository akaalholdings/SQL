from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import List, Optional

from app.core.config import get_settings
from app.db.models import EnvironmentEntity, RepositoryEntity
from app.services.secret_provider import SecretProvider


class FlywayCommand(str, Enum):
    INFO = "info"
    VALIDATE = "validate"
    MIGRATE = "migrate"
    BASELINE = "baseline"
    REPAIR = "repair"


@dataclass
class FlywayMigration:
    category: Optional[str]
    version: Optional[str]
    description: Optional[str]
    type: Optional[str]
    script: Optional[str]
    checksum: Optional[str]
    installed_by: Optional[str]
    installed_on: Optional[datetime]
    execution_time: Optional[int]
    success: Optional[bool]
    state: Optional[str]


@dataclass
class FlywayInfoResult:
    schema_version: Optional[str]
    migrations: List[FlywayMigration]


@dataclass
class FlywayResult:
    exit_code: int
    std_out: str
    std_err: str
    duration_ms: int
    info: Optional[FlywayInfoResult]


class FlywayRunner:
    def __init__(self, secret_provider: SecretProvider) -> None:
        self._secret_provider = secret_provider
        self._settings = get_settings()

    def info(self, environment: EnvironmentEntity, repository: RepositoryEntity) -> FlywayInfoResult:
        result = self.run(FlywayCommand.INFO, environment, repository)
        if result.info is None:
            raise RuntimeError("Flyway info did not return JSON output.")
        return result.info

    def run(self, command: FlywayCommand, environment: EnvironmentEntity, repository: RepositoryEntity) -> FlywayResult:
        password = None
        if environment.password_secret_name:
            password = self._secret_provider.get_secret(environment.password_secret_name)

        child_env = os.environ.copy()
        if environment.user:
            child_env["FLYWAY_USER"] = environment.user
        if password:
            # Avoid leaking secrets via process args (ps, crash dumps).
            child_env["FLYWAY_PASSWORD"] = password

        args = [
            command.value,
            f"-url={environment.jdbc_url}",
            f"-schemas={environment.schema}",
            f"-table={environment.history_table}",
            f"-locations=filesystem:{self._normalize_root(repository.root_path)}/sql",
            "-validateMigrationNaming=true",
        ]

        if command == FlywayCommand.INFO:
            args.append("-outputType=json")

        started = time.monotonic()
        try:
            process = subprocess.run(
                [self._settings.flyway_path, *args],
                capture_output=True,
                text=True,
                check=False,
                env=child_env,
                timeout=self._settings.flyway_timeout_seconds,
            )
        except subprocess.TimeoutExpired as exc:
            duration_ms = int((time.monotonic() - started) * 1000)
            raise RuntimeError(
                f"Flyway command '{command.value}' timed out after {self._settings.flyway_timeout_seconds}s (duration {duration_ms}ms)."
            ) from exc

        duration_ms = int((time.monotonic() - started) * 1000)

        info = None
        if command == FlywayCommand.INFO and process.stdout.strip():
            info = self._try_parse_info(process.stdout)

        std_out = self._truncate_output(process.stdout)
        std_err = self._truncate_output(process.stderr)

        return FlywayResult(
            exit_code=process.returncode,
            std_out=std_out,
            std_err=std_err,
            duration_ms=duration_ms,
            info=info,
        )

    def _truncate_output(self, value: str) -> str:
        limit = max(int(self._settings.output_max_chars), 10_000)
        if not value:
            return ""
        if len(value) <= limit:
            return value
        remaining = len(value) - limit
        return value[:limit] + f"\n...(truncated {remaining} chars)...\n"

    @staticmethod
    def _normalize_root(path: str) -> str:
        return str(Path(path).resolve()).replace("\\", "/")

    @staticmethod
    def _parse_datetime(value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None

    def _try_parse_info(self, payload: str) -> Optional[FlywayInfoResult]:
        try:
            doc = json.loads(payload)
        except json.JSONDecodeError:
            return None

        schema_version = doc.get("schemaVersion")
        migrations_data = doc.get("migrations")
        migrations: List[FlywayMigration] = []

        if isinstance(migrations_data, list):
            for item in migrations_data:
                if not isinstance(item, dict):
                    continue
                success_value = item.get("success")
                success: Optional[bool]
                if isinstance(success_value, bool):
                    success = success_value
                else:
                    success = None

                execution_time = item.get("executionTime")
                migrations.append(
                    FlywayMigration(
                        category=item.get("category"),
                        version=item.get("version"),
                        description=item.get("description"),
                        type=item.get("type"),
                        script=item.get("script"),
                        checksum=None if item.get("checksum") is None else str(item.get("checksum")),
                        installed_by=item.get("installedBy"),
                        installed_on=self._parse_datetime(item.get("installedOn")),
                        execution_time=execution_time if isinstance(execution_time, int) else None,
                        success=success,
                        state=item.get("state"),
                    )
                )

        return FlywayInfoResult(schema_version=schema_version, migrations=migrations)
