from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import time
from typing import Dict, List, Optional

import pyodbc

from app.db.models import EnvironmentEntity
from app.schemas.schema import (
    ColumnSchemaResponse,
    ConstraintColumnSchemaResponse,
    DatabaseSchemaResponse,
    EnvironmentRowCountsResponse,
    ForeignKeyColumnSchemaResponse,
    ForeignKeySchemaResponse,
    IndexColumnSchemaResponse,
    IndexSchemaResponse,
    PartitionSchemaResponse,
    TableConstraintSchemaResponse,
    TableRowCountResponse,
    TableSchemaResponse,
)
from app.services.secret_provider import SecretProvider


_CONSTRAINT_TYPE_PRIMARY_KEY = "PRIMARY_KEY"
_CONSTRAINT_TYPE_UNIQUE = "UNIQUE"
_CONSTRAINT_TYPE_CHECK = "CHECK"
_CONSTRAINT_TYPE_DEFAULT = "DEFAULT"
_TRANSIENT_SQL_STATES = {"HYT00", "08001", "08S01"}


@dataclass
class _IndexAccumulator:
    name: str
    type: str
    is_unique: bool
    is_primary_key: bool
    columns: List[IndexColumnSchemaResponse] = field(default_factory=list)

    def to_response(self) -> IndexSchemaResponse:
        return IndexSchemaResponse(
            name=self.name,
            type=self.type,
            isUnique=self.is_unique,
            isPrimaryKey=self.is_primary_key,
            columns=self.columns,
        )


@dataclass
class _ConstraintAccumulator:
    name: str
    type: str
    definition: Optional[str]
    is_clustered: bool
    is_disabled: bool
    is_not_trusted: bool
    columns: List[ConstraintColumnSchemaResponse] = field(default_factory=list)

    def to_response(self) -> TableConstraintSchemaResponse:
        return TableConstraintSchemaResponse(
            name=self.name,
            type=self.type,
            definition=self.definition,
            isClustered=self.is_clustered,
            isDisabled=self.is_disabled,
            isNotTrusted=self.is_not_trusted,
            columns=self.columns,
        )


@dataclass
class _ForeignKeyAccumulator:
    name: str
    referenced_schema: str
    referenced_table: str
    on_delete_action: str
    on_update_action: str
    is_disabled: bool
    is_not_trusted: bool
    columns: List[ForeignKeyColumnSchemaResponse] = field(default_factory=list)

    def to_response(self) -> ForeignKeySchemaResponse:
        return ForeignKeySchemaResponse(
            name=self.name,
            referencedSchema=self.referenced_schema,
            referencedTable=self.referenced_table,
            onDeleteAction=self.on_delete_action,
            onUpdateAction=self.on_update_action,
            isDisabled=self.is_disabled,
            isNotTrusted=self.is_not_trusted,
            columns=self.columns,
        )


@dataclass
class _TableAccumulator:
    name: str
    schema: str
    columns: List[ColumnSchemaResponse] = field(default_factory=list)
    indexes: Dict[str, _IndexAccumulator] = field(default_factory=dict)
    constraints: Dict[str, _ConstraintAccumulator] = field(default_factory=dict)
    foreign_keys: Dict[str, _ForeignKeyAccumulator] = field(default_factory=dict)
    partitions: Optional[PartitionSchemaResponse] = None

    def get_or_create_index(self, name: str, idx_type: str, is_unique: bool, is_primary_key: bool) -> _IndexAccumulator:
        existing = self.indexes.get(name.lower())
        if existing:
            return existing
        created = _IndexAccumulator(name=name, type=idx_type, is_unique=is_unique, is_primary_key=is_primary_key)
        self.indexes[name.lower()] = created
        return created

    def get_or_create_constraint(
        self,
        name: str,
        constraint_type: str,
        definition: Optional[str],
        is_clustered: bool,
        is_disabled: bool,
        is_not_trusted: bool,
    ) -> _ConstraintAccumulator:
        key = name.lower()
        existing = self.constraints.get(key)
        if existing:
            if definition:
                existing.definition = definition
            existing.is_clustered = existing.is_clustered or is_clustered
            existing.is_disabled = existing.is_disabled or is_disabled
            existing.is_not_trusted = existing.is_not_trusted or is_not_trusted
            return existing

        created = _ConstraintAccumulator(
            name=name,
            type=constraint_type,
            definition=definition,
            is_clustered=is_clustered,
            is_disabled=is_disabled,
            is_not_trusted=is_not_trusted,
        )
        self.constraints[key] = created
        return created

    def get_or_create_foreign_key(
        self,
        name: str,
        referenced_schema: str,
        referenced_table: str,
        on_delete_action: str,
        on_update_action: str,
        is_disabled: bool,
        is_not_trusted: bool,
    ) -> _ForeignKeyAccumulator:
        key = name.lower()
        existing = self.foreign_keys.get(key)
        if existing:
            return existing

        created = _ForeignKeyAccumulator(
            name=name,
            referenced_schema=referenced_schema,
            referenced_table=referenced_table,
            on_delete_action=on_delete_action,
            on_update_action=on_update_action,
            is_disabled=is_disabled,
            is_not_trusted=is_not_trusted,
        )
        self.foreign_keys[key] = created
        return created

    def to_response(self) -> TableSchemaResponse:
        return TableSchemaResponse(
            name=self.name,
            schema=self.schema,
            columns=sorted(self.columns, key=lambda c: c.name.lower()),
            indexes=[i.to_response() for i in sorted(self.indexes.values(), key=lambda x: x.name.lower())],
            constraints=[c.to_response() for c in sorted(self.constraints.values(), key=lambda x: x.name.lower())],
            foreignKeys=[f.to_response() for f in sorted(self.foreign_keys.values(), key=lambda x: x.name.lower())],
            partitions=self.partitions,
        )


class DatabaseSchemaService:
    def __init__(self, secret_provider: SecretProvider) -> None:
        self._secret_provider = secret_provider

    def get_schema(self, environment: EnvironmentEntity) -> DatabaseSchemaResponse:
        connection_string = self._build_connection_string(environment)
        tables: Dict[str, _TableAccumulator] = {}

        with self._connect(connection_string) as connection:
            self._load_tables(connection, tables)
            self._load_columns(connection, tables)
            self._load_indexes(connection, tables)
            self._load_key_constraints(connection, tables)
            self._load_check_constraints(connection, tables)
            self._load_default_constraints(connection, tables)
            self._load_foreign_keys(connection, tables)
            self._load_partitions(connection, tables)

        result_tables = [item.to_response() for item in tables.values()]
        result_tables.sort(key=lambda t: (t.schema.lower(), t.name.lower()))

        return DatabaseSchemaResponse(
            connectionId=str(environment.id),
            connectionName=environment.name,
            environment=environment.type,
            fetchedAt=datetime.now(timezone.utc).isoformat(),
            tables=result_tables,
        )

    def test_connection(self, environment: EnvironmentEntity) -> None:
        connection_string = self._build_connection_string(environment)
        with self._connect(connection_string) as connection:
            cursor = connection.cursor()
            cursor.execute("SELECT 1;")
            cursor.fetchone()
            cursor.close()

    def get_row_counts(self, environment: EnvironmentEntity) -> EnvironmentRowCountsResponse:
        connection_string = self._build_connection_string(environment)
        query = """
SELECT
    s.name AS SchemaName,
    t.name AS TableName,
    COALESCE(SUM(CAST(p.[rows] AS bigint)), 0) AS [RowCount]
FROM sys.tables t
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
LEFT JOIN sys.partitions p ON p.object_id = t.object_id AND p.index_id IN (0, 1)
WHERE t.is_ms_shipped = 0
  AND t.is_external = 0
GROUP BY s.name, t.name
ORDER BY s.name, t.name;
        """

        tables: List[TableRowCountResponse] = []
        with self._connect(connection_string) as connection:
            cursor = connection.cursor()
            cursor.execute(query)
            for row in cursor.fetchall():
                tables.append(
                    TableRowCountResponse(
                        schema=row[0],
                        tableName=row[1],
                        rowCount=0 if row[2] is None else int(row[2]),
                    )
                )
            cursor.close()

        return EnvironmentRowCountsResponse(
            connectionId=str(environment.id),
            connectionName=environment.name,
            environment=environment.type,
            fetchedAt=datetime.now(timezone.utc).isoformat(),
            tables=tables,
        )

    def _connect(self, connection_string: str) -> pyodbc.Connection:
        # Azure SQL free/serverless tiers can cold-start and intermittently throw HYT00.
        # Retry transient connect failures to stabilize schema-compare/demo flows.
        for attempt in range(1, 4):
            try:
                return pyodbc.connect(connection_string)
            except pyodbc.Error as exc:
                if attempt >= 3 or not self._is_transient_connect_error(exc):
                    raise
                time.sleep(attempt * 2)

        raise RuntimeError("Failed to connect to SQL server.")

    @staticmethod
    def _is_transient_connect_error(exc: pyodbc.Error) -> bool:
        sql_state = str(exc.args[0]).upper() if exc.args else ""
        if sql_state in _TRANSIENT_SQL_STATES:
            return True

        message = str(exc).upper()
        return "LOGIN TIMEOUT EXPIRED" in message

    def _build_connection_string(self, environment: EnvironmentEntity) -> str:
        password: Optional[str] = None
        if environment.password_secret_name:
            password = self._secret_provider.get_secret(environment.password_secret_name)

        jdbc = environment.jdbc_url or ""
        if jdbc.lower().startswith("jdbc:sqlserver://"):
            return self._convert_jdbc_to_connection_string(environment, password)

        props = self._parse_connection_string(jdbc)
        server = props.get("server") or props.get("data source") or props.get("datasource")
        if not server:
            raise RuntimeError("Invalid SQL connection string; missing Server.")

        database = props.get("database") or props.get("initial catalog") or environment.database
        driver = props.get("driver", "ODBC Driver 18 for SQL Server")
        encrypt = self._bool_text(props.get("encrypt"), default="yes")
        trust = self._bool_text(props.get("trustservercertificate"), default="no")
        timeout = props.get("connect timeout") or props.get("connection timeout") or props.get("timeout") or "30"

        args = [
            f"DRIVER={{{driver}}}",
            f"SERVER={server}",
            f"DATABASE={database}",
            f"Encrypt={encrypt}",
            f"TrustServerCertificate={trust}",
            f"Connection Timeout={timeout}",
        ]

        if environment.auth_mode.lower() == "entra":
            args.append("Authentication=ActiveDirectoryDefault")
        else:
            username = environment.user or props.get("user id") or props.get("uid") or props.get("user")
            if username:
                args.append(f"UID={username}")

            final_password = password or props.get("password") or props.get("pwd")
            if final_password:
                args.append(f"PWD={final_password}")

        return ";".join(args)

    def _convert_jdbc_to_connection_string(self, environment: EnvironmentEntity, password: Optional[str]) -> str:
        raw = environment.jdbc_url[len("jdbc:sqlserver://") :]
        parts = [part.strip() for part in raw.split(";") if part.strip()]
        if not parts:
            raise RuntimeError("Invalid JDBC URL. Expected jdbc:sqlserver://host:port;...")

        data_source = self._normalize_data_source(parts[0])
        props: Dict[str, str] = {}
        for part in parts[1:]:
            if "=" not in part:
                continue
            key, value = part.split("=", 1)
            props[key.strip().lower()] = value.strip()

        database = props.get("databasename") or props.get("database") or environment.database
        encrypt = self._bool_text(props.get("encrypt"), default="yes")
        trust = self._bool_text(props.get("trustservercertificate"), default="no")
        timeout = props.get("logintimeout") or "30"

        args = [
            "DRIVER={ODBC Driver 18 for SQL Server}",
            f"SERVER={data_source}",
            f"DATABASE={database}",
            f"Encrypt={encrypt}",
            f"TrustServerCertificate={trust}",
            f"Connection Timeout={timeout}",
        ]

        if environment.auth_mode.lower() == "entra":
            args.append("Authentication=ActiveDirectoryDefault")
        else:
            user = environment.user or props.get("user")
            if user:
                args.append(f"UID={user}")

            final_password = password or props.get("password")
            if final_password:
                args.append(f"PWD={final_password}")

        return ";".join(args)

    @staticmethod
    def _parse_connection_string(raw: str) -> Dict[str, str]:
        values: Dict[str, str] = {}
        for item in raw.split(";"):
            part = item.strip()
            if not part or "=" not in part:
                continue
            key, value = part.split("=", 1)
            values[key.strip().lower()] = value.strip()
        return values

    @staticmethod
    def _bool_text(value: Optional[str], default: str) -> str:
        if value is None:
            return default
        return "yes" if value.strip().lower() in {"1", "true", "yes", "on"} else "no"

    @staticmethod
    def _normalize_data_source(value: str) -> str:
        normalized = value
        if normalized.lower().startswith("tcp:"):
            normalized = normalized[4:]

        if "," in normalized:
            return normalized

        port_separator = normalized.rfind(":")
        if port_separator <= 0 or port_separator >= len(normalized) - 1:
            return normalized

        if normalized.startswith("[") and "]" in normalized:
            return normalized

        port_part = normalized[port_separator + 1 :]
        if not port_part.isdigit():
            return normalized

        host_part = normalized[:port_separator]
        return f"{host_part},{port_part}"

    @staticmethod
    def _table_key(schema_name: str, table_name: str) -> str:
        return f"{schema_name}.{table_name}".lower()

    @staticmethod
    def _normalize_length(data_type: str, max_length_raw: int) -> Optional[int]:
        if max_length_raw < 0:
            return -1
        if data_type.lower() in {"nvarchar", "nchar"}:
            return int(max_length_raw / 2)
        return int(max_length_raw)

    @staticmethod
    def _as_bool(value: object) -> bool:
        if isinstance(value, bool):
            return value
        if value is None:
            return False
        return bool(int(value))

    def _load_tables(self, connection: pyodbc.Connection, tables: Dict[str, _TableAccumulator]) -> None:
        query = """
SELECT s.name AS SchemaName, t.name AS TableName
FROM sys.tables t
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
WHERE t.is_ms_shipped = 0
  AND t.is_external = 0
ORDER BY s.name, t.name;
"""
        cursor = connection.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            schema_name = row[0]
            table_name = row[1]
            key = self._table_key(schema_name, table_name)
            tables[key] = _TableAccumulator(name=table_name, schema=schema_name)
        cursor.close()

    def _load_columns(self, connection: pyodbc.Connection, tables: Dict[str, _TableAccumulator]) -> None:
        query = """
SELECT
    s.name AS SchemaName,
    t.name AS TableName,
    c.name AS ColumnName,
    ty.name AS DataType,
    c.max_length AS MaxLength,
    c.precision AS PrecisionValue,
    c.scale AS ScaleValue,
    c.is_nullable AS IsNullable,
    dc.definition AS DefaultValue,
    c.is_identity AS IsIdentity,
    c.is_computed AS IsComputed,
    c.column_id AS ColumnId
FROM sys.columns c
INNER JOIN sys.tables t ON t.object_id = c.object_id
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
INNER JOIN sys.types ty ON ty.user_type_id = c.user_type_id
LEFT JOIN sys.default_constraints dc ON dc.object_id = c.default_object_id
WHERE t.is_ms_shipped = 0
  AND t.is_external = 0
ORDER BY s.name, t.name, c.column_id;
"""
        cursor = connection.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            key = self._table_key(row[0], row[1])
            table = tables.get(key)
            if not table:
                continue

            data_type = row[3]
            table.columns.append(
                ColumnSchemaResponse(
                    name=row[2],
                    dataType=data_type,
                    maxLength=self._normalize_length(data_type, int(row[4])),
                    precision=None if row[5] is None else int(row[5]),
                    scale=None if row[6] is None else int(row[6]),
                    isNullable=self._as_bool(row[7]),
                    defaultValue=row[8],
                    isIdentity=self._as_bool(row[9]),
                    isComputed=self._as_bool(row[10]),
                )
            )
        cursor.close()

    def _load_indexes(self, connection: pyodbc.Connection, tables: Dict[str, _TableAccumulator]) -> None:
        query = """
SELECT
    s.name AS SchemaName,
    t.name AS TableName,
    i.name AS IndexName,
    i.type_desc AS IndexType,
    i.is_unique AS IsUnique,
    i.is_primary_key AS IsPrimaryKey,
    c.name AS ColumnName,
    ic.is_descending_key AS IsDescending,
    ic.is_included_column AS IsIncluded,
    ic.key_ordinal AS KeyOrdinal,
    ic.index_column_id AS IndexColumnId
FROM sys.indexes i
INNER JOIN sys.tables t ON t.object_id = i.object_id
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
INNER JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
INNER JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE t.is_ms_shipped = 0
  AND t.is_external = 0
  AND i.name IS NOT NULL
  AND i.is_primary_key = 0
  AND i.is_unique_constraint = 0
ORDER BY s.name, t.name, i.name, ic.key_ordinal, ic.index_column_id;
"""
        cursor = connection.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            table = tables.get(self._table_key(row[0], row[1]))
            if not table:
                continue

            index = table.get_or_create_index(row[2], row[3], self._as_bool(row[4]), self._as_bool(row[5]))
            index.columns.append(
                IndexColumnSchemaResponse(
                    name=row[6],
                    isDescending=self._as_bool(row[7]),
                    isIncluded=self._as_bool(row[8]),
                )
            )
        cursor.close()

    def _load_key_constraints(self, connection: pyodbc.Connection, tables: Dict[str, _TableAccumulator]) -> None:
        query = """
SELECT
    s.name AS SchemaName,
    t.name AS TableName,
    kc.name AS ConstraintName,
    kc.type AS ConstraintType,
    CASE WHEN i.type_desc LIKE '%CLUSTERED%' THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsClustered,
    c.name AS ColumnName,
    ic.is_descending_key AS IsDescending,
    ic.key_ordinal AS KeyOrdinal
FROM sys.key_constraints kc
INNER JOIN sys.tables t ON t.object_id = kc.parent_object_id
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
INNER JOIN sys.indexes i ON i.object_id = t.object_id AND i.index_id = kc.unique_index_id
INNER JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.key_ordinal > 0
INNER JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE t.is_ms_shipped = 0
  AND t.is_external = 0
ORDER BY s.name, t.name, kc.name, ic.key_ordinal;
"""
        cursor = connection.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            table = tables.get(self._table_key(row[0], row[1]))
            if not table:
                continue

            raw_type = row[3]
            constraint_type = _CONSTRAINT_TYPE_PRIMARY_KEY if str(raw_type).upper() == "PK" else _CONSTRAINT_TYPE_UNIQUE
            constraint = table.get_or_create_constraint(
                row[2],
                constraint_type,
                None,
                self._as_bool(row[4]),
                False,
                False,
            )
            constraint.columns.append(ConstraintColumnSchemaResponse(name=row[5], isDescending=self._as_bool(row[6])))
        cursor.close()

    def _load_check_constraints(self, connection: pyodbc.Connection, tables: Dict[str, _TableAccumulator]) -> None:
        query = """
SELECT
    s.name AS SchemaName,
    t.name AS TableName,
    cc.name AS ConstraintName,
    cc.definition AS Definition,
    cc.is_disabled AS IsDisabled,
    cc.is_not_trusted AS IsNotTrusted,
    c.name AS ColumnName
FROM sys.check_constraints cc
INNER JOIN sys.tables t ON t.object_id = cc.parent_object_id
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
LEFT JOIN sys.columns c ON c.object_id = t.object_id AND c.column_id = cc.parent_column_id
WHERE t.is_ms_shipped = 0
  AND t.is_external = 0
ORDER BY s.name, t.name, cc.name;
"""
        cursor = connection.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            table = tables.get(self._table_key(row[0], row[1]))
            if not table:
                continue

            constraint = table.get_or_create_constraint(
                row[2],
                _CONSTRAINT_TYPE_CHECK,
                row[3],
                False,
                self._as_bool(row[4]),
                self._as_bool(row[5]),
            )

            if row[6] is not None:
                constraint.columns.append(ConstraintColumnSchemaResponse(name=row[6], isDescending=False))
        cursor.close()

    def _load_default_constraints(self, connection: pyodbc.Connection, tables: Dict[str, _TableAccumulator]) -> None:
        query = """
SELECT
    s.name AS SchemaName,
    t.name AS TableName,
    dc.name AS ConstraintName,
    dc.definition AS Definition,
    c.name AS ColumnName
FROM sys.default_constraints dc
INNER JOIN sys.tables t ON t.object_id = dc.parent_object_id
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
INNER JOIN sys.columns c ON c.object_id = t.object_id AND c.column_id = dc.parent_column_id
WHERE t.is_ms_shipped = 0
  AND t.is_external = 0
ORDER BY s.name, t.name, dc.name;
"""
        cursor = connection.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            table = tables.get(self._table_key(row[0], row[1]))
            if not table:
                continue

            constraint = table.get_or_create_constraint(
                row[2],
                _CONSTRAINT_TYPE_DEFAULT,
                row[3],
                False,
                False,
                False,
            )
            constraint.columns.append(ConstraintColumnSchemaResponse(name=row[4], isDescending=False))
        cursor.close()

    def _load_foreign_keys(self, connection: pyodbc.Connection, tables: Dict[str, _TableAccumulator]) -> None:
        query = """
SELECT
    s_parent.name AS ParentSchema,
    t_parent.name AS ParentTable,
    fk.name AS ForeignKeyName,
    s_ref.name AS ReferencedSchema,
    t_ref.name AS ReferencedTable,
    pc.name AS ParentColumn,
    rc.name AS ReferencedColumn,
    fkc.constraint_column_id AS ConstraintColumnId,
    fk.delete_referential_action_desc AS DeleteAction,
    fk.update_referential_action_desc AS UpdateAction,
    fk.is_disabled AS IsDisabled,
    fk.is_not_trusted AS IsNotTrusted
FROM sys.foreign_keys fk
INNER JOIN sys.tables t_parent ON t_parent.object_id = fk.parent_object_id
INNER JOIN sys.schemas s_parent ON s_parent.schema_id = t_parent.schema_id
INNER JOIN sys.tables t_ref ON t_ref.object_id = fk.referenced_object_id
INNER JOIN sys.schemas s_ref ON s_ref.schema_id = t_ref.schema_id
INNER JOIN sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
INNER JOIN sys.columns pc ON pc.object_id = fkc.parent_object_id AND pc.column_id = fkc.parent_column_id
INNER JOIN sys.columns rc ON rc.object_id = fkc.referenced_object_id AND rc.column_id = fkc.referenced_column_id
WHERE t_parent.is_ms_shipped = 0
  AND t_parent.is_external = 0
ORDER BY s_parent.name, t_parent.name, fk.name, fkc.constraint_column_id;
"""
        cursor = connection.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            table = tables.get(self._table_key(row[0], row[1]))
            if not table:
                continue

            foreign_key = table.get_or_create_foreign_key(
                row[2],
                row[3],
                row[4],
                row[8],
                row[9],
                self._as_bool(row[10]),
                self._as_bool(row[11]),
            )
            foreign_key.columns.append(ForeignKeyColumnSchemaResponse(sourceColumn=row[5], referencedColumn=row[6]))
        cursor.close()

    def _load_partitions(self, connection: pyodbc.Connection, tables: Dict[str, _TableAccumulator]) -> None:
        query = """
SELECT
    s.name AS SchemaName,
    t.name AS TableName,
    ps.name AS SchemeName,
    pf.name AS FunctionName,
    c.name AS ColumnName,
    COUNT(DISTINCT p.partition_number) AS PartitionCount
FROM sys.tables t
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
INNER JOIN sys.indexes i ON i.object_id = t.object_id AND i.index_id IN (0, 1)
INNER JOIN sys.partitions p ON p.object_id = i.object_id AND p.index_id = i.index_id
LEFT JOIN sys.partition_schemes ps ON ps.data_space_id = i.data_space_id
LEFT JOIN sys.partition_functions pf ON pf.function_id = ps.function_id
LEFT JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.partition_ordinal = 1
LEFT JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE t.is_ms_shipped = 0
  AND t.is_external = 0
GROUP BY s.name, t.name, ps.name, pf.name, c.name
ORDER BY s.name, t.name;
"""
        cursor = connection.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            table = tables.get(self._table_key(row[0], row[1]))
            if not table:
                continue

            scheme_name = row[2]
            function_name = row[3]
            column_name = row[4]
            partition_count = int(row[5]) if row[5] is not None else 0

            if not scheme_name and not function_name:
                continue

            table.partitions = PartitionSchemaResponse(
                schemeName=scheme_name,
                functionName=function_name,
                columnName=column_name,
                partitionCount=partition_count,
            )
        cursor.close()
