from __future__ import annotations

import datetime as dt
from typing import Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.db.models import MigrationRunEntity, RunLogEntity


class RunService:
    def __init__(self, db: Session) -> None:
        self._db = db

    def start_run(self, environment_id: UUID, action: str, triggered_by: str, confirmation: str | None) -> MigrationRunEntity:
        run = MigrationRunEntity(
            environment_id=environment_id,
            action=action,
            triggered_by=triggered_by,
            confirmation=confirmation,
        )
        self._db.add(run)
        self._db.commit()
        self._db.refresh(run)
        return run

    def complete_run(
        self,
        run: MigrationRunEntity,
        status: str,
        output: Optional[str],
        output_json: Optional[str],
        error: Optional[str],
        pending: Optional[int],
        applied: Optional[int],
        drift: Optional[bool],
    ) -> MigrationRunEntity:
        run.status = status
        run.finished_at = dt.datetime.now(dt.timezone.utc)
        run.output = output
        run.output_json = output_json
        run.error = error
        run.pending_count = pending
        run.applied_count = applied
        run.drift_detected = drift
        if run.finished_at is not None:
            run.duration_ms = int((run.finished_at - run.started_at).total_seconds() * 1000)
        self._db.add(run)
        self._db.commit()
        self._db.refresh(run)
        return run

    def add_log(self, run_id: UUID, level: str, message: str) -> None:
        log = RunLogEntity(run_id=run_id, level=level, message=message)
        self._db.add(log)
        self._db.commit()
