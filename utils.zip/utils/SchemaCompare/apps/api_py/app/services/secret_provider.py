from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from app.core.config import get_settings


class SecretProvider(ABC):
    @abstractmethod
    def get_secret(self, name: str) -> Optional[str]:
        raise NotImplementedError


class KeyVaultSecretProvider(SecretProvider):
    def __init__(self, vault_uri: str) -> None:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient

        self._client = SecretClient(vault_url=vault_uri, credential=DefaultAzureCredential())

    def get_secret(self, name: str) -> Optional[str]:
        if not name:
            return None
        value = self._client.get_secret(name)
        return value.value


def build_secret_provider() -> SecretProvider:
    settings = get_settings()
    return KeyVaultSecretProvider(settings.key_vault_uri)
