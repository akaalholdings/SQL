from __future__ import annotations

import json
import os
import time
import unittest
from unittest import mock

import jwt
from jwt.algorithms import RSAAlgorithm

from app.core.config import get_settings
from app.core import entra_jwt
from app.core.entra_jwt import validate_bearer_token
from app.core.security import require_policy
from app.core.security import get_current_principal
from app.core.auth import Principal


class EntraJwtTests(unittest.TestCase):
    def setUp(self) -> None:
        get_settings.cache_clear()
        entra_jwt._JWKS_CACHE.clear()

    def tearDown(self) -> None:
        get_settings.cache_clear()
        entra_jwt._JWKS_CACHE.clear()

    def test_validate_bearer_token_extracts_name_and_roles(self) -> None:
        # Generate a keypair for the test token.
        try:
            from cryptography.hazmat.primitives.asymmetric import rsa
        except Exception as exc:  # pragma: no cover
            self.skipTest(f"cryptography not available: {exc}")

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        public_jwk = json.loads(RSAAlgorithm.to_jwk(key.public_key()))
        public_jwk["kid"] = "test-kid"
        public_jwk["use"] = "sig"

        tenant_id = "test-tenant"
        audience = "api://test-audience"
        issuer = f"https://login.microsoftonline.com/{tenant_id}/v2.0"

        os.environ["APP_DB_CONNECTION_STRING"] = "Server=localhost;Database=FlywayWeb;TrustServerCertificate=True;"
        os.environ["AUTH_MODE"] = "entra"
        os.environ["KEY_VAULT_URI"] = "https://example.vault.azure.net/"
        os.environ["AzureAd__TenantId"] = tenant_id
        os.environ["AzureAd__Audience"] = audience
        os.environ.pop("AzureAd__Issuer", None)

        settings = get_settings()

        now = int(time.time())
        token = jwt.encode(
            {
                "iss": issuer,
                "aud": audience,
                "exp": now + 300,
                "nbf": now - 10,
                "iat": now,
                "preferred_username": "alice@example.com",
                "roles": ["Viewer"],
            },
            key,
            algorithm="RS256",
            headers={"kid": "test-kid"},
        )

        with mock.patch("app.core.entra_jwt._fetch_jwks", return_value={"test-kid": json.dumps(public_jwk)}):
            principal = validate_bearer_token(token, settings)
            self.assertEqual(principal.name, "alice@example.com")
            self.assertEqual(principal.roles, ["Viewer"])

    def test_wrong_audience_is_rejected(self) -> None:
        try:
            from cryptography.hazmat.primitives.asymmetric import rsa
        except Exception as exc:  # pragma: no cover
            self.skipTest(f"cryptography not available: {exc}")

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        public_jwk = json.loads(RSAAlgorithm.to_jwk(key.public_key()))
        public_jwk["kid"] = "test-kid"
        public_jwk["use"] = "sig"

        tenant_id = "test-tenant"
        audience = "api://test-audience"
        issuer = f"https://login.microsoftonline.com/{tenant_id}/v2.0"

        os.environ["APP_DB_CONNECTION_STRING"] = "Server=localhost;Database=FlywayWeb;TrustServerCertificate=True;"
        os.environ["AUTH_MODE"] = "entra"
        os.environ["KEY_VAULT_URI"] = "https://example.vault.azure.net/"
        os.environ["AzureAd__TenantId"] = tenant_id
        os.environ["AzureAd__Audience"] = audience
        settings = get_settings()

        now = int(time.time())
        token = jwt.encode(
            {
                "iss": issuer,
                "aud": "api://wrong-audience",
                "exp": now + 300,
                "nbf": now - 10,
                "iat": now,
                "preferred_username": "alice@example.com",
                "roles": ["Viewer"],
            },
            key,
            algorithm="RS256",
            headers={"kid": "test-kid"},
        )

        with mock.patch("app.core.entra_jwt._fetch_jwks", return_value={"test-kid": json.dumps(public_jwk)}):
            with self.assertRaises(Exception):
                validate_bearer_token(token, settings)

    def test_missing_principal_is_unauthorized(self) -> None:
        class _State:
            principal = None

        class _Req:
            state = _State()

        with self.assertRaises(Exception):
            get_current_principal(_Req())  # type: ignore[arg-type]

    def test_require_policy_forbids_missing_role(self) -> None:
        dep = require_policy("Admin")
        with self.assertRaises(Exception) as ctx:
            dep(principal=Principal(name="bob", roles=["Viewer"]))
        # FastAPI raises HTTPException; we just assert it's an exception and not None.
        self.assertIsNotNone(ctx.exception)
