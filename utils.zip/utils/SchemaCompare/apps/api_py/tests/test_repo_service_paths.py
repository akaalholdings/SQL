from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from app.services.repo_service import MigrationRepository


class RepoServicePathTests(unittest.TestCase):
    def test_read_script_allows_sql_under_repo_root(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            sql_dir = root / "sql" / "versioned"
            sql_dir.mkdir(parents=True, exist_ok=True)
            script = sql_dir / "V001__init.sql"
            script.write_text("SELECT 1;", encoding="utf-8")

            repo = MigrationRepository()
            content = repo.read_script(str(root), "sql/versioned/V001__init.sql")
            self.assertEqual(content, "SELECT 1;")

    def test_read_script_blocks_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "sql").mkdir(parents=True, exist_ok=True)
            outside = root / "outside.txt"
            outside.write_text("nope", encoding="utf-8")

            repo = MigrationRepository()
            with self.assertRaises(ValueError):
                repo.read_script(str(root), "../outside.txt")

    def test_read_script_blocks_non_sql(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            sql_dir = root / "sql"
            sql_dir.mkdir(parents=True, exist_ok=True)
            not_sql = sql_dir / "notes.txt"
            not_sql.write_text("nope", encoding="utf-8")

            repo = MigrationRepository()
            with self.assertRaises(ValueError):
                repo.read_script(str(root), "sql/notes.txt")

