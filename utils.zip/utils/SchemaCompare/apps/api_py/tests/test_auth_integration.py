from __future__ import annotations

import json
import os
import time
import unittest
from unittest import mock

import jwt
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from jwt.algorithms import RSAAlgorithm

from app.core.auth import AuthContextMiddleware, Principal
from app.core import entra_jwt
from app.core.config import get_settings
from app.core.security import require_policy


def _build_test_app(required_policy: str) -> FastAPI:
    app = FastAPI()
    app.add_middleware(AuthContextMiddleware)

    @app.get("/protected")
    def protected(_: Principal = Depends(require_policy(required_policy))):  # noqa: ANN001 - FastAPI DI
        return {"ok": True}

    return app


class AuthIntegrationTests(unittest.TestCase):
    def setUp(self) -> None:
        get_settings.cache_clear()
        entra_jwt._JWKS_CACHE.clear()

        os.environ["APP_DB_CONNECTION_STRING"] = "Server=localhost;Database=FlywayWeb;TrustServerCertificate=True;"
        os.environ["AUTH_MODE"] = "entra"
        os.environ["KEY_VAULT_URI"] = "https://example.vault.azure.net/"
        os.environ["AzureAd__TenantId"] = "test-tenant"
        os.environ["AzureAd__Audience"] = "api://test-audience"
        os.environ.pop("AzureAd__Issuer", None)

    def tearDown(self) -> None:
        get_settings.cache_clear()
        entra_jwt._JWKS_CACHE.clear()

    def _make_signed_token(self, *, roles: list[str], audience: str | None = None) -> tuple[str, str]:
        try:
            from cryptography.hazmat.primitives.asymmetric import rsa
        except Exception as exc:  # pragma: no cover
            self.skipTest(f"cryptography not available: {exc}")

        tenant_id = os.environ["AzureAd__TenantId"]
        aud = audience or os.environ["AzureAd__Audience"]
        issuer = f"https://login.microsoftonline.com/{tenant_id}/v2.0"

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        public_jwk = json.loads(RSAAlgorithm.to_jwk(key.public_key()))
        public_jwk["kid"] = "test-kid"
        public_jwk["use"] = "sig"

        now = int(time.time())
        token = jwt.encode(
            {
                "iss": issuer,
                "aud": aud,
                "exp": now + 300,
                "nbf": now - 10,
                "iat": now,
                "preferred_username": "alice@example.com",
                "roles": roles,
            },
            key,
            algorithm="RS256",
            headers={"kid": "test-kid"},
        )

        # Return token + jwks map to patch in the validator.
        return token, json.dumps(public_jwk)

    def test_entra_missing_token_returns_401(self) -> None:
        app = _build_test_app("Viewer")
        client = TestClient(app)

        resp = client.get("/protected")
        self.assertEqual(resp.status_code, 401)

    def test_entra_valid_token_with_viewer_role_returns_200(self) -> None:
        token, jwk_json = self._make_signed_token(roles=["Viewer"])

        app = _build_test_app("Viewer")
        client = TestClient(app)

        with mock.patch("app.core.entra_jwt._fetch_jwks", return_value={"test-kid": jwk_json}):
            resp = client.get("/protected", headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json(), {"ok": True})

    def test_entra_valid_token_missing_required_role_returns_403(self) -> None:
        token, jwk_json = self._make_signed_token(roles=["Viewer"])

        app = _build_test_app("Admin")
        client = TestClient(app)

        with mock.patch("app.core.entra_jwt._fetch_jwks", return_value={"test-kid": jwk_json}):
            resp = client.get("/protected", headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(resp.status_code, 403)

    def test_entra_wrong_audience_results_in_401(self) -> None:
        token, jwk_json = self._make_signed_token(roles=["Viewer"], audience="api://wrong-audience")

        app = _build_test_app("Viewer")
        client = TestClient(app)

        with mock.patch("app.core.entra_jwt._fetch_jwks", return_value={"test-kid": jwk_json}):
            resp = client.get("/protected", headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(resp.status_code, 401)
