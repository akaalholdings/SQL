from __future__ import annotations

import os
import unittest
from unittest import mock

from app.core.config import get_settings
from app.db.models import EnvironmentEntity, RepositoryEntity
from app.services.flyway_runner import FlywayCommand, FlywayRunner


class _StubSecretProvider:
    def __init__(self, secrets: dict[str, str]) -> None:
        self._secrets = {k.lower(): v for k, v in secrets.items()}

    def get_secret(self, name: str) -> str | None:
        return self._secrets.get(name.lower())


class FlywayRunnerSecretTests(unittest.TestCase):
    def setUp(self) -> None:
        get_settings.cache_clear()

        os.environ["APP_DB_CONNECTION_STRING"] = "Server=localhost;Database=FlywayWeb;TrustServerCertificate=True;"
        os.environ["AUTH_MODE"] = "dev"
        os.environ["KEY_VAULT_URI"] = "https://example.vault.azure.net/"
        os.environ["OUTPUT_MAX_CHARS"] = "2000000"
        os.environ["FLYWAY_TIMEOUT_SECONDS"] = "10"

    def tearDown(self) -> None:
        get_settings.cache_clear()

    def test_password_not_in_args_and_timeout_is_set(self) -> None:
        env = EnvironmentEntity(
            name="dev",
            type="dev",
            server="s",
            database="d",
            schema="dbo",
            auth_mode="sql",
            jdbc_url="jdbc:sqlserver://localhost:1433;databaseName=Db;encrypt=false;trustServerCertificate=true;",
            user="sa",
            password_secret_name="db-password",
            repository_id=None,  # not used by FlywayRunner
            history_table="flyway_schema_history",
        )
        repo = RepositoryEntity(name="repo", type="local", root_path="/data/migrations")

        secret_provider = _StubSecretProvider({"db-password": "SuperSecret"})
        runner = FlywayRunner(secret_provider)

        def fake_run(cmd, capture_output, text, check, env, timeout):
            self.assertEqual(timeout, 10)
            argv = cmd
            self.assertTrue(all("-password=" not in arg for arg in argv))
            self.assertTrue(all("-user=" not in arg for arg in argv))
            self.assertEqual(env.get("FLYWAY_PASSWORD"), "SuperSecret")
            self.assertEqual(env.get("FLYWAY_USER"), "sa")

            class P:
                returncode = 0
                stdout = "{\"schemaVersion\": null, \"migrations\": []}"
                stderr = ""

            return P()

        with mock.patch("app.services.flyway_runner.subprocess.run", side_effect=fake_run):
            res = runner.run(FlywayCommand.INFO, env, repo)
            self.assertEqual(res.exit_code, 0)
