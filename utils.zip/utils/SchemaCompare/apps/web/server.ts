
import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createProxyMiddleware } from 'http-proxy-middleware';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '8080', 10);

// Backend API URL – set via Helm env or default to in-cluster service
const API_BACKEND_URL = process.env.API_BACKEND_URL || 'http://schemacompare-api.geneva-database.svc.cluster.local';

/**
 * Structured JSON logger for Kubernetes log collection.
 * Outputs to stdout for normal requests, stderr for errors.
 *
 * @param level - Log level (info, warn, error)
 * @param message - Log message
 * @param meta - Additional metadata
 */
function log(level: string, message: string, meta: Record<string, unknown> = {}): void {
  const entry = {
    timestamp: new Date().toISOString(),
    level,
    service: 'schemacompare-web',
    message,
    ...meta,
  };

  if (level === 'error') {
    process.stderr.write(JSON.stringify(entry) + '\n');
  } else {
    process.stdout.write(JSON.stringify(entry) + '\n');
  }
}

// Access logging middleware
app.use((req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();

  res.on('finish', () => {
    log('info', 'HTTP Request', {
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs: Date.now() - start,
      userAgent: req.get('user-agent') || 'unknown',
      remoteIp: req.ip,
    });
  });

  next();
});

// Health check endpoint
app.get('/healthz', (_req: Request, res: Response) => {
  res.status(200).json({ status: 'healthy' });
});

// Readiness check endpoint
app.get('/readyz', (_req: Request, res: Response) => {
  res.status(200).json({ status: 'ready' });
});

// Reverse-proxy /api/* requests to the backend API service.
// This allows the frontend (compiled with API_BACKEND_URL=/api) to reach
// the FastAPI backend without CORS issues or build-time URL baking.
app.use(
  '/api',
  createProxyMiddleware({
    target: API_BACKEND_URL,
    changeOrigin: true,
    pathRewrite: { '^/api': '' }
  })
);

// Serve static files from the Vite build output
app.use(express.static(path.join(__dirname, 'dist'), {
  maxAge: '1d',
  etag: true,
}));

// SPA fallback — serve index.html for all non-file routes
app.get('*', (_req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Global error handler
app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
  log('error', 'Unhandled server error', {
    error: err.message,
    stack: err.stack,
    method: req.method,
    path: req.path,
  });
  res.status(500).json({ error: 'Internal Server Error' });
});

app.listen(PORT, '0.0.0.0', () => {
  log('info', `Server started on port ${PORT}`, {
    port: PORT,
    nodeEnv: process.env.NODE_ENV || 'production',
  });
});