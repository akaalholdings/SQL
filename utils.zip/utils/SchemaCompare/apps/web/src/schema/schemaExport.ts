import type { SchemaComparisonResult, TableComparisonResult } from "../types";
import { generateFullMigrationScript, type ScriptGenerationOptions } from "./sqlScriptGenerator";

export type ExportFormat = "json" | "csv" | "markdown" | "sql";

export function buildExportContent(
  result: SchemaComparisonResult,
  format: ExportFormat,
  scriptOptions?: ScriptGenerationOptions
): string {
  switch (format) {
    case "json":
      return JSON.stringify(result, null, 2);
    case "csv":
      return buildCsv(result);
    case "markdown":
      return buildMarkdown(result);
    case "sql":
      return generateFullMigrationScript(result, scriptOptions);
    default:
      return JSON.stringify(result, null, 2);
  }
}

export function downloadTextFile(filename: string, content: string, mimeType = "text/plain"): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

function buildCsv(result: SchemaComparisonResult): string {
  const header = [
    "schema",
    "table",
    "status",
    "columnDiffs",
    "indexDiffs",
    "constraintDiffs",
    "foreignKeyDiffs",
    "hasPartitionDiff"
  ];

  const rows = result.tables.map((table) => {
    const columnDiffs = table.columnDiffs.filter((d) => d.status !== "match").length;
    const indexDiffs = table.indexDiffs.filter((d) => d.status !== "match").length;
    const constraintDiffs = table.constraintDiffs.filter((d) => d.status !== "match").length;
    const foreignKeyDiffs = table.foreignKeyDiffs.filter((d) => d.status !== "match").length;
    const hasPartitionDiff = table.partitionDiff && table.partitionDiff.status !== "match" ? "yes" : "no";
    return [
      escapeCsv(table.schemaName),
      escapeCsv(table.tableName),
      escapeCsv(table.status),
      `${columnDiffs}`,
      `${indexDiffs}`,
      `${constraintDiffs}`,
      `${foreignKeyDiffs}`,
      hasPartitionDiff
    ].join(",");
  });

  return [header.join(","), ...rows].join("\n");
}

function buildMarkdown(result: SchemaComparisonResult): string {
  const lines: string[] = [];
  lines.push(`# Schema Comparison Report`);
  lines.push(``);
  lines.push(`- Source: ${result.sourceConnectionName}`);
  lines.push(`- Target: ${result.targetConnectionName}`);
  lines.push(`- Compared At: ${result.comparedAt}`);
  lines.push(``);
  lines.push(`## Summary`);
  lines.push(``);
  lines.push(`| Metric | Count |`);
  lines.push(`|---|---:|`);
  lines.push(`| Matching | ${result.summary.matching} |`);
  lines.push(`| Modified | ${result.summary.modified} |`);
  lines.push(`| Missing In Target | ${result.summary.missingInTarget} |`);
  lines.push(`| Extra In Target | ${result.summary.extraInTarget} |`);
  lines.push(`| Total Tables | ${result.summary.totalTables} |`);
  lines.push(``);
  lines.push(`## Table Details`);
  lines.push(``);

  result.tables.forEach((table) => {
    lines.push(...tableToMarkdown(table));
  });

  return lines.join("\n");
}

function tableToMarkdown(table: TableComparisonResult): string[] {
  const lines: string[] = [];
  lines.push(`### ${table.schemaName}.${table.tableName} (${table.status})`);
  lines.push("");

  const columnChanges = table.columnDiffs.filter((d) => d.status !== "match");
  if (columnChanges.length > 0) {
    lines.push("Column differences:");
    columnChanges.forEach((diff) => lines.push(`- ${diff.name}: ${diff.status}`));
    lines.push("");
  }

  const indexChanges = table.indexDiffs.filter((d) => d.status !== "match");
  if (indexChanges.length > 0) {
    lines.push("Index differences:");
    indexChanges.forEach((diff) => lines.push(`- ${diff.name}: ${diff.status}`));
    lines.push("");
  }

  const constraintChanges = table.constraintDiffs.filter((d) => d.status !== "match");
  if (constraintChanges.length > 0) {
    lines.push("Constraint differences:");
    constraintChanges.forEach((diff) => lines.push(`- ${diff.name}: ${diff.status}`));
    lines.push("");
  }

  const foreignKeyChanges = table.foreignKeyDiffs.filter((d) => d.status !== "match");
  if (foreignKeyChanges.length > 0) {
    lines.push("Foreign key differences:");
    foreignKeyChanges.forEach((diff) => lines.push(`- ${diff.name}: ${diff.status}`));
    lines.push("");
  }

  if (table.partitionDiff && table.partitionDiff.status !== "match") {
    lines.push(`Partition difference: ${table.partitionDiff.status}`);
    lines.push("");
  }

  return lines;
}

function escapeCsv(value: string): string {
  if (value.includes(",") || value.includes("\"") || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`;
  }

  return value;
}
