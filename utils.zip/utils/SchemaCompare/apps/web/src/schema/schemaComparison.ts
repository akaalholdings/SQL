import type {
  ColumnDiff,
  ColumnSchema,
  ComparisonStatus,
  ConstraintDiff,
  DatabaseSchema,
  ForeignKeyDiff,
  ForeignKeySchema,
  IndexDiff,
  IndexSchema,
  PartitionDiff,
  PartitionSchema,
  SchemaComparisonResult,
  TableComparisonResult,
  TableConstraintSchema,
  TableSchema
} from "../types";

const statusOrder: Record<ComparisonStatus, number> = {
  missing: 0,
  modified: 1,
  extra: 2,
  match: 3
};

export function compareSchemas(source: DatabaseSchema, target: DatabaseSchema): SchemaComparisonResult {
  const sourceMap = new Map<string, TableSchema>();
  const targetMap = new Map<string, TableSchema>();

  source.tables.forEach((table) => sourceMap.set(tableKey(table.schema, table.name), table));
  target.tables.forEach((table) => targetMap.set(tableKey(table.schema, table.name), table));

  const tableResults: TableComparisonResult[] = [];

  source.tables.forEach((sourceTable) => {
    const key = tableKey(sourceTable.schema, sourceTable.name);
    const targetTable = targetMap.get(key);

    if (!targetTable) {
      tableResults.push({
        tableName: sourceTable.name,
        schemaName: sourceTable.schema,
        status: "missing",
        columnDiffs: sourceTable.columns
          .map((column) => ({
            name: column.name,
            status: "missing" as const,
            source: column,
            differences: ["Missing in target"]
          }))
          .sort(sortByDiffStatus),
        indexDiffs: sourceTable.indexes
          .map((index) => ({
            name: index.name,
            status: "missing" as const,
            source: index,
            differences: ["Missing in target"]
          }))
          .sort(sortByDiffStatus),
        constraintDiffs: sourceTable.constraints
          .map((constraint) => ({
            name: constraint.name,
            status: "missing" as const,
            source: constraint,
            differences: ["Missing in target"]
          }))
          .sort(sortByDiffStatus),
        foreignKeyDiffs: sourceTable.foreignKeys
          .map((foreignKey) => ({
            name: foreignKey.name,
            status: "missing" as const,
            source: foreignKey,
            differences: ["Missing in target"]
          }))
          .sort(sortByDiffStatus),
        partitionDiff: sourceTable.partitions
          ? {
              status: "missing",
              source: sourceTable.partitions,
              differences: ["Missing in target"]
            }
          : undefined
      });
      return;
    }

    const columnDiffs = compareColumns(sourceTable.columns, targetTable.columns);
    const indexDiffs = compareIndexes(sourceTable.indexes, targetTable.indexes);
    const constraintDiffs = compareConstraints(sourceTable.constraints, targetTable.constraints);
    const foreignKeyDiffs = compareForeignKeys(sourceTable.foreignKeys, targetTable.foreignKeys);
    const partitionDiff = comparePartitions(sourceTable.partitions, targetTable.partitions);

    const tableStatus = hasTableDifferences(columnDiffs, indexDiffs, constraintDiffs, foreignKeyDiffs, partitionDiff)
      ? "modified"
      : "match";

    tableResults.push({
      tableName: sourceTable.name,
      schemaName: sourceTable.schema,
      status: tableStatus,
      columnDiffs,
      indexDiffs,
      constraintDiffs,
      foreignKeyDiffs,
      partitionDiff
    });
  });

  target.tables.forEach((targetTable) => {
    const key = tableKey(targetTable.schema, targetTable.name);
    if (sourceMap.has(key)) {
      return;
    }

    tableResults.push({
      tableName: targetTable.name,
      schemaName: targetTable.schema,
      status: "extra",
      columnDiffs: targetTable.columns
        .map((column) => ({
          name: column.name,
          status: "extra" as const,
          target: column,
          differences: ["Extra in target"]
        }))
        .sort(sortByDiffStatus),
      indexDiffs: targetTable.indexes
        .map((index) => ({
          name: index.name,
          status: "extra" as const,
          target: index,
          differences: ["Extra in target"]
        }))
        .sort(sortByDiffStatus),
      constraintDiffs: targetTable.constraints
        .map((constraint) => ({
          name: constraint.name,
          status: "extra" as const,
          target: constraint,
          differences: ["Extra in target"]
        }))
        .sort(sortByDiffStatus),
      foreignKeyDiffs: targetTable.foreignKeys
        .map((foreignKey) => ({
          name: foreignKey.name,
          status: "extra" as const,
          target: foreignKey,
          differences: ["Extra in target"]
        }))
        .sort(sortByDiffStatus),
      partitionDiff: targetTable.partitions
        ? {
            status: "extra",
            target: targetTable.partitions,
            differences: ["Extra in target"]
          }
        : undefined
    });
  });

  tableResults.sort((a, b) => {
    const statusDelta = statusOrder[a.status] - statusOrder[b.status];
    if (statusDelta !== 0) {
      return statusDelta;
    }

    const schemaDelta = a.schemaName.localeCompare(b.schemaName);
    if (schemaDelta !== 0) {
      return schemaDelta;
    }

    return a.tableName.localeCompare(b.tableName);
  });

  const summary = {
    matching: tableResults.filter((t) => t.status === "match").length,
    modified: tableResults.filter((t) => t.status === "modified").length,
    missingInTarget: tableResults.filter((t) => t.status === "missing").length,
    extraInTarget: tableResults.filter((t) => t.status === "extra").length,
    totalTables: tableResults.length
  };

  return {
    sourceConnectionId: source.connectionId,
    sourceConnectionName: source.connectionName,
    targetConnectionId: target.connectionId,
    targetConnectionName: target.connectionName,
    comparedAt: new Date().toISOString(),
    summary,
    tables: tableResults
  };
}

function compareColumns(sourceColumns: ColumnSchema[], targetColumns: ColumnSchema[]): ColumnDiff[] {
  const sourceMap = new Map(sourceColumns.map((column) => [column.name.toLowerCase(), column]));
  const targetMap = new Map(targetColumns.map((column) => [column.name.toLowerCase(), column]));
  const diffs: ColumnDiff[] = [];

  sourceColumns.forEach((sourceColumn) => {
    const key = sourceColumn.name.toLowerCase();
    const targetColumn = targetMap.get(key);
    if (!targetColumn) {
      diffs.push({
        name: sourceColumn.name,
        status: "missing",
        source: sourceColumn,
        differences: ["Missing in target"]
      });
      return;
    }

    const differences = listColumnDifferences(sourceColumn, targetColumn);
    diffs.push({
      name: sourceColumn.name,
      status: differences.length > 0 ? "modified" : "match",
      source: sourceColumn,
      target: targetColumn,
      differences
    });
  });

  targetColumns.forEach((targetColumn) => {
    const key = targetColumn.name.toLowerCase();
    if (sourceMap.has(key)) {
      return;
    }

    diffs.push({
      name: targetColumn.name,
      status: "extra",
      target: targetColumn,
      differences: ["Extra in target"]
    });
  });

  return diffs.sort(sortByDiffStatus);
}

function listColumnDifferences(source: ColumnSchema, target: ColumnSchema): string[] {
  const differences: string[] = [];

  if (!equalsIgnoreCase(source.dataType, target.dataType)) {
    differences.push("Data type differs");
  }

  if ((source.maxLength ?? null) !== (target.maxLength ?? null)) {
    differences.push("Max length differs");
  }

  if ((source.precision ?? null) !== (target.precision ?? null)) {
    differences.push("Precision differs");
  }

  if ((source.scale ?? null) !== (target.scale ?? null)) {
    differences.push("Scale differs");
  }

  if (source.isNullable !== target.isNullable) {
    differences.push("Nullability differs");
  }

  if (normalizeSqlDefinition(source.defaultValue) !== normalizeSqlDefinition(target.defaultValue)) {
    differences.push("Default value differs");
  }

  if (source.isIdentity !== target.isIdentity) {
    differences.push("Identity property differs");
  }

  if (source.isComputed !== target.isComputed) {
    differences.push("Computed property differs");
  }

  return differences;
}

function compareIndexes(sourceIndexes: IndexSchema[], targetIndexes: IndexSchema[]): IndexDiff[] {
  const sourceMap = new Map(sourceIndexes.map((index) => [index.name.toLowerCase(), index]));
  const targetMap = new Map(targetIndexes.map((index) => [index.name.toLowerCase(), index]));
  const diffs: IndexDiff[] = [];

  sourceIndexes.forEach((sourceIndex) => {
    const key = sourceIndex.name.toLowerCase();
    const targetIndex = targetMap.get(key);
    if (!targetIndex) {
      diffs.push({
        name: sourceIndex.name,
        status: "missing",
        source: sourceIndex,
        differences: ["Missing in target"]
      });
      return;
    }

    const differences = listIndexDifferences(sourceIndex, targetIndex);
    diffs.push({
      name: sourceIndex.name,
      status: differences.length > 0 ? "modified" : "match",
      source: sourceIndex,
      target: targetIndex,
      differences
    });
  });

  targetIndexes.forEach((targetIndex) => {
    const key = targetIndex.name.toLowerCase();
    if (sourceMap.has(key)) {
      return;
    }

    diffs.push({
      name: targetIndex.name,
      status: "extra",
      target: targetIndex,
      differences: ["Extra in target"]
    });
  });

  return diffs.sort(sortByDiffStatus);
}

function listIndexDifferences(source: IndexSchema, target: IndexSchema): string[] {
  const differences: string[] = [];

  if (!equalsIgnoreCase(source.type, target.type)) {
    differences.push("Index type differs");
  }

  if (source.isUnique !== target.isUnique) {
    differences.push("Uniqueness differs");
  }

  if (source.isPrimaryKey !== target.isPrimaryKey) {
    differences.push("Primary key flag differs");
  }

  if (!areIndexColumnsEqual(source.columns, target.columns)) {
    differences.push("Indexed columns differ");
  }

  return differences;
}

function compareConstraints(sourceConstraints: TableConstraintSchema[], targetConstraints: TableConstraintSchema[]): ConstraintDiff[] {
  const sourceMap = new Map(sourceConstraints.map((constraint) => [constraint.name.toLowerCase(), constraint]));
  const targetMap = new Map(targetConstraints.map((constraint) => [constraint.name.toLowerCase(), constraint]));
  const diffs: ConstraintDiff[] = [];

  sourceConstraints.forEach((sourceConstraint) => {
    const key = sourceConstraint.name.toLowerCase();
    const targetConstraint = targetMap.get(key);
    if (!targetConstraint) {
      diffs.push({
        name: sourceConstraint.name,
        status: "missing",
        source: sourceConstraint,
        differences: ["Missing in target"]
      });
      return;
    }

    const differences = listConstraintDifferences(sourceConstraint, targetConstraint);
    diffs.push({
      name: sourceConstraint.name,
      status: differences.length > 0 ? "modified" : "match",
      source: sourceConstraint,
      target: targetConstraint,
      differences
    });
  });

  targetConstraints.forEach((targetConstraint) => {
    const key = targetConstraint.name.toLowerCase();
    if (sourceMap.has(key)) {
      return;
    }

    diffs.push({
      name: targetConstraint.name,
      status: "extra",
      target: targetConstraint,
      differences: ["Extra in target"]
    });
  });

  return diffs.sort(sortByDiffStatus);
}

function listConstraintDifferences(source: TableConstraintSchema, target: TableConstraintSchema): string[] {
  const differences: string[] = [];

  if (!equalsIgnoreCase(source.type, target.type)) {
    differences.push("Constraint type differs");
  }

  if (!areConstraintColumnsEqual(source.columns, target.columns)) {
    differences.push("Constraint columns differ");
  }

  if (normalizeSqlDefinition(source.definition) !== normalizeSqlDefinition(target.definition)) {
    differences.push("Constraint definition differs");
  }

  if (source.isClustered !== target.isClustered) {
    differences.push("Constraint clustering differs");
  }

  if (source.isDisabled !== target.isDisabled) {
    differences.push("Constraint disabled flag differs");
  }

  if (source.isNotTrusted !== target.isNotTrusted) {
    differences.push("Constraint trust flag differs");
  }

  return differences;
}

function compareForeignKeys(sourceForeignKeys: ForeignKeySchema[], targetForeignKeys: ForeignKeySchema[]): ForeignKeyDiff[] {
  const sourceMap = new Map(sourceForeignKeys.map((foreignKey) => [foreignKey.name.toLowerCase(), foreignKey]));
  const targetMap = new Map(targetForeignKeys.map((foreignKey) => [foreignKey.name.toLowerCase(), foreignKey]));
  const diffs: ForeignKeyDiff[] = [];

  sourceForeignKeys.forEach((sourceForeignKey) => {
    const key = sourceForeignKey.name.toLowerCase();
    const targetForeignKey = targetMap.get(key);
    if (!targetForeignKey) {
      diffs.push({
        name: sourceForeignKey.name,
        status: "missing",
        source: sourceForeignKey,
        differences: ["Missing in target"]
      });
      return;
    }

    const differences = listForeignKeyDifferences(sourceForeignKey, targetForeignKey);
    diffs.push({
      name: sourceForeignKey.name,
      status: differences.length > 0 ? "modified" : "match",
      source: sourceForeignKey,
      target: targetForeignKey,
      differences
    });
  });

  targetForeignKeys.forEach((targetForeignKey) => {
    const key = targetForeignKey.name.toLowerCase();
    if (sourceMap.has(key)) {
      return;
    }

    diffs.push({
      name: targetForeignKey.name,
      status: "extra",
      target: targetForeignKey,
      differences: ["Extra in target"]
    });
  });

  return diffs.sort(sortByDiffStatus);
}

function listForeignKeyDifferences(source: ForeignKeySchema, target: ForeignKeySchema): string[] {
  const differences: string[] = [];

  if (!equalsIgnoreCase(source.referencedSchema, target.referencedSchema)) {
    differences.push("Referenced schema differs");
  }

  if (!equalsIgnoreCase(source.referencedTable, target.referencedTable)) {
    differences.push("Referenced table differs");
  }

  if (!areForeignKeyColumnsEqual(source.columns, target.columns)) {
    differences.push("Foreign key columns differ");
  }

  if (!equalsIgnoreCase(source.onDeleteAction, target.onDeleteAction)) {
    differences.push("ON DELETE action differs");
  }

  if (!equalsIgnoreCase(source.onUpdateAction, target.onUpdateAction)) {
    differences.push("ON UPDATE action differs");
  }

  if (source.isDisabled !== target.isDisabled) {
    differences.push("Foreign key disabled flag differs");
  }

  if (source.isNotTrusted !== target.isNotTrusted) {
    differences.push("Foreign key trust flag differs");
  }

  return differences;
}

function comparePartitions(source?: PartitionSchema, target?: PartitionSchema): PartitionDiff | undefined {
  if (!source && !target) {
    return undefined;
  }

  if (source && !target) {
    return {
      status: "missing",
      source,
      differences: ["Missing in target"]
    };
  }

  if (!source && target) {
    return {
      status: "extra",
      target,
      differences: ["Extra in target"]
    };
  }

  const differences: string[] = [];

  if (!equalsIgnoreCase(source?.schemeName, target?.schemeName)) {
    differences.push("Partition scheme differs");
  }

  if (!equalsIgnoreCase(source?.functionName, target?.functionName)) {
    differences.push("Partition function differs");
  }

  if (!equalsIgnoreCase(source?.columnName, target?.columnName)) {
    differences.push("Partition column differs");
  }

  if ((source?.partitionCount ?? 0) !== (target?.partitionCount ?? 0)) {
    differences.push("Partition count differs");
  }

  return {
    status: differences.length > 0 ? "modified" : "match",
    source,
    target,
    differences
  };
}

function hasTableDifferences(
  columnDiffs: ColumnDiff[],
  indexDiffs: IndexDiff[],
  constraintDiffs: ConstraintDiff[],
  foreignKeyDiffs: ForeignKeyDiff[],
  partitionDiff?: PartitionDiff
): boolean {
  if (columnDiffs.some((d) => d.status !== "match")) {
    return true;
  }

  if (indexDiffs.some((d) => d.status !== "match")) {
    return true;
  }

  if (constraintDiffs.some((d) => d.status !== "match")) {
    return true;
  }

  if (foreignKeyDiffs.some((d) => d.status !== "match")) {
    return true;
  }

  if (partitionDiff && partitionDiff.status !== "match") {
    return true;
  }

  return false;
}

function sortByDiffStatus<T extends { status: ComparisonStatus; name: string }>(a: T, b: T): number {
  const statusDelta = statusOrder[a.status] - statusOrder[b.status];
  if (statusDelta !== 0) {
    return statusDelta;
  }

  return a.name.localeCompare(b.name);
}

function areIndexColumnsEqual(
  sourceColumns: { name: string; isDescending: boolean; isIncluded: boolean }[],
  targetColumns: { name: string; isDescending: boolean; isIncluded: boolean }[]
): boolean {
  if (sourceColumns.length !== targetColumns.length) {
    return false;
  }

  for (let i = 0; i < sourceColumns.length; i += 1) {
    const source = sourceColumns[i];
    const target = targetColumns[i];
    if (!equalsIgnoreCase(source.name, target.name)) {
      return false;
    }

    if (source.isDescending !== target.isDescending) {
      return false;
    }

    if (source.isIncluded !== target.isIncluded) {
      return false;
    }
  }

  return true;
}

function areConstraintColumnsEqual(
  sourceColumns: { name: string; isDescending: boolean }[],
  targetColumns: { name: string; isDescending: boolean }[]
): boolean {
  if (sourceColumns.length !== targetColumns.length) {
    return false;
  }

  for (let i = 0; i < sourceColumns.length; i += 1) {
    const source = sourceColumns[i];
    const target = targetColumns[i];
    if (!equalsIgnoreCase(source.name, target.name)) {
      return false;
    }

    if (source.isDescending !== target.isDescending) {
      return false;
    }
  }

  return true;
}

function areForeignKeyColumnsEqual(
  sourceColumns: { sourceColumn: string; referencedColumn: string }[],
  targetColumns: { sourceColumn: string; referencedColumn: string }[]
): boolean {
  if (sourceColumns.length !== targetColumns.length) {
    return false;
  }

  for (let i = 0; i < sourceColumns.length; i += 1) {
    const source = sourceColumns[i];
    const target = targetColumns[i];
    if (!equalsIgnoreCase(source.sourceColumn, target.sourceColumn)) {
      return false;
    }

    if (!equalsIgnoreCase(source.referencedColumn, target.referencedColumn)) {
      return false;
    }
  }

  return true;
}

function normalizeSqlDefinition(value?: string): string {
  if (!value) {
    return "";
  }

  let normalized = value.trim().toLowerCase();
  normalized = normalized.replace(/\s+/g, " ");

  // Remove nested wrapping parentheses introduced by SQL Server metadata for defaults/checks.
  while (normalized.startsWith("(") && normalized.endsWith(")")) {
    normalized = normalized.slice(1, -1).trim();
  }

  return normalized;
}

function equalsIgnoreCase(left?: string, right?: string): boolean {
  return (left ?? "").trim().toLowerCase() === (right ?? "").trim().toLowerCase();
}

function tableKey(schema: string, table: string): string {
  return `${schema.toLowerCase()}.${table.toLowerCase()}`;
}

export function sortTablesForDisplay(tables: TableComparisonResult[]): TableComparisonResult[] {
  return [...tables].sort((a, b) => {
    const statusDelta = statusOrder[a.status] - statusOrder[b.status];
    if (statusDelta !== 0) {
      return statusDelta;
    }

    return `${a.schemaName}.${a.tableName}`.localeCompare(`${b.schemaName}.${b.tableName}`);
  });
}
