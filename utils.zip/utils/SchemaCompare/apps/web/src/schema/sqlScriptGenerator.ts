import type {
  ColumnSchema,
  ForeignKeySchema,
  IndexSchema,
  SchemaComparisonResult,
  TableComparisonResult,
  TableConstraintSchema
} from "../types";

export interface ScriptGenerationOptions {
  includeDestructiveChanges?: boolean;
  wrapInTransaction?: boolean;
}

const defaultOptions: ScriptGenerationOptions = {
  includeDestructiveChanges: false,
  wrapInTransaction: false
};

interface TableScriptPlan {
  body: string;
  deferredForeignKeys: string[];
}

export function generateColumnAddScript(schemaName: string, tableName: string, column: ColumnSchema): string {
  return `ALTER TABLE ${qn(schemaName)}.${qn(tableName)}\nADD ${columnDefinition(column)};`;
}

export function generateColumnDropScript(schemaName: string, tableName: string, columnName: string): string {
  return `ALTER TABLE ${qn(schemaName)}.${qn(tableName)}\nDROP COLUMN ${qn(columnName)};`;
}

export function generateColumnAlterScript(schemaName: string, tableName: string, column: ColumnSchema): string {
  if (column.isComputed) {
    return `/* WARNING: Computed column ${qn(column.name)} requires manual ALTER script because expression metadata is unavailable. */`;
  }

  return `ALTER TABLE ${qn(schemaName)}.${qn(tableName)}\nALTER COLUMN ${columnDefinition(column, true)};`;
}

export function generateIndexCreateScript(schemaName: string, tableName: string, index: IndexSchema): string {
  const unique = index.isUnique ? "UNIQUE " : "";
  const type = index.type.toLowerCase().includes("clustered") ? "CLUSTERED" : "NONCLUSTERED";

  const keyColumns = index.columns
    .filter((c) => !c.isIncluded)
    .map((c) => `${qn(c.name)} ${c.isDescending ? "DESC" : "ASC"}`)
    .join(", ");

  const includedColumns = index.columns.filter((c) => c.isIncluded).map((c) => qn(c.name)).join(", ");

  const includeClause = includedColumns.length > 0 ? `\nINCLUDE (${includedColumns})` : "";

  return `CREATE ${unique}${type} INDEX ${qn(index.name)}\nON ${qn(schemaName)}.${qn(tableName)} (${keyColumns})${includeClause};`;
}

export function generateIndexDropScript(schemaName: string, tableName: string, indexName: string): string {
  return `DROP INDEX ${qn(indexName)} ON ${qn(schemaName)}.${qn(tableName)};`;
}

export function generateConstraintDropScript(schemaName: string, tableName: string, constraintName: string): string {
  return `ALTER TABLE ${qn(schemaName)}.${qn(tableName)}\nDROP CONSTRAINT ${qn(constraintName)};`;
}

export function generateConstraintAddScript(schemaName: string, tableName: string, constraint: TableConstraintSchema): string {
  const constraintType = constraint.type.toUpperCase();

  if (constraintType === "PRIMARY_KEY" || constraintType === "UNIQUE") {
    const keyword = constraintType === "PRIMARY_KEY" ? "PRIMARY KEY" : "UNIQUE";
    const clustered = constraint.isClustered ? "CLUSTERED" : "NONCLUSTERED";
    const columns = constraint.columns
      .map((column) => `${qn(column.name)} ${column.isDescending ? "DESC" : "ASC"}`)
      .join(", ");
    return `ALTER TABLE ${qn(schemaName)}.${qn(tableName)}\nADD CONSTRAINT ${qn(constraint.name)} ${keyword} ${clustered} (${columns});`;
  }

  if (constraintType === "CHECK") {
    if (!constraint.definition) {
      return `/* WARNING: CHECK constraint ${qn(constraint.name)} has no definition metadata. */`;
    }

    return [
      `ALTER TABLE ${qn(schemaName)}.${qn(tableName)} WITH CHECK`,
      `ADD CONSTRAINT ${qn(constraint.name)} CHECK ${constraint.definition};`,
      `ALTER TABLE ${qn(schemaName)}.${qn(tableName)} CHECK CONSTRAINT ${qn(constraint.name)};`
    ].join("\n");
  }

  if (constraintType === "DEFAULT") {
    if (!constraint.definition || constraint.columns.length === 0) {
      return `/* WARNING: DEFAULT constraint ${qn(constraint.name)} is missing definition or target column metadata. */`;
    }

    return `ALTER TABLE ${qn(schemaName)}.${qn(tableName)}\nADD CONSTRAINT ${qn(constraint.name)} DEFAULT ${constraint.definition} FOR ${qn(
      constraint.columns[0].name
    )};`;
  }

  return `/* WARNING: Unsupported constraint type ${constraint.type} for ${qn(constraint.name)}. */`;
}

export function generateForeignKeyDropScript(schemaName: string, tableName: string, foreignKeyName: string): string {
  return `ALTER TABLE ${qn(schemaName)}.${qn(tableName)}\nDROP CONSTRAINT ${qn(foreignKeyName)};`;
}

export function generateForeignKeyCreateScript(schemaName: string, tableName: string, foreignKey: ForeignKeySchema): string {
  const sourceColumns = foreignKey.columns.map((column) => qn(column.sourceColumn)).join(", ");
  const referencedColumns = foreignKey.columns.map((column) => qn(column.referencedColumn)).join(", ");
  const deleteClause = renderReferentialAction("DELETE", foreignKey.onDeleteAction);
  const updateClause = renderReferentialAction("UPDATE", foreignKey.onUpdateAction);

  return [
    `ALTER TABLE ${qn(schemaName)}.${qn(tableName)} WITH CHECK`,
    `ADD CONSTRAINT ${qn(foreignKey.name)} FOREIGN KEY (${sourceColumns})`,
    `REFERENCES ${qn(foreignKey.referencedSchema)}.${qn(foreignKey.referencedTable)} (${referencedColumns})${deleteClause}${updateClause};`,
    `ALTER TABLE ${qn(schemaName)}.${qn(tableName)} CHECK CONSTRAINT ${qn(foreignKey.name)};`
  ].join("\n");
}

export function generateTableSyncScript(table: TableComparisonResult, options?: ScriptGenerationOptions): string {
  const config: Required<ScriptGenerationOptions> = {
    includeDestructiveChanges: options?.includeDestructiveChanges ?? defaultOptions.includeDestructiveChanges ?? false,
    wrapInTransaction: options?.wrapInTransaction ?? defaultOptions.wrapInTransaction ?? false
  };
  const plan = buildTableScriptPlan(table, config, false);
  const sections = [plan.body, ...plan.deferredForeignKeys].filter((part) => part.trim().length > 0);
  return sections.join("\n\n");
}

export function generateFullMigrationScript(result: SchemaComparisonResult, options?: ScriptGenerationOptions): string {
  const config: Required<ScriptGenerationOptions> = {
    includeDestructiveChanges: options?.includeDestructiveChanges ?? defaultOptions.includeDestructiveChanges ?? false,
    wrapInTransaction: options?.wrapInTransaction ?? defaultOptions.wrapInTransaction ?? false
  };
  const plans = result.tables
    .filter((table) => table.status !== "match")
    .map((table) => buildTableScriptPlan(table, config, true));

  const tableScripts = plans.map((plan) => plan.body).filter((script) => script.trim().length > 0);
  const deferredForeignKeys = plans.flatMap((plan) => plan.deferredForeignKeys).filter((script) => script.trim().length > 0);

  const header = [
    "/*",
    "Schema comparison migration script",
    `Source: ${result.sourceConnectionName}`,
    `Target: ${result.targetConnectionName}`,
    `GeneratedAt: ${new Date().toISOString()}`,
    "*/",
    ""
  ];

  if (tableScripts.length === 0 && deferredForeignKeys.length === 0) {
    return [...header, "-- No differences detected."].join("\n");
  }

  const bodySections = [...tableScripts];
  if (deferredForeignKeys.length > 0) {
    bodySections.push("-- Deferred foreign keys");
    bodySections.push(...deferredForeignKeys);
  }

  const body = bodySections.join("\n\n");

  if (!config.wrapInTransaction) {
    return [...header, body].join("\n");
  }

  return [...header, "BEGIN TRANSACTION;", "", body, "", "COMMIT TRANSACTION;"].join("\n");
}

function buildTableScriptPlan(
  table: TableComparisonResult,
  options: Required<ScriptGenerationOptions>,
  deferForeignKeys: boolean
): TableScriptPlan {
  const lines: string[] = [];
  const deferredForeignKeys: string[] = [];

  lines.push(`-- Sync table ${table.schemaName}.${table.tableName}`);

  if (table.status === "extra") {
    if (options.includeDestructiveChanges) {
      lines.push("/* WARNING: Destructive operation enabled. */");
      lines.push(`DROP TABLE ${qn(table.schemaName)}.${qn(table.tableName)};`);
    } else {
      lines.push("/* INFO: Table exists only in target. Enable destructive mode to emit DROP TABLE. */");
    }

    return { body: lines.join("\n\n"), deferredForeignKeys };
  }

  if (table.status === "missing") {
    lines.push(generateCreateTableScript(table));
  }

  table.foreignKeyDiffs.forEach((diff) => {
    if (diff.status === "modified" || (diff.status === "extra" && options.includeDestructiveChanges)) {
      lines.push(generateForeignKeyDropScript(table.schemaName, table.tableName, diff.name));
    }
  });

  if (table.status !== "missing") {
    table.columnDiffs.forEach((diff) => {
      if (diff.status === "missing" && diff.source) {
        lines.push(generateColumnAddScript(table.schemaName, table.tableName, diff.source));
        return;
      }

      if (diff.status === "modified" && diff.source) {
        lines.push(generateColumnAlterScript(table.schemaName, table.tableName, diff.source));
        return;
      }

      if (diff.status === "extra" && options.includeDestructiveChanges) {
        lines.push(generateColumnDropScript(table.schemaName, table.tableName, diff.name));
      }
    });
  }

  table.constraintDiffs.forEach((diff) => {
    if (diff.status === "missing" && diff.source) {
      lines.push(generateConstraintAddScript(table.schemaName, table.tableName, diff.source));
      return;
    }

    if (diff.status === "modified") {
      lines.push(generateConstraintDropScript(table.schemaName, table.tableName, diff.name));
      if (diff.source) {
        lines.push(generateConstraintAddScript(table.schemaName, table.tableName, diff.source));
      }
      return;
    }

    if (diff.status === "extra" && options.includeDestructiveChanges) {
      lines.push(generateConstraintDropScript(table.schemaName, table.tableName, diff.name));
    }
  });

  table.indexDiffs.forEach((diff) => {
    if (diff.status === "missing" && diff.source) {
      lines.push(generateIndexCreateScript(table.schemaName, table.tableName, diff.source));
      return;
    }

    if (diff.status === "modified") {
      lines.push(generateIndexDropScript(table.schemaName, table.tableName, diff.name));
      if (diff.source) {
        lines.push(generateIndexCreateScript(table.schemaName, table.tableName, diff.source));
      }
      return;
    }

    if (diff.status === "extra" && options.includeDestructiveChanges) {
      lines.push(generateIndexDropScript(table.schemaName, table.tableName, diff.name));
    }
  });

  table.foreignKeyDiffs.forEach((diff) => {
    if ((diff.status === "missing" || diff.status === "modified") && diff.source) {
      const statement = generateForeignKeyCreateScript(table.schemaName, table.tableName, diff.source);
      if (deferForeignKeys) {
        deferredForeignKeys.push(statement);
      } else {
        lines.push(statement);
      }
      return;
    }

    if (diff.status === "extra" && !options.includeDestructiveChanges) {
      lines.push(`/* INFO: Extra foreign key ${qn(diff.name)} found in target. Enable destructive mode to drop it. */`);
    }
  });

  if (table.partitionDiff && table.partitionDiff.status !== "match") {
    lines.push("/* WARNING: Partition differences detected; manual intervention required. */");
  }

  const body = lines.filter((line) => line.trim().length > 0).join("\n\n");
  return { body, deferredForeignKeys };
}

function generateCreateTableScript(table: TableComparisonResult): string {
  const sourceColumns = table.columnDiffs
    .map((diff) => diff.source)
    .filter((column): column is ColumnSchema => Boolean(column));

  const computedColumns = sourceColumns.filter((column) => column.isComputed);
  const concreteColumns = sourceColumns.filter((column) => !column.isComputed);

  if (concreteColumns.length === 0) {
    return `/* WARNING: Table ${qn(table.schemaName)}.${qn(table.tableName)} has no non-computed columns available for CREATE TABLE generation. */`;
  }

  const columnLines = concreteColumns.map((column) => `  ${columnDefinition(column)}`);

  const lines = [
    `CREATE TABLE ${qn(table.schemaName)}.${qn(table.tableName)} (`,
    `${columnLines.join(",\n")}`,
    `);`
  ];

  if (computedColumns.length > 0) {
    lines.push(
      `/* WARNING: Computed columns not auto-generated: ${computedColumns.map((column) => qn(column.name)).join(", ")}. Add manually. */`
    );
  }

  return lines.join("\n");
}

function qn(identifier: string): string {
  return `[${identifier.replace(/]/g, "]]")}]`;
}

function columnDefinition(column: ColumnSchema, forAlter = false): string {
  const dataType = renderDataType(column);
  const nullable = column.isNullable ? "NULL" : "NOT NULL";

  if (forAlter || column.isComputed) {
    return `${qn(column.name)} ${dataType} ${nullable}`;
  }

  const defaultClause = column.defaultValue ? ` DEFAULT ${column.defaultValue}` : "";
  const identityClause = column.isIdentity ? " IDENTITY(1,1)" : "";

  return `${qn(column.name)} ${dataType}${identityClause} ${nullable}${defaultClause}`;
}

function renderDataType(column: ColumnSchema): string {
  const type = column.dataType.toLowerCase();

  if (["varchar", "nvarchar", "char", "nchar", "varbinary", "binary"].includes(type)) {
    const length = column.maxLength === -1 || column.maxLength === undefined ? "max" : `${column.maxLength}`;
    return `${type}(${length})`;
  }

  if (["decimal", "numeric"].includes(type)) {
    const precision = column.precision ?? 18;
    const scale = column.scale ?? 0;
    return `${type}(${precision},${scale})`;
  }

  if (["datetime2", "datetimeoffset", "time"].includes(type) && typeof column.scale === "number") {
    return `${type}(${column.scale})`;
  }

  return type;
}

function renderReferentialAction(kind: "DELETE" | "UPDATE", value: string): string {
  const normalized = value.trim().toUpperCase().replace(/_/g, " ");
  if (!normalized || normalized === "NO ACTION") {
    return "";
  }

  return `\nON ${kind} ${normalized}`;
}
