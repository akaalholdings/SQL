interface Props {
  label?: string;
  onClick: () => void;
  disabled?: boolean;
}

export function GenerateScriptButton({ label = "Generate Script", onClick, disabled }: Props) {
  return (
    <button className="secondary" onClick={onClick} disabled={disabled}>
      {label}
    </button>
  );
}
