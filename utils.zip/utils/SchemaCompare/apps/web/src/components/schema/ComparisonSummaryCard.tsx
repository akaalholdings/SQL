import type { SchemaComparisonSummary } from "../../types";
import { GenerateScriptButton } from "./GenerateScriptButton";

interface Props {
  summary: SchemaComparisonSummary;
  onGenerateFullScript: () => void;
}

export function ComparisonSummaryCard({ summary, onGenerateFullScript }: Props) {
  return (
    <section className="card compare-summary-card">
      <div className="summary-grid">
        <SummaryStat label="Match" value={summary.matching} tone="match" />
        <SummaryStat label="Modified" value={summary.modified} tone="modified" />
        <SummaryStat label="Missing" value={summary.missingInTarget} tone="missing" />
        <SummaryStat label="Extra" value={summary.extraInTarget} tone="extra" />
      </div>
      <div className="summary-actions">
        <div className="meta">Total tables compared: {summary.totalTables}</div>
        <GenerateScriptButton label="Full Migration Script" onClick={onGenerateFullScript} />
      </div>
    </section>
  );
}

function SummaryStat({
  label,
  value,
  tone
}: {
  label: string;
  value: number;
  tone: "match" | "modified" | "missing" | "extra";
}) {
  return (
    <div className={`summary-stat summary-${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
