import type { IndexDiff, IndexSchema } from "../../types";
import { ComparisonStatusIcon } from "./ComparisonStatusIcon";

interface Props {
  diffs: IndexDiff[];
}

export function IndexComparisonTable({ diffs }: Props) {
  return (
    <div className="compare-table-wrap">
      <table className="compare-table">
        <thead>
          <tr>
            <th>Index</th>
            <th>Source Definition</th>
            <th>Target Definition</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {diffs.map((diff) => (
            <tr key={diff.name}>
              <td>
                <div className="mono">{diff.name}</div>
                {diff.differences.length > 0 && diff.status !== "match" ? (
                  <div className="meta">{diff.differences.join(", ")}</div>
                ) : null}
              </td>
              <td className="mono">{renderIndex(diff.source)}</td>
              <td className="mono">{renderIndex(diff.target)}</td>
              <td>
                <ComparisonStatusIcon status={diff.status} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function renderIndex(index?: IndexSchema): string {
  if (!index) {
    return "-";
  }

  const columnList = index.columns
    .map((column) => `${column.name}${column.isIncluded ? " (inc)" : ""}${column.isDescending ? " desc" : ""}`)
    .join(", ");

  return `${index.type.toLowerCase()}${index.isUnique ? " unique" : ""}${index.isPrimaryKey ? " pk" : ""} (${columnList})`;
}
