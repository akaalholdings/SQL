import { ComparisonStatusIcon } from "./ComparisonStatusIcon";
import type { ColumnDiff, ColumnSchema } from "../../types";

interface Props {
  diffs: ColumnDiff[];
}

export function ColumnComparisonTable({ diffs }: Props) {
  return (
    <div className="compare-table-wrap">
      <table className="compare-table">
        <thead>
          <tr>
            <th>Column</th>
            <th>Source Type</th>
            <th>Target Type</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {diffs.map((diff) => (
            <tr key={diff.name}>
              <td>
                <div className="mono">{diff.name}</div>
                {diff.differences.length > 0 && diff.status !== "match" ? (
                  <div className="meta">{diff.differences.join(", ")}</div>
                ) : null}
              </td>
              <td className="mono">{renderColumnType(diff.source)}</td>
              <td className="mono">{renderColumnType(diff.target)}</td>
              <td>
                <ComparisonStatusIcon status={diff.status} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function renderColumnType(column?: ColumnSchema): string {
  if (!column) {
    return "-";
  }

  const base = column.dataType.toLowerCase();
  let shape = base;

  if (["varchar", "nvarchar", "char", "nchar", "varbinary", "binary"].includes(base)) {
    shape = `${base}(${column.maxLength === -1 || column.maxLength === undefined ? "max" : column.maxLength})`;
  } else if (["decimal", "numeric"].includes(base)) {
    shape = `${base}(${column.precision ?? 18},${column.scale ?? 0})`;
  }

  return `${shape} ${column.isNullable ? "NULL" : "NOT NULL"}`;
}
