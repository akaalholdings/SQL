import type { PartitionDiff } from "../../types";
import { ComparisonStatusIcon } from "./ComparisonStatusIcon";

interface Props {
  diff?: PartitionDiff;
}

export function PartitionComparisonCard({ diff }: Props) {
  if (!diff) {
    return <div className="empty">No partition metadata found.</div>;
  }

  return (
    <div className="partition-card">
      <div className="partition-header">
        <ComparisonStatusIcon status={diff.status} />
      </div>
      <div className="partition-grid">
        <PartitionBlock
          title="Source"
          scheme={diff.source?.schemeName}
          fn={diff.source?.functionName}
          column={diff.source?.columnName}
          count={diff.source?.partitionCount}
        />
        <PartitionBlock
          title="Target"
          scheme={diff.target?.schemeName}
          fn={diff.target?.functionName}
          column={diff.target?.columnName}
          count={diff.target?.partitionCount}
        />
      </div>
      {diff.differences.length > 0 && diff.status !== "match" ? (
        <div className="meta">{diff.differences.join(", ")}</div>
      ) : null}
    </div>
  );
}

function PartitionBlock({
  title,
  scheme,
  fn,
  column,
  count
}: {
  title: string;
  scheme?: string;
  fn?: string;
  column?: string;
  count?: number;
}) {
  return (
    <div className="partition-block">
      <strong>{title}</strong>
      <div>Scheme: {scheme ?? "-"}</div>
      <div>Function: {fn ?? "-"}</div>
      <div>Column: {column ?? "-"}</div>
      <div>Count: {count ?? 0}</div>
    </div>
  );
}
