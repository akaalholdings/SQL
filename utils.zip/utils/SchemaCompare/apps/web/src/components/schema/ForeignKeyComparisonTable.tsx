import type { ForeignKeyDiff, ForeignKeySchema } from "../../types";
import { ComparisonStatusIcon } from "./ComparisonStatusIcon";

interface Props {
  diffs: ForeignKeyDiff[];
}

export function ForeignKeyComparisonTable({ diffs }: Props) {
  return (
    <div className="compare-table-wrap">
      <table className="compare-table">
        <thead>
          <tr>
            <th>Foreign Key</th>
            <th>Source Definition</th>
            <th>Target Definition</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {diffs.map((diff) => (
            <tr key={diff.name}>
              <td>
                <div className="mono">{diff.name}</div>
                {diff.differences.length > 0 && diff.status !== "match" ? (
                  <div className="meta">{diff.differences.join(", ")}</div>
                ) : null}
              </td>
              <td className="mono">{renderForeignKey(diff.source)}</td>
              <td className="mono">{renderForeignKey(diff.target)}</td>
              <td>
                <ComparisonStatusIcon status={diff.status} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function renderForeignKey(foreignKey?: ForeignKeySchema): string {
  if (!foreignKey) {
    return "-";
  }

  const columnPairs = foreignKey.columns
    .map((column) => `${column.sourceColumn}->${column.referencedColumn}`)
    .join(", ");

  return `${foreignKey.referencedSchema}.${foreignKey.referencedTable} (${columnPairs}) del:${foreignKey.onDeleteAction} upd:${foreignKey.onUpdateAction}`;
}
