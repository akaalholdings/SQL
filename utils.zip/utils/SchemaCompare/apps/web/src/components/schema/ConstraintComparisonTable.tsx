import type { ConstraintDiff, TableConstraintSchema } from "../../types";
import { ComparisonStatusIcon } from "./ComparisonStatusIcon";

interface Props {
  diffs: ConstraintDiff[];
}

export function ConstraintComparisonTable({ diffs }: Props) {
  return (
    <div className="compare-table-wrap">
      <table className="compare-table">
        <thead>
          <tr>
            <th>Constraint</th>
            <th>Source Definition</th>
            <th>Target Definition</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {diffs.map((diff) => (
            <tr key={diff.name}>
              <td>
                <div className="mono">{diff.name}</div>
                {diff.differences.length > 0 && diff.status !== "match" ? (
                  <div className="meta">{diff.differences.join(", ")}</div>
                ) : null}
              </td>
              <td className="mono">{renderConstraint(diff.source)}</td>
              <td className="mono">{renderConstraint(diff.target)}</td>
              <td>
                <ComparisonStatusIcon status={diff.status} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function renderConstraint(constraint?: TableConstraintSchema): string {
  if (!constraint) {
    return "-";
  }

  const type = constraint.type.toLowerCase();
  const columns = constraint.columns
    .map((column) => `${column.name}${column.isDescending ? " desc" : ""}`)
    .join(", ");
  const cluster = constraint.isClustered ? " clustered" : " nonclustered";
  const definition = constraint.definition ? ` ${constraint.definition}` : "";
  return `${type}${type === "primary_key" || type === "unique" ? cluster : ""} (${columns})${definition}`.trim();
}
