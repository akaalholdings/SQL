import type { ComparisonStatus } from "../../types";

interface Props {
  status: ComparisonStatus;
  showLabel?: boolean;
}

const statusConfig: Record<ComparisonStatus, { icon: string; label: string }> = {
  match: { icon: "=", label: "Match" },
  modified: { icon: "!", label: "Modified" },
  missing: { icon: "-", label: "Missing" },
  extra: { icon: "+", label: "Extra" }
};

export function ComparisonStatusIcon({ status, showLabel = true }: Props) {
  const config = statusConfig[status];

  return (
    <span className={`status-pill-tag status-${status}`}>
      <strong>{config.icon}</strong>
      {showLabel ? <span>{config.label}</span> : null}
    </span>
  );
}
