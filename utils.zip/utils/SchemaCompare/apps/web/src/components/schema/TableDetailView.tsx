import { useMemo, useState } from "react";
import type { TableComparisonResult } from "../../types";
import { ColumnComparisonTable } from "./ColumnComparisonTable";
import { ComparisonStatusIcon } from "./ComparisonStatusIcon";
import { ConstraintComparisonTable } from "./ConstraintComparisonTable";
import { ForeignKeyComparisonTable } from "./ForeignKeyComparisonTable";
import { GenerateScriptButton } from "./GenerateScriptButton";
import { IndexComparisonTable } from "./IndexComparisonTable";
import { PartitionComparisonCard } from "./PartitionComparisonCard";

type TabId = "columns" | "indexes" | "constraints" | "foreignKeys" | "partitions";

interface Props {
  table?: TableComparisonResult;
  onGenerateScript: () => void;
}

export function TableDetailView({ table, onGenerateScript }: Props) {
  const [activeTab, setActiveTab] = useState<TabId>("columns");

  const counts = useMemo(() => {
    if (!table) {
      return { columns: 0, indexes: 0, constraints: 0, foreignKeys: 0, partitions: 0 };
    }

    return {
      columns: table.columnDiffs.filter((d) => d.status !== "match").length,
      indexes: table.indexDiffs.filter((d) => d.status !== "match").length,
      constraints: table.constraintDiffs.filter((d) => d.status !== "match").length,
      foreignKeys: table.foreignKeyDiffs.filter((d) => d.status !== "match").length,
      partitions: table.partitionDiff && table.partitionDiff.status !== "match" ? 1 : 0
    };
  }, [table]);

  if (!table) {
    return <div className="empty">Run compare and select a table to inspect details.</div>;
  }

  return (
    <div className="detail-view">
      <div className="detail-header">
        <div>
          <h3>
            {table.schemaName}.{table.tableName}
          </h3>
          <ComparisonStatusIcon status={table.status} />
        </div>
        <GenerateScriptButton onClick={onGenerateScript} />
      </div>

      <div className="detail-tabs">
        <button className={activeTab === "columns" ? "active" : ""} onClick={() => setActiveTab("columns")}>
          Columns ({counts.columns})
        </button>
        <button className={activeTab === "indexes" ? "active" : ""} onClick={() => setActiveTab("indexes")}>
          Indexes ({counts.indexes})
        </button>
        <button className={activeTab === "constraints" ? "active" : ""} onClick={() => setActiveTab("constraints")}>
          Constraints ({counts.constraints})
        </button>
        <button className={activeTab === "foreignKeys" ? "active" : ""} onClick={() => setActiveTab("foreignKeys")}>
          Foreign Keys ({counts.foreignKeys})
        </button>
        <button className={activeTab === "partitions" ? "active" : ""} onClick={() => setActiveTab("partitions")}>
          Partitions ({counts.partitions})
        </button>
      </div>

      {activeTab === "columns" ? <ColumnComparisonTable diffs={table.columnDiffs} /> : null}
      {activeTab === "indexes" ? <IndexComparisonTable diffs={table.indexDiffs} /> : null}
      {activeTab === "constraints" ? <ConstraintComparisonTable diffs={table.constraintDiffs} /> : null}
      {activeTab === "foreignKeys" ? <ForeignKeyComparisonTable diffs={table.foreignKeyDiffs} /> : null}
      {activeTab === "partitions" ? <PartitionComparisonCard diff={table.partitionDiff} /> : null}
    </div>
  );
}
