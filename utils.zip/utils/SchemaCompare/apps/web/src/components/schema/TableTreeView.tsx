import { useEffect, useMemo, useState } from "react";
import type { ComparisonStatus, TableComparisonResult } from "../../types";
import { ComparisonStatusIcon } from "./ComparisonStatusIcon";

interface Props {
  tables: TableComparisonResult[];
  selectedTableKey?: string;
  onSelectTable: (tableKey: string) => void;
  onFilteredTablesChange?: (tables: TableComparisonResult[]) => void;
}

export function TableTreeView({ tables, selectedTableKey, onSelectTable, onFilteredTablesChange }: Props) {
  const [searchQuery, setSearchQuery] = useState("");
  const [schemaFilter, setSchemaFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | ComparisonStatus>("all");
  const [collapsedSchemas, setCollapsedSchemas] = useState<Record<string, boolean>>({});

  const schemaOptions = useMemo(() => {
    return Array.from(new Set(tables.map((table) => table.schemaName))).sort((a, b) => a.localeCompare(b));
  }, [tables]);

  const filteredTables = useMemo(() => {
    return tables.filter((table) => {
      if (schemaFilter !== "all" && table.schemaName !== schemaFilter) {
        return false;
      }

      if (statusFilter !== "all" && table.status !== statusFilter) {
        return false;
      }

      if (!searchQuery.trim()) {
        return true;
      }

      const token = searchQuery.trim().toLowerCase();
      return `${table.schemaName}.${table.tableName}`.toLowerCase().includes(token);
    });
  }, [tables, schemaFilter, statusFilter, searchQuery]);

  useEffect(() => {
    onFilteredTablesChange?.(filteredTables);
  }, [filteredTables, onFilteredTablesChange]);

  const groupedTables = useMemo(() => {
    const groups = new Map<string, TableComparisonResult[]>();
    filteredTables.forEach((table) => {
      const group = groups.get(table.schemaName) ?? [];
      group.push(table);
      groups.set(table.schemaName, group);
    });

    return Array.from(groups.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [filteredTables]);

  return (
    <div className="tree-panel">
      <input
        placeholder="Search schema.table"
        value={searchQuery}
        onChange={(event) => setSearchQuery(event.target.value)}
      />
      <div className="tree-filters">
        <select value={schemaFilter} onChange={(event) => setSchemaFilter(event.target.value)}>
          <option value="all">All schemas</option>
          {schemaOptions.map((schemaName) => (
            <option value={schemaName} key={schemaName}>
              {schemaName}
            </option>
          ))}
        </select>
        <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value as "all" | ComparisonStatus)}>
          <option value="all">All statuses</option>
          <option value="missing">Missing</option>
          <option value="modified">Modified</option>
          <option value="extra">Extra</option>
          <option value="match">Match</option>
        </select>
      </div>
      <div className="tree-list">
        {groupedTables.map(([schemaName, schemaTables]) => {
          const collapsed = collapsedSchemas[schemaName] ?? false;

          return (
            <div className="tree-group" key={schemaName}>
              <button
                className="tree-group-title"
                onClick={() =>
                  setCollapsedSchemas((current) => ({
                    ...current,
                    [schemaName]: !collapsed
                  }))
                }
              >
                <span>{collapsed ? ">" : "v"}</span>
                <strong>{schemaName}</strong>
                <span className="meta">({schemaTables.length})</span>
              </button>

              {!collapsed ? (
                <div className="tree-items">
                  {schemaTables.map((table) => {
                    const key = buildTableKey(table.schemaName, table.tableName);
                    return (
                      <button
                        key={key}
                        className={`tree-item ${selectedTableKey === key ? "active" : ""}`}
                        onClick={() => onSelectTable(key)}
                      >
                        <ComparisonStatusIcon status={table.status} showLabel={false} />
                        <span>{table.tableName}</span>
                      </button>
                    );
                  })}
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function buildTableKey(schemaName: string, tableName: string): string {
  return `${schemaName}.${tableName}`.toLowerCase();
}
