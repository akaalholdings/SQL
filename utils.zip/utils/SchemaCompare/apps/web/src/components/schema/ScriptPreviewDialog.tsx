interface Props {
  isOpen: boolean;
  title: string;
  script: string;
  wrapInTransaction: boolean;
  includeDestructiveChanges: boolean;
  onWrapInTransactionChange: (value: boolean) => void;
  onIncludeDestructiveChangesChange: (value: boolean) => void;
  onCopy: () => void;
  onDownload: () => void;
  onClose: () => void;
}

export function ScriptPreviewDialog({
  isOpen,
  title,
  script,
  wrapInTransaction,
  includeDestructiveChanges,
  onWrapInTransactionChange,
  onIncludeDestructiveChangesChange,
  onCopy,
  onDownload,
  onClose
}: Props) {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog-card" onClick={(event) => event.stopPropagation()}>
        <div className="dialog-header">
          <h3>{title}</h3>
          <button className="ghost" onClick={onClose}>
            Close
          </button>
        </div>

        <div className="dialog-options">
          <label>
            <input
              type="checkbox"
              checked={wrapInTransaction}
              onChange={(event) => onWrapInTransactionChange(event.target.checked)}
            />
            Wrap in transaction
          </label>
          <label>
            <input
              type="checkbox"
              checked={includeDestructiveChanges}
              onChange={(event) => onIncludeDestructiveChangesChange(event.target.checked)}
            />
            Include destructive changes
          </label>
        </div>

        <pre className="code-block script-dialog-content">{script}</pre>

        <div className="dialog-actions">
          <button className="secondary" onClick={onCopy}>
            Copy
          </button>
          <button className="primary" onClick={onDownload}>
            Download .sql
          </button>
        </div>
      </div>
    </div>
  );
}
