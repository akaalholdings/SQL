import { useState } from "react";
import type { ExportFormat } from "../../schema/schemaExport";

interface Props {
  disabled?: boolean;
  onExport: (format: ExportFormat) => void;
}

export function ExportReportButton({ disabled, onExport }: Props) {
  const [format, setFormat] = useState<ExportFormat>("json");

  return (
    <div className="export-inline">
      <select value={format} onChange={(event) => setFormat(event.target.value as ExportFormat)} disabled={disabled}>
        <option value="json">JSON</option>
        <option value="csv">CSV</option>
        <option value="markdown">Markdown</option>
        <option value="sql">SQL</option>
      </select>
      <button className="ghost" disabled={disabled} onClick={() => onExport(format)}>
        Export
      </button>
    </div>
  );
}
