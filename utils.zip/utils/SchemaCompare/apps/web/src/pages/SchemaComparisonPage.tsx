import { useEffect, useMemo, useState } from "react";
import { apiFetch } from "../api";
import type {
  DatabaseSchema,
  Environment,
  SchemaComparisonResult,
  TableComparisonResult
} from "../types";
import { compareSchemas } from "../schema/schemaComparison";
import {
  generateFullMigrationScript,
  generateTableSyncScript,
  type ScriptGenerationOptions
} from "../schema/sqlScriptGenerator";
import { buildExportContent, downloadTextFile, type ExportFormat } from "../schema/schemaExport";
import { ComparisonSummaryCard } from "../components/schema/ComparisonSummaryCard";
import { ExportReportButton } from "../components/schema/ExportReportButton";
import { ScriptPreviewDialog } from "../components/schema/ScriptPreviewDialog";
import { TableDetailView } from "../components/schema/TableDetailView";
import { TableTreeView, buildTableKey } from "../components/schema/TableTreeView";

type ScriptMode = "full" | "table";

export function SchemaComparisonPage() {
  const [environments, setEnvironments] = useState<Environment[]>([]);
  const [sourceId, setSourceId] = useState<string>("");
  const [targetId, setTargetId] = useState<string>("");
  const [comparison, setComparison] = useState<SchemaComparisonResult | null>(null);
  const [selectedTableKey, setSelectedTableKey] = useState<string>("");
  const [visibleTables, setVisibleTables] = useState<TableComparisonResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [scriptMode, setScriptMode] = useState<ScriptMode>("full");
  const [scriptOptions, setScriptOptions] = useState<ScriptGenerationOptions>({
    wrapInTransaction: false,
    includeDestructiveChanges: false
  });

  const selectedTable = useMemo(() => {
    if (!comparison || !selectedTableKey) {
      return undefined;
    }

    return comparison.tables.find((table) => buildTableKey(table.schemaName, table.tableName) === selectedTableKey);
  }, [comparison, selectedTableKey]);

  const scriptTitle = scriptMode === "full" ? "Full Migration Script" : "Table Sync Script";

  const scriptText = useMemo(() => {
    if (!comparison) {
      return "";
    }

    if (scriptMode === "table") {
      if (!selectedTable) {
        return "-- Select a table to generate a script.";
      }

      return generateTableSyncScript(selectedTable, scriptOptions);
    }

    return generateFullMigrationScript(comparison, scriptOptions);
  }, [comparison, scriptMode, selectedTable, scriptOptions]);

  useEffect(() => {
    apiFetch<Environment[]>("/environments")
      .then((items) => {
        setEnvironments(items);
        if (items.length === 0) {
          return;
        }

        const defaultSource = items.find((env) => env.type.toLowerCase() === "prod") ?? items[0];
        const defaultTarget =
          items.find((env) => env.id !== defaultSource.id && ["dev", "test", "staging"].includes(env.type.toLowerCase())) ??
          items.find((env) => env.id !== defaultSource.id) ??
          defaultSource;

        setSourceId(defaultSource.id);
        setTargetId(defaultTarget.id);
      })
      .catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    if (!comparison) {
      return;
    }

    if (!selectedTableKey) {
      const firstDiff = comparison.tables.find((table) => table.status !== "match") ?? comparison.tables[0];
      if (firstDiff) {
        setSelectedTableKey(buildTableKey(firstDiff.schemaName, firstDiff.tableName));
      }
      return;
    }

    const stillExists = comparison.tables.some(
      (table) => buildTableKey(table.schemaName, table.tableName) === selectedTableKey
    );

    if (!stillExists) {
      const first = comparison.tables[0];
      if (first) {
        setSelectedTableKey(buildTableKey(first.schemaName, first.tableName));
      }
    }
  }, [comparison, selectedTableKey]);

  useEffect(() => {
    if (visibleTables.length === 0 || !selectedTableKey) {
      return;
    }

    const inVisible = visibleTables.some(
      (table) => buildTableKey(table.schemaName, table.tableName) === selectedTableKey
    );

    if (!inVisible) {
      const first = visibleTables[0];
      setSelectedTableKey(buildTableKey(first.schemaName, first.tableName));
    }
  }, [visibleTables, selectedTableKey]);

  const runCompare = async () => {
    if (!sourceId || !targetId) {
      setError("Select both source and target.");
      return;
    }

    if (sourceId === targetId) {
      setError("Source and target must be different environments.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const [sourceSchema, targetSchema] = await Promise.all([
        apiFetch<DatabaseSchema>(`/environments/${sourceId}/schema`),
        apiFetch<DatabaseSchema>(`/environments/${targetId}/schema`)
      ]);

      const result = compareSchemas(sourceSchema, targetSchema);
      setComparison(result);
      const firstDiff = result.tables.find((table) => table.status !== "match") ?? result.tables[0];
      setSelectedTableKey(firstDiff ? buildTableKey(firstDiff.schemaName, firstDiff.tableName) : "");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const switchTargetEnvironment = (envType: "dev" | "test" | "staging") => {
    const candidate = environments.find((env) => env.type.toLowerCase() === envType && env.id !== sourceId);
    if (candidate) {
      setTargetId(candidate.id);
    }
  };

  const handleExport = (format: ExportFormat) => {
    if (!comparison) {
      return;
    }

    const content = buildExportContent(comparison, format, scriptOptions);
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const extension = format === "markdown" ? "md" : format;
    const mime = format === "json" ? "application/json" : format === "csv" ? "text/csv" : "text/plain";
    downloadTextFile(`schema-compare-${stamp}.${extension}`, content, mime);
  };

  const copyScript = async () => {
    await navigator.clipboard.writeText(scriptText);
  };

  const downloadScript = () => {
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    downloadTextFile(`schema-sync-${stamp}.sql`, scriptText, "text/sql");
  };

  return (
    <div className="page">
      <section className="page-header">
        <div>
          <h1>Schema Comparison</h1>
          <p>Compare production schema against lower environments and generate synchronization scripts.</p>
        </div>
        <ExportReportButton disabled={!comparison} onExport={handleExport} />
      </section>

      {error ? <div className="error">{error}</div> : null}

      <section className="card env-selector-card">
        <div className="env-selector-row">
          <div>
            <label>Source (Production)</label>
            <select value={sourceId} onChange={(event) => setSourceId(event.target.value)}>
              {environments.map((env) => (
                <option value={env.id} key={env.id}>
                  {env.name} ({env.type})
                </option>
              ))}
            </select>
          </div>

          <div className="arrow">-&gt;</div>

          <div>
            <label>Target (Lower Environment)</label>
            <select value={targetId} onChange={(event) => setTargetId(event.target.value)}>
              {environments.map((env) => (
                <option value={env.id} key={env.id}>
                  {env.name} ({env.type})
                </option>
              ))}
            </select>
          </div>

          <button className="primary" onClick={runCompare} disabled={loading || !sourceId || !targetId || sourceId === targetId}>
            {loading ? "Comparing..." : "Compare"}
          </button>
        </div>

        <div className="quick-switch-row">
          <span className="meta">Quick switch:</span>
          <button className="ghost" onClick={() => switchTargetEnvironment("dev")}>
            DEV
          </button>
          <button className="ghost" onClick={() => switchTargetEnvironment("test")}>
            TEST
          </button>
          <button className="ghost" onClick={() => switchTargetEnvironment("staging")}>
            STAGING
          </button>
        </div>
      </section>

      {comparison ? (
        <>
          <ComparisonSummaryCard
            summary={comparison.summary}
            onGenerateFullScript={() => {
              setScriptMode("full");
              setDialogOpen(true);
            }}
          />

          <section className="compare-main-grid">
            <div className="card">
              <TableTreeView
                tables={comparison.tables}
                selectedTableKey={selectedTableKey}
                onSelectTable={setSelectedTableKey}
                onFilteredTablesChange={setVisibleTables}
              />
            </div>

            <div className="card">
              <TableDetailView
                table={selectedTable}
                onGenerateScript={() => {
                  setScriptMode("table");
                  setDialogOpen(true);
                }}
              />
            </div>
          </section>
        </>
      ) : (
        <div className="empty">Choose environments and run compare to view differences.</div>
      )}

      <ScriptPreviewDialog
        isOpen={dialogOpen}
        title={scriptTitle}
        script={scriptText}
        wrapInTransaction={Boolean(scriptOptions.wrapInTransaction)}
        includeDestructiveChanges={Boolean(scriptOptions.includeDestructiveChanges)}
        onWrapInTransactionChange={(value) =>
          setScriptOptions((current) => ({
            ...current,
            wrapInTransaction: value
          }))
        }
        onIncludeDestructiveChangesChange={(value) =>
          setScriptOptions((current) => ({
            ...current,
            includeDestructiveChanges: value
          }))
        }
        onCopy={copyScript}
        onDownload={downloadScript}
        onClose={() => setDialogOpen(false)}
      />
    </div>
  );
}
