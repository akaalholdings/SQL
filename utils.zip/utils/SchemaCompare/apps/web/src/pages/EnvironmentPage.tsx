import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { apiFetch } from "../api";
import type { Environment, EnvironmentStatus, MigrationHistoryResponse } from "../types";

export function EnvironmentPage() {
  const { id } = useParams();
  const [environment, setEnvironment] = useState<Environment | null>(null);
  const [status, setStatus] = useState<EnvironmentStatus | null>(null);
  const [history, setHistory] = useState<MigrationHistoryResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [runOutput, setRunOutput] = useState<string>("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!id) return;
    Promise.all([
      apiFetch<Environment>(`/environments/${id}`),
      apiFetch<EnvironmentStatus>(`/environments/${id}/status`),
      apiFetch<MigrationHistoryResponse>(`/environments/${id}/history`)
    ])
      .then(([env, envStatus, envHistory]) => {
        setEnvironment(env);
        setStatus(envStatus);
        setHistory(envHistory);
      })
      .catch((err) => setError(err.message));
  }, [id]);

  const runValidate = async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ driftDetected: boolean; output: string; error: string; runId: string }>(
        `/environments/${id}/validate`,
        { method: "POST" }
      );
      setRunOutput(res.output || res.error || "Validation complete.");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const runPlan = async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ pending: any[]; appliedCount: number }>(`/environments/${id}/plan`, {
        method: "POST"
      });
      setRunOutput(`Pending migrations (${res.pending.length}):\n` + res.pending.map((m) => m.script).join("\n"));
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const runMigrate = async () => {
    if (!id || !environment) return;
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<any>(`/environments/${id}/migrate`, {
        method: "POST",
        body: JSON.stringify({ dryRun: false, confirmation: confirm })
      });
      setRunOutput(res.output || res.error || "Migration completed.");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!environment) {
    return <div className="page">Loading environment...</div>;
  }

  return (
    <div className="page">
      <section className="page-header">
        <div>
          <h1>{environment.name}</h1>
          <p>
            {environment.server}/{environment.database} · {environment.type.toUpperCase()} · schema {environment.schema}
          </p>
        </div>
        {status ? (
          <div className="status-pill">
            <span>Pending {status.pendingCount}</span>
            <span>Applied {status.appliedCount}</span>
            <span>Current {status.currentVersion || "—"}</span>
          </div>
        ) : null}
      </section>

      {error ? <div className="error">{error}</div> : null}

      <div className="split">
        <div className="card">
          <h3>Actions</h3>
          <div className="action-row">
            <button className="secondary" onClick={runValidate} disabled={loading}>
              Validate
            </button>
            <button className="secondary" onClick={runPlan} disabled={loading}>
              Dry Run
            </button>
            <button className="primary" onClick={runMigrate} disabled={loading}>
              Migrate
            </button>
          </div>
          {environment.type.toLowerCase() === "prod" ? (
            <div className="confirm">
              <label>Prod confirmation (type database name)</label>
              <input value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder={environment.database} />
            </div>
          ) : null}
          <div className="log">
            <div className="log-header">Run output</div>
            <pre>{runOutput || "No runs yet."}</pre>
          </div>
        </div>
        <div className="card">
          <h3>Pending migrations</h3>
          <div className="table">
            <div className="table-header">
              <span>Version</span>
              <span>Description</span>
              <span>Script</span>
            </div>
            {history?.pending.map((m, idx) => (
              <div className="table-row" key={`${m.script ?? m.description ?? "pending"}-${idx}`}>
                <span>{m.version ?? "R"}</span>
                <span>{m.description}</span>
                <span className="mono">{m.script}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card">
        <h3>Applied history</h3>
        <div className="table">
          <div className="table-header">
            <span>Version</span>
            <span>Description</span>
            <span>Installed</span>
            <span>Checksum</span>
          </div>
          {history?.applied.map((m, idx) => (
            <div className="table-row" key={`${m.script ?? m.description ?? "applied"}-${m.installedOn ?? "unknown"}-${idx}`}>
              <span>{m.version ?? "R"}</span>
              <span>{m.description}</span>
              <span>{m.installedOn ? new Date(m.installedOn).toLocaleString() : ""}</span>
              <span className="mono">{m.checksum}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
