import { useEffect, useMemo, useState } from "react";
import { apiFetch } from "../api";
import type { Repository, ScriptContent, ScriptDiff, ScriptInfo } from "../types";

export function RepoPage() {
  const [repos, setRepos] = useState<Repository[]>([]);
  const [selectedRepo, setSelectedRepo] = useState<Repository | null>(null);
  const [scripts, setScripts] = useState<ScriptInfo[]>([]);
  const [selectedPath, setSelectedPath] = useState<string | null>(null);
  const [content, setContent] = useState<ScriptContent | null>(null);
  const [diff, setDiff] = useState<ScriptDiff | null>(null);
  const [comparePath, setComparePath] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<Repository[]>("/repos")
      .then((data) => {
        setRepos(data);
        if (data.length > 0) setSelectedRepo(data[0]);
      })
      .catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    if (!selectedRepo) return;
    apiFetch<ScriptInfo[]>(`/repos/${selectedRepo.id}/scripts`)
      .then((data) => {
        setScripts(data);
        if (data.length > 0) setSelectedPath(data[0].path);
      })
      .catch((err) => setError(err.message));
  }, [selectedRepo]);

  useEffect(() => {
    if (!selectedRepo || !selectedPath) return;
    apiFetch<ScriptContent>(`/repos/${selectedRepo.id}/script?path=${encodeURIComponent(selectedPath)}`)
      .then((data) => {
        setContent(data);
        setDiff(null);
      })
      .catch((err) => setError(err.message));
  }, [selectedRepo, selectedPath]);

  const diffOptions = useMemo(() => scripts.map((s) => s.path), [scripts]);

  const runDiff = async () => {
    if (!selectedRepo || !selectedPath || !comparePath) return;
    try {
      const data = await apiFetch<ScriptDiff>(
        `/repos/${selectedRepo.id}/diff?left=${encodeURIComponent(selectedPath)}&right=${encodeURIComponent(comparePath)}`
      );
      setDiff(data);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="page">
      <section className="page-header">
        <div>
          <h1>Repository Browser</h1>
          <p>Review migration scripts, checksums, and diffs.</p>
        </div>
      </section>
      {error ? <div className="error">{error}</div> : null}
      <div className="split">
        <div className="card">
          <h3>Repositories</h3>
          <select
            value={selectedRepo?.id ?? ""}
            onChange={(e) => setSelectedRepo(repos.find((r) => r.id === e.target.value) ?? null)}
          >
            {repos.map((repo) => (
              <option value={repo.id} key={repo.id}>
                {repo.name}
              </option>
            ))}
          </select>
          <div className="table">
            <div className="table-header">
              <span>Path</span>
              <span>Type</span>
              <span>Checksum</span>
            </div>
            {scripts.map((script) => (
              <div
                key={script.path}
                className={`table-row selectable ${selectedPath === script.path ? "active" : ""}`}
                onClick={() => setSelectedPath(script.path)}
              >
                <span className="mono">{script.path}</span>
                <span>{script.type}</span>
                <span className="mono">{script.checksum.slice(0, 12)}...</span>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <h3>Script Viewer</h3>
          {content ? (
            <>
              <div className="meta">Checksum {content.checksum}</div>
              <pre className="code-block">{content.content}</pre>
            </>
          ) : (
            <div className="empty">Select a script to view.</div>
          )}
          <div className="diff-panel">
            <label>Compare with</label>
            <select value={comparePath ?? ""} onChange={(e) => setComparePath(e.target.value)}>
              <option value="">Select a script</option>
              {diffOptions.map((path) => (
                <option value={path} key={path}>
                  {path}
                </option>
              ))}
            </select>
            <button className="secondary" onClick={runDiff} disabled={!comparePath}>
              Diff
            </button>
          </div>
          {diff ? (
            <pre className="code-block">{diff.diffLines.join("\n")}</pre>
          ) : null}
        </div>
      </div>
    </div>
  );
}
