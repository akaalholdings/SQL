import { useEffect, useState } from "react";
import { apiFetch } from "../api";
import type { Run, RunDetail } from "../types";

export function RunsPage() {
  const [runs, setRuns] = useState<Run[]>([]);
  const [selected, setSelected] = useState<RunDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<Run[]>("/runs")
      .then(setRuns)
      .catch((err) => setError(err.message));
  }, []);

  const loadDetail = async (id: string) => {
    try {
      const detail = await apiFetch<RunDetail>(`/runs/${id}`);
      setSelected(detail);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="page">
      <section className="page-header">
        <div>
          <h1>Runs</h1>
          <p>Auditable history of validate and migrate operations.</p>
        </div>
      </section>
      {error ? <div className="error">{error}</div> : null}
      <div className="split">
        <div className="card">
          <h3>Recent runs</h3>
          <div className="table">
            <div className="table-header">
              <span>Action</span>
              <span>Status</span>
              <span>Started</span>
            </div>
            {runs.map((run) => (
              <div className="table-row selectable" key={run.id} onClick={() => loadDetail(run.id)}>
                <span>{run.action}</span>
                <span className={`badge ${run.status === "failed" ? "danger" : "ok"}`}>{run.status}</span>
                <span>{new Date(run.startedAt).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <h3>Run details</h3>
          {selected ? (
            <div className="log">
              <div className="log-header">{selected.action} · {selected.status}</div>
              <pre>{selected.output || selected.error || "No output"}</pre>
            </div>
          ) : (
            <div className="empty">Select a run to view details.</div>
          )}
        </div>
      </div>
    </div>
  );
}
