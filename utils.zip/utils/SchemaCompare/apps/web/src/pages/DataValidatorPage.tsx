import { useEffect, useMemo, useState } from "react";
import { apiFetch } from "../api";
import type { Environment, EnvironmentRowCounts, TableRowCount } from "../types";

type RowCompareStatus = "match" | "mismatch" | "missing" | "extra";

interface ComparedRow {
  key: string;
  schemaName: string;
  tableName: string;
  sourceCount?: number;
  targetCount?: number;
  delta?: number;
  status: RowCompareStatus;
}

interface ComparisonSummary {
  match: number;
  mismatch: number;
  missingInTarget: number;
  extraInTarget: number;
  total: number;
}

const statusOrder: Record<RowCompareStatus, number> = {
  mismatch: 0,
  missing: 1,
  extra: 2,
  match: 3
};

export function DataValidatorPage() {
  const [environments, setEnvironments] = useState<Environment[]>([]);
  const [sourceId, setSourceId] = useState<string>("");
  const [targetId, setTargetId] = useState<string>("");
  const [sourceName, setSourceName] = useState<string>("");
  const [targetName, setTargetName] = useState<string>("");
  const [rows, setRows] = useState<ComparedRow[]>([]);
  const [differencesOnly, setDifferencesOnly] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [comparedAt, setComparedAt] = useState<string | null>(null);

  const summary = useMemo<ComparisonSummary>(() => {
    return {
      match: rows.filter((row) => row.status === "match").length,
      mismatch: rows.filter((row) => row.status === "mismatch").length,
      missingInTarget: rows.filter((row) => row.status === "missing").length,
      extraInTarget: rows.filter((row) => row.status === "extra").length,
      total: rows.length
    };
  }, [rows]);

  const visibleRows = useMemo(() => {
    if (!differencesOnly) {
      return rows;
    }
    return rows.filter((row) => row.status !== "match");
  }, [rows, differencesOnly]);

  useEffect(() => {
    apiFetch<Environment[]>("/environments")
      .then((items) => {
        setEnvironments(items);

        if (items.length === 0) {
          return;
        }

        const defaultSource = items.find((env) => env.type.toLowerCase() === "prod") ?? items[0];
        const defaultTarget =
          items.find((env) => env.id !== defaultSource.id && env.type.toLowerCase() === "dev") ??
          items.find((env) => env.id !== defaultSource.id && ["test", "staging"].includes(env.type.toLowerCase())) ??
          items.find((env) => env.id !== defaultSource.id) ??
          defaultSource;

        setSourceId(defaultSource.id);
        setTargetId(defaultTarget.id);
      })
      .catch((err) => setError(err.message));
  }, []);

  const switchTargetEnvironment = (envType: "dev" | "test" | "staging") => {
    const candidate = environments.find((env) => env.type.toLowerCase() === envType && env.id !== sourceId);
    if (candidate) {
      setTargetId(candidate.id);
    }
  };

  const runValidation = async () => {
    if (!sourceId || !targetId) {
      setError("Select both source and target environments.");
      return;
    }

    if (sourceId === targetId) {
      setError("Source and target must be different environments.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const [source, target] = await Promise.all([
        apiFetch<EnvironmentRowCounts>(`/environments/${sourceId}/row-counts`),
        apiFetch<EnvironmentRowCounts>(`/environments/${targetId}/row-counts`)
      ]);

      setSourceName(source.connectionName);
      setTargetName(target.connectionName);
      setRows(compareRowCounts(source.tables, target.tables));
      setComparedAt(new Date().toISOString());
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <section className="page-header">
        <div>
          <h1>Data Validator</h1>
          <p>Compare table row counts between environments to quickly detect data drift.</p>
        </div>
      </section>

      {error ? <div className="error">{error}</div> : null}

      <section className="card env-selector-card">
        <div className="env-selector-row">
          <div>
            <label>Source (Production)</label>
            <select value={sourceId} onChange={(event) => setSourceId(event.target.value)}>
              {environments.map((env) => (
                <option value={env.id} key={env.id}>
                  {env.name} ({env.type})
                </option>
              ))}
            </select>
          </div>

          <div className="arrow">-&gt;</div>

          <div>
            <label>Target (Lower Environment)</label>
            <select value={targetId} onChange={(event) => setTargetId(event.target.value)}>
              {environments.map((env) => (
                <option value={env.id} key={env.id}>
                  {env.name} ({env.type})
                </option>
              ))}
            </select>
          </div>

          <button className="primary" onClick={runValidation} disabled={loading || !sourceId || !targetId || sourceId === targetId}>
            {loading ? "Validating..." : "Validate Data"}
          </button>
        </div>

        <div className="quick-switch-row">
          <span className="meta">Quick switch:</span>
          <button className="ghost" onClick={() => switchTargetEnvironment("dev")}>DEV</button>
          <button className="ghost" onClick={() => switchTargetEnvironment("test")}>TEST</button>
          <button className="ghost" onClick={() => switchTargetEnvironment("staging")}>STAGING</button>
        </div>
      </section>

      {rows.length > 0 ? (
        <>
          <section className="card">
            <div className="summary-grid">
              <SummaryStat label="Match" value={summary.match} tone="match" />
              <SummaryStat label="Mismatch" value={summary.mismatch} tone="modified" />
              <SummaryStat label="Missing" value={summary.missingInTarget} tone="missing" />
              <SummaryStat label="Extra" value={summary.extraInTarget} tone="extra" />
            </div>
            <div className="meta">
              <span style={{ display: "inline-flex", gap: "0.5rem", alignItems: "center", marginRight: "0.75rem" }}>
                <input
                  type="checkbox"
                  checked={differencesOnly}
                  onChange={(event) => setDifferencesOnly(event.target.checked)}
                />
                Differences only
              </span>
              Showing {visibleRows.length} of {rows.length} tables.{" "}
              Compared {summary.total} tables. Source: {sourceName || "-"} | Target: {targetName || "-"}
              {comparedAt ? ` | Compared at ${new Date(comparedAt).toLocaleString()}` : ""}
            </div>
          </section>

          <section className="card">
            {visibleRows.length > 0 ? (
              <div className="compare-table-wrap">
                <table className="compare-table">
                  <thead>
                    <tr>
                      <th>Table</th>
                      <th>{sourceName || "Source"} Row Count</th>
                      <th>{targetName || "Target"} Row Count</th>
                      <th>Delta</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visibleRows.map((row) => (
                      <tr key={row.key}>
                        <td className="mono">{row.schemaName}.{row.tableName}</td>
                        <td>{formatCount(row.sourceCount)}</td>
                        <td>{formatCount(row.targetCount)}</td>
                        <td className="mono">{row.delta === undefined ? "-" : formatSigned(row.delta)}</td>
                        <td>
                          <span className={statusBadgeClass(row.status)}>{statusLabel(row.status)}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="empty">
                No differences found.{" "}
                <button className="secondary" onClick={() => setDifferencesOnly(false)}>
                  Show all tables
                </button>
              </div>
            )}
          </section>
        </>
      ) : (
        <div className="empty">Choose environments and run validation to view row-count differences.</div>
      )}
    </div>
  );
}

function compareRowCounts(sourceTables: TableRowCount[], targetTables: TableRowCount[]): ComparedRow[] {
  const sourceMap = new Map(sourceTables.map((table) => [tableKey(table.schema, table.tableName), table]));
  const targetMap = new Map(targetTables.map((table) => [tableKey(table.schema, table.tableName), table]));
  const rows: ComparedRow[] = [];

  sourceTables.forEach((sourceTable) => {
    const key = tableKey(sourceTable.schema, sourceTable.tableName);
    const targetTable = targetMap.get(key);

    if (!targetTable) {
      rows.push({
        key,
        schemaName: sourceTable.schema,
        tableName: sourceTable.tableName,
        sourceCount: sourceTable.rowCount,
        status: "missing"
      });
      return;
    }

    const delta = sourceTable.rowCount - targetTable.rowCount;
    rows.push({
      key,
      schemaName: sourceTable.schema,
      tableName: sourceTable.tableName,
      sourceCount: sourceTable.rowCount,
      targetCount: targetTable.rowCount,
      delta,
      status: delta === 0 ? "match" : "mismatch"
    });
  });

  targetTables.forEach((targetTable) => {
    const key = tableKey(targetTable.schema, targetTable.tableName);
    if (sourceMap.has(key)) {
      return;
    }

    rows.push({
      key,
      schemaName: targetTable.schema,
      tableName: targetTable.tableName,
      targetCount: targetTable.rowCount,
      status: "extra"
    });
  });

  rows.sort((a, b) => {
    const statusDelta = statusOrder[a.status] - statusOrder[b.status];
    if (statusDelta !== 0) {
      return statusDelta;
    }

    return `${a.schemaName}.${a.tableName}`.localeCompare(`${b.schemaName}.${b.tableName}`);
  });

  return rows;
}

function tableKey(schemaName: string, tableName: string): string {
  return `${schemaName.toLowerCase()}.${tableName.toLowerCase()}`;
}

function formatCount(value?: number): string {
  if (typeof value !== "number") {
    return "-";
  }

  return value.toLocaleString();
}

function formatSigned(value: number): string {
  if (value > 0) {
    return `+${value.toLocaleString()}`;
  }

  return value.toLocaleString();
}

function statusBadgeClass(status: RowCompareStatus): string {
  if (status === "match") {
    return "badge ok";
  }

  if (status === "mismatch") {
    return "badge warn";
  }

  if (status === "missing") {
    return "badge danger";
  }

  return "badge";
}

function statusLabel(status: RowCompareStatus): string {
  if (status === "match") {
    return "Match";
  }

  if (status === "mismatch") {
    return "Mismatch";
  }

  if (status === "missing") {
    return "Missing in Target";
  }

  return "Extra in Target";
}

function SummaryStat({
  label,
  value,
  tone
}: {
  label: string;
  value: number;
  tone: "match" | "modified" | "missing" | "extra";
}) {
  return (
    <div className={`summary-stat summary-${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
