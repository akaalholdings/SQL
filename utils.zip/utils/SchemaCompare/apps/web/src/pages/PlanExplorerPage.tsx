import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEventHandler,
  type DragEventHandler,
  type MouseEventHandler
} from "react";
import { apiFetch } from "../api";
import { buildNodeIndex, extractStatementText, parseShowPlanXml, type PlanNodeInfo } from "../plan/planParser";
import qpScriptUrl from "html-query-plan/dist/qp.min.js?url";

type HtmlQueryPlanModule = {
  showPlan: (container: HTMLElement, planXml: string, options?: any) => void;
};

type PlanReviewRequest = {
  fileName?: string;
  statementText?: string;
  queryPlan?: string;
  nodeCount: number;
  hasActualRows: boolean;
  nodes: PlanNodeInfo[];
};

type PlanReviewResponse = {
  model: string;
  generatedAt: string;
  analysis: string;
};

declare global {
  interface Window {
    QP?: HtmlQueryPlanModule;
  }
}

let qpLoadPromise: Promise<HtmlQueryPlanModule> | null = null;

function formatNumber(value: number | undefined, fractionDigits = 2): string {
  if (value === undefined || !Number.isFinite(value)) {
    return "-";
  }
  const abs = Math.abs(value);
  if (abs >= 1_000_000) {
    return value.toExponential(2);
  }
  return value.toLocaleString(undefined, {
    maximumFractionDigits: fractionDigits
  });
}

function formatRows(value: number | undefined): string {
  if (value === undefined || !Number.isFinite(value)) {
    return "-";
  }
  return Math.round(value).toLocaleString();
}

function formatObject(info?: PlanNodeInfo["object"]): string {
  if (!info) {
    return "-";
  }

  const parts: string[] = [];
  if (info.database) {
    parts.push(info.database);
  }
  if (info.schema) {
    parts.push(info.schema);
  }
  if (info.table) {
    parts.push(info.table);
  }

  const base = parts.length > 0 ? parts.join(".") : "-";
  const index = info.index ? ` [${info.index}]` : "";
  const alias = info.alias ? ` (alias: ${info.alias})` : "";
  return `${base}${index}${alias}`;
}

function nodeSummary(node: PlanNodeInfo): string {
  const lines: string[] = [];
  lines.push(`NodeId: ${node.nodeId}`);
  if (node.physicalOp || node.logicalOp) {
    lines.push(`Operator: ${[node.physicalOp, node.logicalOp].filter(Boolean).join(" | ")}`);
  }
  const explanation = explainOperator(node.physicalOp, node.logicalOp);
  if (explanation) {
    lines.push(`Explanation: ${explanation}`);
  }
  lines.push(`Estimated Rows: ${formatRows(node.estimatedRows)}`);
  lines.push(`Actual Rows: ${formatRows(node.actualRows)}`);
  lines.push(`Estimated Subtree Cost: ${formatNumber(node.estimatedTotalSubtreeCost)}`);
  lines.push(`Estimated Operator Cost: ${formatNumber(node.estimatedOperatorCost)}`);
  lines.push(`Object: ${formatObject(node.object)}`);
  if (node.warnings.length > 0) {
    lines.push(`Warnings:`);
    for (const w of node.warnings) {
      lines.push(`- ${w}`);
    }
  }
  return lines.join("\n");
}

function isSupportedFile(file: File): boolean {
  const name = file.name.toLowerCase();
  return name.endsWith(".sqlplan") || name.endsWith(".xml");
}

function explainOperator(physicalOp?: string, logicalOp?: string): string | undefined {
  const op = (physicalOp || logicalOp || "").toLowerCase();
  if (!op) {
    return undefined;
  }

  if (op.includes("index seek")) {
    return "Uses an index to directly locate matching keys (typically efficient for selective predicates).";
  }
  if (op.includes("index scan")) {
    return "Reads a large portion of an index (can be expensive on large tables if many rows are touched).";
  }
  if (op.includes("table scan")) {
    return "Reads a large portion of the table/heap (often expensive unless the table is small).";
  }
  if (op.includes("key lookup") || op.includes("rid lookup")) {
    return "Fetches additional columns row-by-row after a nonclustered index access. Can become expensive with many lookups.";
  }
  if (op.includes("nested loops")) {
    return "Joins by iterating outer rows and probing the inner input. Great for small outer sets, risky for large ones.";
  }
  if (op.includes("hash match")) {
    return "Builds a hash table for join/aggregate. Can spill to tempdb if memory is insufficient.";
  }
  if (op.includes("merge join")) {
    return "Joins two sorted inputs. Efficient when both inputs are already ordered by the join keys.";
  }
  if (op.includes("sort")) {
    return "Orders rows. Can spill to tempdb if memory is insufficient or the row set is large.";
  }
  if (op.includes("filter")) {
    return "Applies a predicate to rows.";
  }
  if (op.includes("compute scalar")) {
    return "Computes expressions per row. Usually cheap, but can hide scalar UDFs or expensive computations.";
  }
  if (op.includes("stream aggregate")) {
    return "Aggregates rows on a sorted input (often efficient when input is already ordered).";
  }
  if (op.includes("hash aggregate")) {
    return "Aggregates rows using hashing (may require memory and can spill for large groups).";
  }
  if (op === "top" || op.includes("top")) {
    return "Returns the first N rows (may still require scanning/sorting depending on the plan).";
  }
  if (op.includes("spool")) {
    return "Temporarily stores rows for reuse. Can indicate repeated work or a workaround for plan shape constraints.";
  }
  if (op.includes("parallelism")) {
    return "Parallel operator coordinating work across threads (look for repartition/gather streams).";
  }

  return undefined;
}

async function loadHtmlQueryPlan(): Promise<HtmlQueryPlanModule> {
  // IMPORTANT:
  // `html-query-plan` bundles svg.js which assigns `this.SVG = ...`.
  // When imported as an ES module, `this` can be `undefined` (module strict mode),
  // which breaks at runtime with "Cannot set properties of undefined (setting 'SVG')".
  // Loading the UMD bundle via a classic script keeps it working.

  await import("html-query-plan/css/qp.css");

  if (window.QP && typeof window.QP.showPlan === "function") {
    return window.QP;
  }

  if (!qpLoadPromise) {
    qpLoadPromise = new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = qpScriptUrl;
      script.async = true;
      script.type = "text/javascript";
      script.dataset.qpScript = "1";

      script.onload = () => {
        if (window.QP && typeof window.QP.showPlan === "function") {
          resolve(window.QP);
          return;
        }
        reject(new Error("html-query-plan loaded, but window.QP was not found."));
      };

      script.onerror = () => reject(new Error("Failed to load html-query-plan script."));
      document.head.appendChild(script);
    });
  }

  return qpLoadPromise;
}

export function PlanExplorerPage() {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const planContainerRef = useRef<HTMLDivElement | null>(null);
  const selectedNodeElRef = useRef<HTMLElement | null>(null);
  const qpRef = useRef<HtmlQueryPlanModule | null>(null);

  const [fileName, setFileName] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [nodeIndex, setNodeIndex] = useState<Map<number, PlanNodeInfo> | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<number | null>(null);
  const [statementText, setStatementText] = useState<string | null>(null);
  const [planText, setPlanText] = useState<string | null>(null);

  const [aiIncludeStatementText, setAiIncludeStatementText] = useState(true);
  const [aiIncludeFullPlanXml, setAiIncludeFullPlanXml] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);

  const selectedNode = useMemo(() => {
    if (!nodeIndex || selectedNodeId === null) {
      return undefined;
    }
    return nodeIndex.get(selectedNodeId);
  }, [nodeIndex, selectedNodeId]);

  const selectedNodeExplanation = useMemo(() => {
    if (!selectedNode) {
      return undefined;
    }
    return explainOperator(selectedNode.physicalOp, selectedNode.logicalOp);
  }, [selectedNode]);

  useEffect(() => {
    // Preload the library so the first render after a file drop is fast.
    loadHtmlQueryPlan()
      .then((qp) => {
        qpRef.current = qp;
      })
      .catch(() => {
        // Ignore preload errors; we'll surface them when the user loads a plan.
      });
  }, []);

  const clearSelection = () => {
    if (selectedNodeElRef.current) {
      selectedNodeElRef.current.classList.remove("plan-node-selected");
      selectedNodeElRef.current = null;
    }
    setSelectedNodeId(null);
  };

  const clearPlan = () => {
    setFileName("");
    setNodeIndex(null);
    setStatementText(null);
    setPlanText(null);
    setAiError(null);
    setAiAnalysis(null);
    clearSelection();
    if (planContainerRef.current) {
      planContainerRef.current.innerHTML = "";
    }
  };

  const renderPlan = async (planXml: string) => {
    const container = planContainerRef.current;
    if (!container) {
      setError("Plan container not ready.");
      return;
    }

    setLoading(true);
    setError(null);
    setAiError(null);
    setAiAnalysis(null);
    clearSelection();

    try {
      const qp = qpRef.current ?? (await loadHtmlQueryPlan());
      qpRef.current = qp;

      container.innerHTML = "";
      qp.showPlan(container, planXml, { jsTooltips: true });

      const xmlDoc: XMLDocument | undefined = (container as any).xml;
      if (!xmlDoc) {
        throw new Error("Plan XML parse failed (xml document not available).");
      }

      const parserErrors = xmlDoc.getElementsByTagName("parsererror");
      if (parserErrors && parserErrors.length > 0) {
        throw new Error("XML parse error. Ensure the file contains valid ShowPlan XML.");
      }

      const relOps = xmlDoc.getElementsByTagNameNS("*", "RelOp");
      if (!relOps || relOps.length === 0) {
        throw new Error("Not a ShowPlanXML plan (no RelOp elements found).");
      }

      setStatementText(extractStatementText(xmlDoc) ?? null);

      const parsed = parseShowPlanXml(xmlDoc);
      const index = buildNodeIndex(parsed);
      setNodeIndex(index);
    } catch (e: any) {
      setNodeIndex(null);
      setError(e?.message ?? "Failed to render plan.");
    } finally {
      setLoading(false);
    }
  };

  const handleFile = async (file: File) => {
    if (!isSupportedFile(file)) {
      setError("Unsupported file. Please provide a .sqlplan or .xml file.");
      return;
    }

    setFileName(file.name);
    const text = await file.text();
    setPlanText(text);
    await renderPlan(text);
  };

  const onDrop: DragEventHandler<HTMLDivElement> = async (event) => {
    event.preventDefault();
    setDragOver(false);
    const file = event.dataTransfer.files?.[0];
    if (!file) {
      return;
    }
    await handleFile(file);
  };

  const onPickFile: ChangeEventHandler<HTMLInputElement> = async (event) => {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }
    await handleFile(file);
    // Reset so selecting the same file again triggers onChange.
    event.target.value = "";
  };

  const onPlanClick: MouseEventHandler<HTMLDivElement> = (event) => {
    if (!nodeIndex) {
      return;
    }

    const target = event.target as HTMLElement | null;
    const nodeEl = target?.closest?.(".qp-node") as HTMLElement | null;
    if (!nodeEl) {
      return;
    }

    const raw = nodeEl.getAttribute("data-node-id") ?? nodeEl.dataset?.nodeId;
    const nodeId = raw ? Number.parseInt(raw, 10) : Number.NaN;
    if (!Number.isFinite(nodeId)) {
      return;
    }

    if (selectedNodeElRef.current && selectedNodeElRef.current !== nodeEl) {
      selectedNodeElRef.current.classList.remove("plan-node-selected");
    }
    nodeEl.classList.add("plan-node-selected");
    selectedNodeElRef.current = nodeEl;
    setSelectedNodeId(nodeId);
  };

  const zoomOut = () => setZoom((z) => Math.max(0.5, Math.round((z - 0.1) * 10) / 10));
  const zoomIn = () => setZoom((z) => Math.min(2.0, Math.round((z + 0.1) * 10) / 10));
  const zoomReset = () => setZoom(1);

  const copySelected = async () => {
    if (!selectedNode) {
      return;
    }
    await navigator.clipboard.writeText(nodeSummary(selectedNode));
  };

  const buildPlanReviewPayload = (): PlanReviewRequest | null => {
    if (!nodeIndex) {
      return null;
    }

    const nodesAll = Array.from(nodeIndex.values());
    const hasActualRows = nodesAll.some((n) => n.actualRows !== undefined);

    // Keep payload bounded; the API/LLM doesn't need every node for a useful review.
    const MAX_NODES = 600;
    let nodes = nodesAll;
    if (nodesAll.length > MAX_NODES) {
      nodes = [...nodesAll]
        .sort((a, b) => (b.estimatedTotalSubtreeCost ?? 0) - (a.estimatedTotalSubtreeCost ?? 0))
        .slice(0, MAX_NODES);
    }

    const payload: PlanReviewRequest = {
      fileName: fileName || undefined,
      statementText: aiIncludeStatementText ? statementText || undefined : undefined,
      queryPlan: aiIncludeFullPlanXml ? planText || undefined : undefined,
      nodeCount: nodeIndex.size,
      hasActualRows,
      nodes
    };

    return payload;
  };

  const runAiReview = async () => {
    const payload = buildPlanReviewPayload();
    if (!payload) {
      return;
    }

    setAiLoading(true);
    setAiError(null);
    setAiAnalysis(null);

    try {
      const response = await apiFetch<PlanReviewResponse>("/plan-review", {
        method: "POST",
        body: JSON.stringify(payload)
      });
      setAiAnalysis(response.analysis);
    } catch (e: any) {
      const raw = e?.message ?? "AI review failed.";
      try {
        const parsed = JSON.parse(raw);
        setAiError(parsed?.detail ?? parsed?.error ?? raw);
      } catch {
        setAiError(raw);
      }
    } finally {
      setAiLoading(false);
    }
  };

  const copyAiAnalysis = async () => {
    if (!aiAnalysis) {
      return;
    }
    await navigator.clipboard.writeText(aiAnalysis);
  };

  return (
    <div className="page">
      <section className="page-header">
        <div>
          <h1>Plan Explorer</h1>
          <p>
            Drop a SQL Server/Azure SQL execution plan (<span className="mono">.sqlplan</span> or{" "}
            <span className="mono">.xml</span>) to view it graphically. Rendering stays in your browser. Optional AI review
            sends the plan text to the API/OpenAI.
          </p>
        </div>
      </section>

      {error ? <div className="error">{error}</div> : null}

      <section className="card plan-dropzone">
        <div
          className={dragOver ? "plan-dropzone-inner dragover" : "plan-dropzone-inner"}
          onDragEnter={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
        >
          <div>
            <strong>Drag and drop a plan file here</strong>
            <div className="meta">Accepted: .sqlplan, .xml (ShowPlanXML)</div>
          </div>
          <div style={{ display: "flex", gap: "0.6rem", alignItems: "center", flexWrap: "wrap" }}>
            <input
              ref={fileInputRef}
              type="file"
              accept=".sqlplan,.xml,application/xml,text/xml"
              onChange={onPickFile}
              style={{ display: "none" }}
            />
            <button className="primary" onClick={() => fileInputRef.current?.click()}>
              Choose file
            </button>
            {fileName ? <span className="mono">{fileName}</span> : <span className="meta">No file loaded</span>}
            {fileName ? (
              <button className="ghost" onClick={clearPlan}>
                Clear
              </button>
            ) : null}
          </div>
        </div>
      </section>

      <section className="compare-main-grid plan-grid">
        <div className="card">
          <div className="plan-toolbar">
            <div className="meta">
              {nodeIndex ? (
                <>
                  Nodes: <span className="mono">{nodeIndex.size}</span> | Click an operator to inspect
                </>
              ) : (
                "Load a plan to start exploring."
              )}
            </div>
            <div style={{ display: "flex", gap: "0.4rem", alignItems: "center" }}>
              <button className="ghost" onClick={zoomOut} disabled={!nodeIndex}>
                -
              </button>
              <span className="mono" style={{ width: 54, textAlign: "center" }}>
                {Math.round(zoom * 100)}%
              </span>
              <button className="ghost" onClick={zoomIn} disabled={!nodeIndex}>
                +
              </button>
              <button className="ghost" onClick={zoomReset} disabled={!nodeIndex || zoom === 1}>
                Reset
              </button>
            </div>
          </div>

          <div className="plan-viewer" onClick={onPlanClick}>
            {loading ? <div className="meta">Rendering plan…</div> : null}
            <div
              className="plan-viewer-scale"
              style={{
                transform: `scale(${zoom})`,
                transformOrigin: "0 0"
              }}
            >
              <div ref={planContainerRef} />
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <div>
              <h3 style={{ margin: 0 }}>Node Inspector</h3>
              <div className="meta">Click an operator in the plan to see details.</div>
            </div>
            <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", justifyContent: "flex-end" }}>
              <button className="ghost" onClick={copySelected} disabled={!selectedNode}>
                Copy details
              </button>
              <button className="ghost" onClick={clearSelection} disabled={!selectedNode}>
                Clear
              </button>
            </div>
          </div>

          {selectedNode ? (
            <div className="kv">
              <div className="kv-row">
                <span className="meta">NodeId</span>
                <span className="mono">{selectedNode.nodeId}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Physical Op</span>
                <span className="mono">{selectedNode.physicalOp ?? "-"}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Logical Op</span>
                <span className="mono">{selectedNode.logicalOp ?? "-"}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Explanation</span>
                <span>{selectedNodeExplanation ?? "-"}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Estimated Rows</span>
                <span className="mono">{formatRows(selectedNode.estimatedRows)}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Actual Rows</span>
                <span className="mono">{formatRows(selectedNode.actualRows)}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Est. Subtree Cost</span>
                <span className="mono">{formatNumber(selectedNode.estimatedTotalSubtreeCost)}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Est. Operator Cost</span>
                <span className="mono">{formatNumber(selectedNode.estimatedOperatorCost)}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Object</span>
                <span className="mono">{formatObject(selectedNode.object)}</span>
              </div>
              <div className="kv-row">
                <span className="meta">Warnings</span>
                <span className="mono">
                  {selectedNode.warnings.length > 0 ? selectedNode.warnings.join(" | ") : "-"}
                </span>
              </div>
            </div>
          ) : (
            <div className="meta">No operator selected.</div>
          )}

          <div className="plan-ai-separator" />

          <div className="plan-ai-header">
            <div>
              <h3 style={{ margin: 0 }}>AI Review</h3>
              <div className="meta">
                Sends a summary to the backend and OpenAI by default. Enable full plan upload only when needed and approved.
              </div>
            </div>
            <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", justifyContent: "flex-end" }}>
              <button className="ghost" onClick={copyAiAnalysis} disabled={!aiAnalysis}>
                Copy analysis
              </button>
              <button className="primary" onClick={runAiReview} disabled={!nodeIndex || aiLoading}>
                {aiLoading ? "Analyzing…" : "Analyze plan"}
              </button>
            </div>
          </div>

          <label className="plan-ai-option">
            <input
              type="checkbox"
              checked={aiIncludeStatementText}
              onChange={(e) => setAiIncludeStatementText(e.target.checked)}
              disabled={aiLoading}
            />
            <span>
              Include statement text (if present){" "}
              {statementText ? <span className="meta">(detected)</span> : <span className="meta">(not found)</span>}
            </span>
          </label>

          <label className="plan-ai-option">
            <input
              type="checkbox"
              checked={aiIncludeFullPlanXml}
              onChange={(e) => setAiIncludeFullPlanXml(e.target.checked)}
              disabled={aiLoading || !planText}
            />
            <span>
              Include full plan XML/text{" "}
              {planText ? <span className="meta">(uploads file contents)</span> : <span className="meta">(no plan loaded)</span>}
            </span>
          </label>

          {aiError ? <div className="error">{aiError}</div> : null}

          {aiAnalysis ? <pre className="plan-ai-output">{aiAnalysis}</pre> : <div className="meta">No AI analysis yet.</div>}
        </div>
      </section>
    </div>
  );
}
