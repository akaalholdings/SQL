import { useEffect, useState } from "react";
import { apiFetch } from "../api";
import type { Environment, EnvironmentStatus } from "../types";
import { Link } from "react-router-dom";

export function DashboardPage() {
  const [environments, setEnvironments] = useState<Environment[]>([]);
  const [statuses, setStatuses] = useState<Record<string, EnvironmentStatus>>({});
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<Environment[]>("/environments")
      .then((envs) => {
        setEnvironments(envs);
        return Promise.all(
          envs.map((env) =>
            apiFetch<EnvironmentStatus>(`/environments/${env.id}/status`).then((status) => ({
              id: env.id,
              status
            }))
          )
        );
      })
      .then((results) => {
        const map: Record<string, EnvironmentStatus> = {};
        results.forEach((r) => {
          map[r.id] = r.status;
        });
        setStatuses(map);
      })
      .catch((err) => setError(err.message));
  }, []);

  return (
    <div className="page">
      <section className="page-header">
        <div>
          <h1>Environments</h1>
          <p>Track migration health, pending work, and drift across Azure SQL environments.</p>
        </div>
      </section>
      {error ? <div className="error">{error}</div> : null}
      <div className="grid">
        {environments.map((env) => {
          const status = statuses[env.id];
          return (
            <Link to={`/environments/${env.id}`} className="card" key={env.id}>
              <div className="card-header">
                <div>
                  <h3>{env.name}</h3>
                  <div className="meta">
                    {env.type.toUpperCase()} · {env.server}/{env.database}
                  </div>
                </div>
                {status ? <StatusBadge status={status} /> : <span className="badge">Loading</span>}
              </div>
              {status ? (
                <div className="card-body">
                  <div className="stat">
                    <span>Current</span>
                    <strong>{status.currentVersion || "—"}</strong>
                  </div>
                  <div className="stat">
                    <span>Pending</span>
                    <strong>{status.pendingCount}</strong>
                  </div>
                  <div className="stat">
                    <span>Applied</span>
                    <strong>{status.appliedCount}</strong>
                  </div>
                </div>
              ) : (
                <div className="card-body">Loading status...</div>
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: EnvironmentStatus }) {
  if (status.driftDetected) {
    return <span className="badge danger">Drift detected</span>;
  }
  if (status.pendingCount > 0) {
    return <span className="badge warn">Pending</span>;
  }
  return <span className="badge ok">Up to date</span>;
}
