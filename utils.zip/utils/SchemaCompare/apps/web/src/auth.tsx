import React, { useEffect, useMemo, useState } from "react";
import {
  PublicClientApplication,
  type AccountInfo,
  type AuthenticationResult
} from "@azure/msal-browser";
import { MsalProvider, useMsal, useIsAuthenticated } from "@azure/msal-react";
import { config } from "./config";

let msalInstance: PublicClientApplication | null = null;
let msalInitError: string | null = null;

function entraConfigError(): string | null {
  if (!config.entra.clientId) {
    return "Missing VITE_ENTRA_CLIENT_ID.";
  }
  if (!config.entra.scope) {
    return "Missing VITE_API_SCOPE (e.g. api://<client-id>/access_as_user).";
  }
  return null;
}

export function getMsalInstance(): PublicClientApplication | null {
  if (config.devAuth) {
    return null;
  }
  if (msalInstance) {
    return msalInstance;
  }
  const err = entraConfigError();
  if (err) {
    msalInitError = err;
    return null;
  }

  msalInstance = new PublicClientApplication({
    auth: {
      clientId: config.entra.clientId,
      authority: config.entra.tenantId
        ? `https://login.microsoftonline.com/${config.entra.tenantId}`
        : "https://login.microsoftonline.com/common",
      redirectUri: window.location.origin
    },
    cache: {
      cacheLocation: "localStorage"
    }
  });
  return msalInstance;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  if (config.devAuth) {
    return <>{children}</>;
  }

  const instance = getMsalInstance();
  if (!instance) {
    const message =
      msalInitError ??
      "Entra auth is enabled, but required build-time env vars are missing. Set VITE_ENTRA_CLIENT_ID and VITE_API_SCOPE.";
    return (
      <div className="page">
        <div className="card">
          <h2>Auth configuration error</h2>
          <p className="meta">{message}</p>
        </div>
      </div>
    );
  }

  return <MsalProvider instance={instance}>{children}</MsalProvider>;
}

export function AuthGate({ children }: { children: React.ReactNode }) {
  if (config.devAuth) {
    return <>{children}</>;
  }

  return <MsalAuthGate>{children}</MsalAuthGate>;
}

function MsalAuthGate({ children }: { children: React.ReactNode }) {
  const { instance, accounts } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    instance
      .handleRedirectPromise()
      .then((result) => {
        if (result?.account) {
          instance.setActiveAccount(result.account);
        } else if (accounts.length > 0) {
          instance.setActiveAccount(accounts[0]);
        }
      })
      .finally(() => setReady(true));
  }, [instance, accounts]);

  if (!ready) {
    return <div className="page">Loading auth...</div>;
  }

  if (!isAuthenticated) {
    return (
      <div className="page">
        <div className="card">
          <h2>Sign in</h2>
          <p>Use your Microsoft Entra ID to continue.</p>
          <button
            className="primary"
            onClick={() => instance.loginRedirect({ scopes: [config.entra.scope] })}
          >
            Sign in
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

export function useAuth() {
  if (config.devAuth) {
    return {
      account: { username: "dev.user@local" } as AccountInfo,
      login: async () => {},
      logout: () => {},
      getToken: async () => ""
    };
  }

  return useMsalAuth();
}

function useMsalAuth() {
  const { instance, accounts } = useMsal();
  const account = useMemo(() => instance.getActiveAccount() ?? accounts[0] ?? null, [instance, accounts]);

  const login = async () => {
    await instance.loginRedirect({ scopes: [config.entra.scope] });
  };

  const logout = () => {
    instance.logoutRedirect();
  };

  const getToken = async () => {
    if (!account) {
      throw new Error("No active account");
    }
    const result: AuthenticationResult = await instance.acquireTokenSilent({
      account,
      scopes: [config.entra.scope]
    });
    return result.accessToken;
  };

  return { account, login, logout, getToken };
}
