export const config = {
  apiBaseUrl: import.meta.env.API_BACKEND_URL || '/api',
  API_BASE_URL: import.meta.env.API_BACKEND_URL || '/api',
  devAuth: import.meta.env.VITE_DEV_AUTH === "true",
  entra: {
    clientId: import.meta.env.VITE_ENTRA_CLIENT_ID ?? "",
    tenantId: import.meta.env.VITE_ENTRA_TENANT_ID ?? "",
    scope: import.meta.env.VITE_API_SCOPE ?? ""
  }
};
