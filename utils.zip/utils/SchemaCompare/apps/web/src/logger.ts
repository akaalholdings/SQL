/**
 * File: logger.ts
 * Description: Client-side logger that outputs to browser console and optionally
 *              sends error logs to the backend for pod-level observability.
 * Author: Geneva Platform Team
 * Created: 2025-01-01
 * Last Modified: 2026-03-13
 */

const API_BASE_URL: string = (import.meta as any).env?.API_BACKEND_URL || '/api';

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  source: 'client';
  meta?: Record<string, unknown>;
}

/**
 * Sends a log entry to the backend for pod-level collection.
 *
 * @param entry - The structured log entry to send
 */
async function sendToBackend(entry: LogEntry): Promise<void> {
  try {
    await fetch(`${API_BASE_URL}/logs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(entry),
    });
  } catch {
    // Silently fail — avoid infinite error loops
  }
}

/**
 * Creates a structured log entry and writes to console.
 * Errors are also forwarded to the backend for pod log collection.
 *
 * @param level - Log level
 * @param message - Log message
 * @param meta - Additional metadata
 */
export function log(level: LogLevel, message: string, meta?: Record<string, unknown>): void {
  const entry: LogEntry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    source: 'client',
    meta,
  };

  switch (level) {
    case 'debug':
      console.debug(`[${entry.timestamp}]`, message, meta);
      break;
    case 'info':
      console.info(`[${entry.timestamp}]`, message, meta);
      break;
    case 'warn':
      console.warn(`[${entry.timestamp}]`, message, meta);
      break;
    case 'error':
      console.error(`[${entry.timestamp}]`, message, meta);
      sendToBackend(entry);
      break;
  }
}

/**
 * Registers global error handlers to catch unhandled exceptions
 * and promise rejections, forwarding them to the backend.
 */
export function initGlobalErrorHandlers(): void {
  window.addEventListener('error', (event) => {
    log('error', 'Unhandled client error', {
      message: event.message,
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno,
    });
  });

  window.addEventListener('unhandledrejection', (event) => {
    log('error', 'Unhandled promise rejection', {
      reason: String(event.reason),
    });
  });
}