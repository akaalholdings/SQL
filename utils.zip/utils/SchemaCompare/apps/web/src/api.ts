import { config } from "./config";
import { getMsalInstance } from "./auth";

async function getAccessToken(): Promise<string | null> {
  if (config.devAuth) {
    return null;
  }
  const msalInstance = getMsalInstance();
  if (!msalInstance) {
    return null;
  }
  const account = msalInstance.getActiveAccount() ?? msalInstance.getAllAccounts()[0];
  if (!account) {
    return null;
  }
  const result = await msalInstance.acquireTokenSilent({
    account,
    scopes: [config.entra.scope]
  });
  return result.accessToken;
}

export async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const method = (options?.method ?? "GET").toUpperCase();
  const headers = new Headers(options?.headers ?? {});
  headers.set("Accept", "application/json");

  // Avoid forcing CORS preflight on simple GETs.
  // Only set Content-Type when we actually send a JSON body.
  const hasBody = options?.body !== undefined && options?.body !== null && method !== "GET" && method !== "HEAD";
  if (hasBody) {
    headers.set("Content-Type", "application/json");
  }
  const token = await getAccessToken();
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  const response = await fetch(`${config.apiBaseUrl}${path}`, {
    ...options,
    headers
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || response.statusText);
  }

  if (response.status === 204) {
    return {} as T;
  }

  return (await response.json()) as T;
}
