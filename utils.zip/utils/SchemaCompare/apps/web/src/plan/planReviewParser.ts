export type Priority = "Critical" | "High" | "Medium" | "Low" | "Unknown";

export type ParsedAiItem = {
  index: number;
  title: string;
  body: string;
  priority: Priority;
};

export type ParsedPlanReview = {
  queryExplanation?: string;
  issues: ParsedAiItem[];
  recommendations: ParsedAiItem[];
  raw: string;
  normalized: string;
};

function extractOuterTag(input: string, tag: string): string | undefined {
  const lower = input.toLowerCase();
  const open = lower.indexOf(`<${tag}`);
  if (open === -1) {
    return undefined;
  }
  const openEnd = lower.indexOf(">", open);
  if (openEnd === -1) {
    return undefined;
  }
  const close = lower.lastIndexOf(`</${tag}>`);
  if (close === -1 || close < openEnd) {
    return undefined;
  }
  return input.slice(openEnd + 1, close);
}

export function normalizeAnalysis(raw: string): string {
  let text = (raw || "").trim();
  if (!text) {
    return "";
  }

  // Strip outer <analysis> wrappers. Sometimes the model returns nested tags.
  for (let i = 0; i < 2; i++) {
    const extracted = extractOuterTag(text, "analysis");
    if (extracted === undefined) {
      break;
    }
    text = extracted.trim();
  }

  return text;
}

export function extractTag(normalized: string, tag: string): string | undefined {
  const extracted = extractOuterTag(normalized, tag.toLowerCase());
  return extracted?.trim();
}

export function splitNumberedItems(section: string): Array<{ index: number; body: string }> {
  const lines = (section || "").split(/\r?\n/);
  const items: Array<{ index: number; body: string }> = [];

  let currentIndex: number | null = null;
  let currentLines: string[] = [];

  const flush = () => {
    if (currentIndex === null) {
      return;
    }
    const body = currentLines.join("\n").trim();
    items.push({ index: currentIndex, body });
  };

  const headerRe = /^\s*(\d+)[.)]\s+(.*)$/;

  for (const line of lines) {
    const match = line.match(headerRe);
    if (match) {
      flush();
      currentIndex = Number.parseInt(match[1], 10);
      currentLines = [match[2]];
      continue;
    }
    if (currentIndex !== null) {
      currentLines.push(line);
    }
  }

  flush();
  return items;
}

export function inferPriority(body: string): Priority {
  const match = (body || "").match(/priority\s*(?:level)?\s*[:=-]\s*(critical|high|medium|low)/i);
  if (!match) {
    return "Unknown";
  }
  const value = match[1].toLowerCase();
  if (value === "critical") return "Critical";
  if (value === "high") return "High";
  if (value === "medium") return "Medium";
  if (value === "low") return "Low";
  return "Unknown";
}

export function titleFromBody(body: string): string {
  const lines = (body || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const first = lines[0] || "Untitled";
  const cleaned = first.replace(/^\s*\d+[.)]\s*/, "").replace(/^\s*[-*]\s*/, "").trim();
  const normalized = cleaned.replace(/\s+/g, " ");
  if (normalized.length <= 90) {
    return normalized;
  }
  return normalized.slice(0, 87).trimEnd() + "...";
}

export function parsePlanReviewAnalysis(raw: string): ParsedPlanReview {
  const normalized = normalizeAnalysis(raw);

  const queryExplanation = extractTag(normalized, "query_explanation");
  const issuesText = extractTag(normalized, "issues_identified");
  const recommendationsText = extractTag(normalized, "recommendations");

  const issues = (issuesText ? splitNumberedItems(issuesText) : []).map((item) => {
    return {
      index: item.index,
      title: titleFromBody(item.body),
      body: item.body,
      priority: inferPriority(item.body)
    } satisfies ParsedAiItem;
  });

  const recommendations = (recommendationsText ? splitNumberedItems(recommendationsText) : []).map((item) => {
    return {
      index: item.index,
      title: titleFromBody(item.body),
      body: item.body,
      priority: inferPriority(item.body)
    } satisfies ParsedAiItem;
  });

  return {
    queryExplanation,
    issues,
    recommendations,
    raw,
    normalized
  };
}

