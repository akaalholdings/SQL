export interface PlanNodeObjectInfo {
  database?: string;
  schema?: string;
  table?: string;
  index?: string;
  alias?: string;
}

export interface PlanNodeInfo {
  nodeId: number;
  physicalOp?: string;
  logicalOp?: string;
  estimatedRows?: number;
  actualRows?: number;
  estimatedTotalSubtreeCost?: number;
  estimatedOperatorCost?: number;
  object?: PlanNodeObjectInfo;
  warnings: string[];
}

export interface ParsedPlan {
  xml: XMLDocument;
  relOps: Element[];
  byNodeId: Map<number, Element>;
  parentByNodeId: Map<number, number | null>;
  childrenByNodeId: Map<number, number[]>;
}

function parseNumber(value: string | null | undefined): number | undefined {
  if (!value) {
    return undefined;
  }
  const n = Number.parseFloat(value);
  return Number.isFinite(n) ? n : undefined;
}

function findParentRelOp(el: Element): Element | null {
  let current: Element | null = el.parentElement;
  while (current) {
    if (current.localName === "RelOp") {
      return current;
    }
    current = current.parentElement;
  }
  return null;
}

function pickFirstObjectInfo(relOp: Element): PlanNodeObjectInfo | undefined {
  const objects = Array.from(relOp.getElementsByTagNameNS("*", "Object"));
  for (const obj of objects) {
    const info: PlanNodeObjectInfo = {
      database: obj.getAttribute("Database") ?? undefined,
      schema: obj.getAttribute("Schema") ?? undefined,
      table: obj.getAttribute("Table") ?? undefined,
      index: obj.getAttribute("Index") ?? undefined,
      alias: obj.getAttribute("Alias") ?? undefined
    };

    if (info.database || info.schema || info.table || info.index || info.alias) {
      return info;
    }
  }
  return undefined;
}

function extractActualRows(relOp: Element): number | undefined {
  const counters = Array.from(relOp.getElementsByTagNameNS("*", "RunTimeCountersPerThread"));
  if (counters.length === 0) {
    return undefined;
  }

  let sum = 0;
  let saw = false;
  for (const c of counters) {
    const actual = parseNumber(c.getAttribute("ActualRows"));
    if (actual !== undefined) {
      sum += actual;
      saw = true;
    }
  }
  return saw ? sum : undefined;
}

function summariseAttributes(el: Element, allowed: string[] = []): string {
  const attrs = Array.from(el.attributes);
  const filtered = allowed.length
    ? attrs.filter((a) => allowed.includes(a.name))
    : attrs.filter((a) => a.name.toLowerCase() !== "xmlns");

  if (filtered.length === 0) {
    return "";
  }

  const parts: string[] = [];
  for (const a of filtered.slice(0, 6)) {
    parts.push(`${a.name}=${a.value}`);
  }
  return parts.join(", ");
}

function extractWarnings(relOp: Element): string[] {
  const warnings: string[] = [];
  const warningsEls = Array.from(relOp.getElementsByTagNameNS("*", "Warnings"));

  const pushUnique = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) {
      return;
    }
    if (!warnings.includes(trimmed)) {
      warnings.push(trimmed);
    }
  };

  for (const w of warningsEls) {
    const spill = w.getElementsByTagNameNS("*", "SpillToTempDb");
    if (spill.length > 0) {
      const attrs = summariseAttributes(spill[0], ["SpillLevel"]);
      pushUnique(attrs ? `SpillToTempDb (${attrs})` : "SpillToTempDb");
    }

    const sortSpill = w.getElementsByTagNameNS("*", "SortSpillDetails");
    if (sortSpill.length > 0) {
      const attrs = summariseAttributes(sortSpill[0]);
      pushUnique(attrs ? `SortSpillDetails (${attrs})` : "SortSpillDetails");
    }

    const hashSpill = w.getElementsByTagNameNS("*", "HashSpillDetails");
    if (hashSpill.length > 0) {
      const attrs = summariseAttributes(hashSpill[0]);
      pushUnique(attrs ? `HashSpillDetails (${attrs})` : "HashSpillDetails");
    }

    const memGrant = w.getElementsByTagNameNS("*", "MemoryGrantWarning");
    if (memGrant.length > 0) {
      const attrs = summariseAttributes(memGrant[0], ["GrantWarningKind", "RequestedMemory", "GrantedMemory", "MaxUsedMemory"]);
      pushUnique(attrs ? `MemoryGrantWarning (${attrs})` : "MemoryGrantWarning");
    }

    const convert = w.getElementsByTagNameNS("*", "PlanAffectingConvert");
    if (convert.length > 0) {
      const attrs = summariseAttributes(convert[0], ["ConvertIssue", "Expression"]);
      pushUnique(attrs ? `PlanAffectingConvert (${attrs})` : "PlanAffectingConvert");
    }

    const noJoin = w.getElementsByTagNameNS("*", "NoJoinPredicate");
    if (noJoin.length > 0) {
      pushUnique("NoJoinPredicate");
    }

    const noStats = w.getElementsByTagNameNS("*", "ColumnsWithNoStatistics");
    if (noStats.length > 0) {
      const columns = Array.from(noStats[0].getElementsByTagNameNS("*", "ColumnReference"));
      pushUnique(columns.length > 0 ? `ColumnsWithNoStatistics (${columns.length})` : "ColumnsWithNoStatistics");
    }

    const wait = w.getElementsByTagNameNS("*", "Wait");
    if (wait.length > 0) {
      const attrs = summariseAttributes(wait[0], ["WaitType", "WaitTimeMs"]);
      pushUnique(attrs ? `Wait (${attrs})` : "Wait");
    }
  }

  return warnings;
}

export function parseShowPlanXml(xml: XMLDocument): ParsedPlan {
  const relOps = Array.from(xml.getElementsByTagNameNS("*", "RelOp"));
  const byNodeId = new Map<number, Element>();
  const parentByNodeId = new Map<number, number | null>();
  const childrenByNodeId = new Map<number, number[]>();

  for (const el of relOps) {
    const nodeIdRaw = el.getAttribute("NodeId");
    const nodeId = nodeIdRaw ? Number.parseInt(nodeIdRaw, 10) : Number.NaN;
    if (!Number.isFinite(nodeId)) {
      continue;
    }
    byNodeId.set(nodeId, el);
    childrenByNodeId.set(nodeId, []);
  }

  for (const [nodeId, el] of byNodeId) {
    const parentEl = findParentRelOp(el);
    if (!parentEl) {
      parentByNodeId.set(nodeId, null);
      continue;
    }

    const parentIdRaw = parentEl.getAttribute("NodeId");
    const parentId = parentIdRaw ? Number.parseInt(parentIdRaw, 10) : Number.NaN;
    if (!Number.isFinite(parentId) || !byNodeId.has(parentId)) {
      parentByNodeId.set(nodeId, null);
      continue;
    }

    parentByNodeId.set(nodeId, parentId);
    const children = childrenByNodeId.get(parentId);
    if (children) {
      children.push(nodeId);
    }
  }

  return {
    xml,
    relOps,
    byNodeId,
    parentByNodeId,
    childrenByNodeId
  };
}

export function buildNodeIndex(parsedPlan: ParsedPlan): Map<number, PlanNodeInfo> {
  const map = new Map<number, PlanNodeInfo>();

  for (const [nodeId, relOp] of parsedPlan.byNodeId.entries()) {
    const info: PlanNodeInfo = {
      nodeId,
      physicalOp: relOp.getAttribute("PhysicalOp") ?? undefined,
      logicalOp: relOp.getAttribute("LogicalOp") ?? undefined,
      estimatedRows: parseNumber(relOp.getAttribute("EstimateRows")),
      actualRows: extractActualRows(relOp),
      estimatedTotalSubtreeCost: parseNumber(relOp.getAttribute("EstimatedTotalSubtreeCost")),
      object: pickFirstObjectInfo(relOp),
      warnings: extractWarnings(relOp)
    };

    map.set(nodeId, info);
  }

  for (const [nodeId, info] of map.entries()) {
    if (info.estimatedTotalSubtreeCost === undefined) {
      continue;
    }

    const children = parsedPlan.childrenByNodeId.get(nodeId) ?? [];
    let sumChildCosts = 0;
    let sawChildCost = false;
    for (const childId of children) {
      const child = map.get(childId);
      if (child?.estimatedTotalSubtreeCost !== undefined) {
        sumChildCosts += child.estimatedTotalSubtreeCost;
        sawChildCost = true;
      }
    }

    if (!sawChildCost) {
      continue;
    }

    const opCost = info.estimatedTotalSubtreeCost - sumChildCosts;
    info.estimatedOperatorCost = Number.isFinite(opCost) ? Math.max(0, opCost) : undefined;
  }

  return map;
}

export function extractStatementText(xml: XMLDocument): string | undefined {
  // Common ShowPlan element that contains the query text.
  const stmtNames = ["StmtSimple", "StmtCursor", "StmtCond", "StmtUseDb", "StmtMultiStmt"];
  for (const name of stmtNames) {
    const els = Array.from(xml.getElementsByTagNameNS("*", name));
    for (const el of els) {
      const text = el.getAttribute("StatementText");
      if (text && text.trim()) {
        return text.trim();
      }
    }
  }

  // Fallback: scan for any element that has a StatementText attribute.
  const all = Array.from(xml.getElementsByTagName("*"));
  for (const el of all) {
    const text = el.getAttribute?.("StatementText");
    if (text && text.trim()) {
      return text.trim();
    }
  }

  return undefined;
}
