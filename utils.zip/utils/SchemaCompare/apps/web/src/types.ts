export interface Environment {
  id: string;
  name: string;
  type: string;
  server: string;
  database: string;
  schema: string;
  authMode: string;
  jdbcUrl: string;
  user?: string;
  passwordSecretName?: string;
  repositoryId: string;
  historyTable: string;
  isActive: boolean;
  tags?: Record<string, string>;
  owner?: string;
  createdAt: string;
  updatedAt: string;
  lastValidatedAt?: string;
  lastValidationDrift?: boolean;
}

export interface EnvironmentStatus {
  environmentId: string;
  currentVersion: string;
  pendingCount: number;
  appliedCount: number;
  driftDetected: boolean;
  lastValidatedAt?: string;
}

export interface MigrationHistoryItem {
  version?: string;
  description?: string;
  type?: string;
  script?: string;
  checksum?: string;
  installedBy?: string;
  installedOn?: string;
  executionTimeMs?: number;
  success?: boolean;
  state?: string;
}

export interface MigrationHistoryResponse {
  environmentId: string;
  applied: MigrationHistoryItem[];
  pending: MigrationHistoryItem[];
}

export interface Run {
  id: string;
  environmentId: string;
  action: string;
  status: string;
  startedAt: string;
  finishedAt?: string;
  triggeredBy: string;
  pendingCount?: number;
  appliedCount?: number;
  driftDetected?: boolean;
  error?: string;
}

export interface RunDetail extends Run {
  output?: string;
  outputJson?: string;
  logs: { timestamp: string; level: string; message: string }[];
}

export interface Repository {
  id: string;
  name: string;
  type: string;
  rootPath: string;
  gitUrl?: string;
  gitBranch?: string;
}

export interface ScriptInfo {
  path: string;
  type: string;
  version?: string;
  description: string;
  checksum: string;
  sizeBytes: number;
  lastModified: string;
}

export interface ScriptContent {
  path: string;
  checksum: string;
  content: string;
}

export interface ScriptDiff {
  leftPath: string;
  rightPath: string;
  diffLines: string[];
}

export type ComparisonStatus = "match" | "modified" | "missing" | "extra";

export interface DatabaseSchema {
  connectionId: string;
  connectionName: string;
  environment: string;
  fetchedAt: string;
  tables: TableSchema[];
}

export interface EnvironmentRowCounts {
  connectionId: string;
  connectionName: string;
  environment: string;
  fetchedAt: string;
  tables: TableRowCount[];
}

export interface TableRowCount {
  schema: string;
  tableName: string;
  rowCount: number;
}

export interface TableSchema {
  name: string;
  schema: string;
  columns: ColumnSchema[];
  indexes: IndexSchema[];
  constraints: TableConstraintSchema[];
  foreignKeys: ForeignKeySchema[];
  partitions?: PartitionSchema;
}

export interface ColumnSchema {
  name: string;
  dataType: string;
  maxLength?: number;
  precision?: number;
  scale?: number;
  isNullable: boolean;
  defaultValue?: string;
  isIdentity: boolean;
  isComputed: boolean;
}

export interface IndexSchema {
  name: string;
  type: string;
  isUnique: boolean;
  isPrimaryKey: boolean;
  columns: IndexColumnSchema[];
}

export interface IndexColumnSchema {
  name: string;
  isDescending: boolean;
  isIncluded: boolean;
}

export interface PartitionSchema {
  schemeName?: string;
  functionName?: string;
  columnName?: string;
  partitionCount: number;
}

export interface TableConstraintSchema {
  name: string;
  type: "PRIMARY_KEY" | "UNIQUE" | "CHECK" | "DEFAULT" | string;
  definition?: string;
  isClustered: boolean;
  isDisabled: boolean;
  isNotTrusted: boolean;
  columns: ConstraintColumnSchema[];
}

export interface ConstraintColumnSchema {
  name: string;
  isDescending: boolean;
}

export interface ForeignKeySchema {
  name: string;
  referencedSchema: string;
  referencedTable: string;
  onDeleteAction: string;
  onUpdateAction: string;
  isDisabled: boolean;
  isNotTrusted: boolean;
  columns: ForeignKeyColumnSchema[];
}

export interface ForeignKeyColumnSchema {
  sourceColumn: string;
  referencedColumn: string;
}

export interface SchemaComparisonSummary {
  matching: number;
  modified: number;
  missingInTarget: number;
  extraInTarget: number;
  totalTables: number;
}

export interface ColumnDiff {
  name: string;
  status: ComparisonStatus;
  source?: ColumnSchema;
  target?: ColumnSchema;
  differences: string[];
}

export interface IndexDiff {
  name: string;
  status: ComparisonStatus;
  source?: IndexSchema;
  target?: IndexSchema;
  differences: string[];
}

export interface PartitionDiff {
  status: ComparisonStatus;
  source?: PartitionSchema;
  target?: PartitionSchema;
  differences: string[];
}

export interface ConstraintDiff {
  name: string;
  status: ComparisonStatus;
  source?: TableConstraintSchema;
  target?: TableConstraintSchema;
  differences: string[];
}

export interface ForeignKeyDiff {
  name: string;
  status: ComparisonStatus;
  source?: ForeignKeySchema;
  target?: ForeignKeySchema;
  differences: string[];
}

export interface TableComparisonResult {
  tableName: string;
  schemaName: string;
  status: ComparisonStatus;
  columnDiffs: ColumnDiff[];
  indexDiffs: IndexDiff[];
  constraintDiffs: ConstraintDiff[];
  foreignKeyDiffs: ForeignKeyDiff[];
  partitionDiff?: PartitionDiff;
}

export interface SchemaComparisonResult {
  sourceConnectionId: string;
  sourceConnectionName: string;
  targetConnectionId: string;
  targetConnectionName: string;
  comparedAt: string;
  summary: SchemaComparisonSummary;
  tables: TableComparisonResult[];
}
