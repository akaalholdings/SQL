import { BrowserRouter, NavLink, Route, Routes } from "react-router-dom";
import { AuthGate, useAuth } from "./auth";
import { DashboardPage } from "./pages/DashboardPage";
import { EnvironmentPage } from "./pages/EnvironmentPage";
import { SchemaComparisonPage } from "./pages/SchemaComparisonPage";
import { DataValidatorPage } from "./pages/DataValidatorPage";

export function App() {
  return (
    <BrowserRouter>
      <AuthGate>
        <div className="shell">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<DashboardPage />} />
              <Route path="/environments/:id" element={<EnvironmentPage />} />
              <Route path="/schema-compare" element={<SchemaComparisonPage />} />
              <Route path="/data-validator" element={<DataValidatorPage />} />
            </Routes>
          </main>
        </div>
      </AuthGate>
    </BrowserRouter>
  );
}

function Header() {
  const { account, logout, login } = useAuth();
  return (
    <header className="topbar">
      <div className="brand">
        <div className="logo">⇧</div>
        <div>
          <div className="title">Azure SQL Migration Manager</div>
          <div className="subtitle">Flyway-style migrations for Azure SQL</div>
        </div>
      </div>
      <nav className="nav">
        <NavLink to="/" end>
          Dashboard
        </NavLink>
        <NavLink to="/schema-compare">Schema Compare</NavLink>
        <NavLink to="/data-validator">Data Validator</NavLink>
      </nav>
      <div className="user">
        {account?.username ? <span>{account.username}</span> : null}
        {account ? (
          <button className="ghost" onClick={logout}>
            Sign out
          </button>
        ) : (
          <button className="ghost" onClick={login}>
            Sign in
          </button>
        )}
      </div>
    </header>
  );
}
