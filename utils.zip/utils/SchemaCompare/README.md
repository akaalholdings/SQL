# Azure SQL DB Utils 

A web UI + API for running Flyway-style migrations against Azure SQL Database with Entra ID authentication, audit logs, and safe deployment controls.

## Architecture
- React + TypeScript UI
- FastAPI (Python) API wrapping Flyway CLI
- App DB for metadata (Azure SQL or SQL Server)
- Azure Key Vault for secrets (required)
