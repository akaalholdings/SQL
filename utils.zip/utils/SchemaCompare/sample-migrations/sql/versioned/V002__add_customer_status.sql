ALTER TABLE dbo.Customer
ADD Status NVARCHAR(50) NOT NULL DEFAULT 'Active';

CREATE INDEX IX_Customer_Status ON dbo.Customer (Status);
