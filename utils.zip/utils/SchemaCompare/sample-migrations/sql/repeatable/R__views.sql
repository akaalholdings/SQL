CREATE OR ALTER VIEW dbo.vw_ActiveCustomers AS
SELECT CustomerId, Name, Email, Status
FROM dbo.Customer
WHERE Status = 'Active';
