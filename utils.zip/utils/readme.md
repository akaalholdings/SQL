Used for fe space
